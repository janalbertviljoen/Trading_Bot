---
paths:
  - "Toolbox/*/pipeline.py"
  - "Toolbox/skatkis/pipelines/dag.py"
  - "Toolbox/skatkis/pipelines/registry.py"
  - "Toolbox/skatkis/pipelines/runnable.py"
---

# Pipeline orchestration (SOP §4.5, §7, §16)

- `pipeline.py` owns source registration, the DAG (as data, §16.1), execution order,
  seed extraction, registry updates and result access. No formulas, source
  transformations, validation logic or product branches (§4.5).
- After each layer: order fields by grain and output schema, update the contract entry,
  store the result, expose it to downstream hydration (§16.2).
- Construction is explicit: `from_paths` / `from_records` separate file access from
  execution (§16.4). Results are read through a controlled accessor; access before
  `run` raises (§16.5).
- Pipelines satisfy `RunnablePipeline` (§17.2): `registry`, results mapping,
  `run(start_layer=None)`. Keep that protocol stable; `ui` and accreditation depend on it.
- Do not imply concurrency for independent terminal branches (§16.3).
