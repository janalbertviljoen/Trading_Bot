---
paths:
  - "steward/**"
---

# Steward's records (`steward/`)

- Only the secretary writes here: notes, change logs, change files, designs, charts and
  the agent instructions. Read `steward/instructions/secretary.md` (imported below)
  first.
- `steward/` holds no code and no client data.
- Keep `steward/steward.md` current: update it, and its decision log, whenever
  Steward's behaviour, access or hosting changes.
- When a rule is decided during a change, record it in the agent instructions once the
  unit tests are signed off (`secretary.md`, "Decided rules go into the agent
  instructions").

@../../steward/instructions/secretary.md
@../../steward/instructions/writing.md
