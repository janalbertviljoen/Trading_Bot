---
paths:
  - "Toolbox/*/schema.py"
---

# Schema (SOP §4.1, §5)

- `schema.py` is the single source of truth for canonical column contracts (§5.1). No
  other production module redefines a column.
- Owns names, dtype and constraint flags (`required`, `positive`, `non_negative`,
  `probability`, `unique_key`, `join_col`, `value_col`), defaults, ownership and
  derivation metadata, source and layer input/output schemas, and model constants.
- Must not contain DataFrame calculations, file IO, validation execution or orchestration.
- Layer input schemas reference upstream entries directly (`X_INPUT["c"] =
  UPSTREAM_OUTPUT["c"]`) to keep lineage (§5.3).
- Adding a flag activates generic validation everywhere the schema is used (§13.2):
  check which layers consume the column before changing metadata.
- Renaming a canonical column touches code, contracts, tests, README, mappings and the
  accreditation reference metric names (§12.4, §15.6). Do not rename partially.
- Use shared schema factories for repeated instrument structures (§5.5, §18).
