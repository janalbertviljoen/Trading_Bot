# Fair value tool: error guide (temporary copy for Copilot)

Use this guide when a user pastes an error from the fair value tool, or a run does
something they did not expect. Find the entry by the label in square brackets at the
start of the message and by the rule named in it, then tell the user what to check
first, in order, and the fix. Never repeat data values from a pasted error back to the
user beyond the column and row names. On new client data, give the exact fix when you
know it; in a training exercise, point the user to the check and the tool rather than
solving it.

Entries are keyed `<tool>/<source>/<error>`: `skatkis` for an error raised by the
shared core, `fair_value` for one raised by the tool. `<source>` is the label in square
brackets: a model class (`FacilitiesModel`, `PDModel`, `LGDModel`,
`PortfolioEconomicsModel`, `FacilityEconomicsModel`), a mapping loader
(`load_pd_model_col_map`) or a layer's input gate (`exposure_input`, `valuation_input`).

The user manual is `Clients/client_x/fair_value/00_start_here.py`; its sections are
referred to as §2 (economics levels), §3 (folders and file names) and §4 (input
reference).

## Reading a schema violation (Pandera)

Every source and every layer input passes one schema gate. It runs all the schema's
rules at once and raises one `SchemaValidationError` listing every rule broken, the
column, how many rows, and up to five of those rows named by their key.

One run reports every problem in a file. Six faults in a facilities file, as raised:

```text
SchemaValidationError: [FacilitiesModel] 6 schema violation(s):
  - [FacilitiesModel] Duplicate rows on key ['loan_id']: 2 rows. Rows: loan_id='S0007'; loan_id='S0007'
  - [FacilitiesModel] Null values found in 'product_type': 1 rows. Rows: loan_id='S0008'
  - [FacilitiesModel] Disallowed values detected in 'product_type': ['trm']. Allowed values: ['revolver', 'term']. Rows: loan_id='S0001'
  - [FacilitiesModel] Disallowed values detected in 'payment_type': ['fixed payment']. Allowed values: ['bulletpayment', 'fixedpayment', 'fixedpaymentapprox', 'interestonlypayment']. Rows: loan_id='S0002'
  - [FacilitiesModel] Null values found in 'principal': 1 rows. Rows: loan_id='S0006'
  - [FacilitiesModel] 'principal' must be > 0. Found 1 invalid values. Rows: loan_id='S0008'
```

A mapping or casting fault stops loading before this gate runs, and is reported alone:

```text
ValueError: [FacilitiesModel] Mapping references source columns absent from input: ['Loan Amt']
Columns present: ['Product', 'Repayment Type', 'Start Date', 'Payment Frequency', 'Maturity Date', 'Loan Amount', 'Interest Rate', 'Compounding', 'EIR', 'CCF', 'Limit', 'Risk Grade', 'Depreciation Rate', 'Disbursement', 'First Payment Date', 'Account Number']
```

Earlier checks stopped at the first rule broken and gave only a count, so the same
three faults took three runs to find:

```text
ValueError: [FacilitiesModel] Null values found:
principal    1
```

Further examples:

```text
[PDModel] 2 schema violation(s):
  - [PDModel] 'pd_ttc_cumulative' has values outside [0, 1]. Found 1 invalid values. Rows: pd_band='aa', mob=6
  - ...

[exposure_input] 1 schema violation(s):
  - [exposure_input] Null values found in 'pd_pit_cumulative': 1 rows. Rows: loan_id='S0003', mob=...

[PortfolioEconomicsModel] 1 schema violation(s):
  - [PortfolioEconomicsModel] Null values found in 'hurdle_rate': 1 rows. Rows: row 0
```

How to read one:

1. The label in brackets says **where**: a model class means the source file failed as
   loaded; a name ending in `_input` means a layer's input failed after the sources were
   joined, so the cause is usually a join that did not match.
2. Each line is **one rule**: null, disallowed value, bound, duplicate key, required
   column. The entries below are keyed on that rule.
3. **Rows** names the first five failing rows by key; `(+n more)` follows when there are
   more. Open those rows first.
4. Text is stripped and lower-cased before the gate, so a difference in case or
   surrounding spaces never fails it; a value listed as disallowed differs in spelling
   or inner spaces.

## Loading and mapping

### skatkis/<Model>/mapping_columns_absent

- **Shown as:** `ValueError: [<Model>] Mapping references source columns absent from input: [...]`, followed by `Columns present: [...]`.
- **Stage:** loading a source, before casting.
- **Check first:** 1. the listed name against the file's header: spelling, spaces,
  capitals, a `%` or unit dropped or added; 2. whether the client renamed the column in
  this export; 3. whether the mapping belongs to another file.
- **Fix:** correct `source_column` in the mapping (or the header), so every mapped input
  is in the file.

### skatkis/load_<source>_col_map/duplicate_mapping_targets

- **Shown as:** `ValueError: [load_<source>_col_map] Multiple source columns map to the same internal column: [...]`, followed by the source columns per internal column.
- **Stage:** reading the mapping CSV, for every source.
- **Check first:** the mapping rows for the listed internal column: two client columns
  point at it.
- **Fix:** keep one row per internal column; drop or remap the other.

### fair_value/load_pd_model_col_map/required_mapping_missing

- **Shown as:** `ValueError: [load_pd_model_col_map] At least one of {'pd_pit_marginal', 'pd_pit_cumulative'} must be mapped.` (or the TTC pair); for the LGD model, `At least one of {'secured_lgd', 'unsecured_lgd'} must be mapped.`
- **Stage:** reading the PD or LGD mapping.
- **Check first:** the mapping has a row for a point-in-time and a through-the-cycle
  curve (cumulative or marginal), or for at least one LGD.
- **Fix:** add the missing mapping row; if the client did not supply the curve, ask.

### skatkis/<Model>/missing_required_columns

- **Shown as:** `[<Model>] Missing required columns: [...]`, followed by `Columns present: [...]`.
- **Stage:** loading a source, or a layer's input gate.
- **Check first:** 1. if `Columns present` shows the client's own names, the mapping
  file was not found (missing or misnamed), so no mapping was applied; 2. otherwise the
  mapping has no row for the listed column.
- **Fix:** put the mapping file under its standard name (§3), or add the row.

### fair_value/<source>/paired_presence

- **Shown as:** `'<source>': data file and mapping file must both be present or both be absent.`
- **Check first:** the file names in `raw_data/` and `column_mapping/` against the
  standard names (§3).
- **Fix:** supply both files, or neither.

### skatkis/<Model>/failed_cast

- **Shown as:** `ValueError: [<Model>] Failed to cast '<column>' to <dtype>: ...` (for a date, `time data "..." doesn't match format "%Y-%m-%d"`).
- **Stage:** loading a source.
- **Check first:** 1. dates in another format (day/month/year): write ISO `YYYY-MM-DD`;
  2. text in a numeric column (`N/A`, `-`, `n.a.`).
- **Fix:** convert the column in the file, or ask the client for the value.
- **Beware:** numbers with a decimal comma or a `%` are not rejected but can be read
  wrongly; see "Numbers read wrongly" below.

### fair_value/portfolio_economics/mapped_at_both_levels

- **Shown as:** `ValueError: Column '<column>' (instrument '<instrument>') is mapped at both facility and portfolio level for this run.`
- **Stage:** building the run, after the economics sources load.
- **Check first:** the column appears in both `portfolio_economics_mapping.csv` and
  `facility_economics_mapping.csv`.
- **Fix:** keep it in one: per loan in facility economics, or one value in portfolio
  economics (§2).

### skatkis/<source>/file_not_found

- **Shown as:** `FileNotFoundError: [<context>] File not found: <path>`.
- **Check first:** the folder and the standard file names (§3).

## Schema gates

### skatkis/<Model>/null_values (at a source)

- **Shown as:** `[<Model>] Null values found in '<column>': n rows. Rows: ...`.
- **Check first:** the named rows in the file: the value is empty, or the column is
  empty because its mapping row is missing.
- **Fix:** supply the value; if it cannot be derived from the data, ask the client.
  `hurdle_rate` is required; a missing rate is not defaulted.

### skatkis/<layer>_input/null_values (after hydration)

- **Shown as:** `[<layer>_input] Null values found in '<column>': n rows. Rows: loan_id=..., mob=...`.
- **Stage:** a layer's input, after the sources are joined: the error appears one step
  after its cause.
- **Check first:** 1. the join keys of the model that supplies the column: a facility's
  `pd_band` not in the PD model (spelling, inner spaces), a `product_type` not in the LGD
  model; 2. a gap in a curve: a band without every month on book (curve completeness is
  not checked at load); 3. the named loans and months, to see which join missed.
- **Fix:** align the labels, or complete the curve.

### skatkis/<Model>/disallowed_values

- **Shown as:** `[<Model>] Disallowed values detected in '<column>': [...]. Allowed values: [...]. Rows: ...`.
- **Check first:** the listed values against the allowed list: a client label not yet
  translated (`fixed payment` for `fixedpayment`, `trm` for `term`).
- **Fix:** translate the client's labels to the internal values (§4).

### skatkis/<Model>/duplicate_key

- **Shown as:** `[<Model>] Duplicate rows on key [...]: n rows. Rows: ...`.
- **Check first:** the named rows: a loan exported twice, or two curve rows for the same
  band and month.
- **Fix:** keep one row per key. `ingest_csv` drops **every** copy of a duplicated key,
  so remove the duplicate before ingesting, or the loan is lost.

### skatkis/<Model>/outside_probability_bounds, not_positive, negative

- **Shown as:** `'<column>' has values outside [0, 1]`, `'<column>' must be > 0`, `'<column>' must be >= 0`, each with a count and rows.
- **Check first:** 1. a rate or probability given as a whole number (`45` for 0.45);
  2. a sign error; 3. a value keyed in the wrong column.
- **Fix:** correct the value; for a rate in percent, divide by 100 (or keep the `%`
  only if every value in the column has it; see "Numbers read wrongly" below).

### skatkis/<Model>/null_where_required

- **Shown as:** `Null values found in '<column>' where <condition>`, for example `ccf` or `account_limit` where `product_type == 'revolver'`.
- **Fix:** supply the column for those products.

## Tool rules

### fair_value/<context>/unrecognised_product_type

- **Shown as:** `[<context>] Unrecognised product_type values: [...]. Valid types: [...]`.
- **Fix:** translate the label, as for disallowed values.

### fair_value/term_schedule/term_schedule_rules

- **Shown as:** `[term_schedule] n validation error(s):` with one line per loan: unknown `payment_frequency`, neither `term_months` nor `final_payment_date`, `term_months` not a positive whole number, final payment before the first.
- **Fix:** correct the named loans' schedule fields.

### fair_value/<context>/unsupported_exposure_type

- **Shown as:** `Unsupported exposure_type: ...`.
- **Note:** every loan is treated as corporate; other asset classes are not built yet.

## Soft outcomes: no error, but something was assumed

### Optional column not mapped: defaulted silently

A column with no mapping row is not loaded; if the tool needs it, its schema default is
used (for example `capitalisation_rate` 0, which gives no capital). There is no error.
**Check:** `ignored_columns(pipeline, dir_raw_data)` in `manual_helpers.py`, and
`pipeline.registry.report.by_category("defaulted")`.

### Rows dropped at ingestion

`ingest_csv` prints `[<context>] Dropped n of m rows on schema soft-validation.` and
keeps the rows on `.dropped`. **Check:** review `.dropped` before writing the file; a
loan dropped for a repairable reason should be repaired, not dropped.

### Numbers read wrongly

Numeric columns are read by stripping every `,` and every `%`, and when any value in the
column holds `%`, the **whole column** is divided by 100. A decimal comma (`12,5%`)
becomes 125%, and every other value in the column is divided by 100, with no error.
**Check:** numeric columns use a decimal point and no thousands separator, and a `%`
appears on every value of a column or on none.

### Text tidied on loading

Text columns are stripped and lower-cased, so `Term` and `term ` both load as `term`.
Inner spaces and misspellings are not repaired.

### A stale file picked up

The loader reads any file with a standard name, for example an old
`facility_economics.csv`. **Check:** the folder holds only this run's files.

### Every loan treated as corporate

The capital calculation applies the corporate formula to every loan; other asset
classes are not built yet.
