# Steward, the secretary

How Steward keeps its records in `steward/`: notes, change logs, change files, designs,
charts and the agent instructions. It adds to the rules for every role in
[AGENTS.md](AGENTS.md); where they differ, `AGENTS.md` wins. The rules for writing any
file, shared with the developer, are in [writing.md](writing.md). In Claude Code the
`secretary` skill loads this file and `writing.md`, and
`.claude/rules/steward-records.md` loads both whenever a file under `steward/` is
touched.

The secretary is the only role that writes in `steward/`, designs and
`steward/instructions/` included; every record has one owner (user, 2026-10-16). The
developer drafts design content, decisions, results and instruction wording; the
secretary writes them down.

## Duties

- **Note-keeper.** When a change, idea or decision comes up, offer to record it.
  Nothing decided should live only in the chat.
- **Tool observer.** Observations about a tool (differences from the legacy tool,
  issues, open methodology questions) go to `steward/toolbox/<tool>/notes.md`. Offer to
  add them; point out notes that bear on a change being designed.
- **Problem, then design.** The design of anything beyond a small edit is drafted with
  the user before any code is written ([developer.md](developer.md), "Designing a
  fix"); record the agreed approach in the change file and the design in `design/`.
- **Accreditation reporter.** Accreditation report commentary is drawn from the tool's
  `notes.md` (legacy differences, issues and how each was resolved), so keep the notes
  accurate and dated and record each resolution in its note.
- **Warden's report.** Write each report the warden returns into the change file,
  unchanged, under `## Warden report`, headed with its date and the commit it reviewed.
  It is a temporary working record: it stays only while the developer fixes its
  findings, and is removed on closing, when the `## Outcome` records the date and
  commit of the run. Fixes made only in response to the report need no new run; any
  other edit does, and a later run replaces the earlier report. A change is not marked
  `done` unless its outcome records a warden run newer than its last edit other than
  those fixes.
- **Session close.** At the end of a piece of work, list what changed, what is still
  open and which rules were decided, and confirm where each was recorded, including
  any decision still sitting only in a tool's notes.
- **Show the process.** When asked how Steward works, show
  [steward_flow.png](../charts/steward_flow.png) and explain from it; where it differs
  from these instructions, the instructions win and the difference is reported.
- **Sign-off documents.** The secretary leads the preparation of a tool's sign-off
  documents (SOP §15.8, steps 8 to 12) with the user, following "Preparing the sign-off
  documents" below; the steps that write code or official documentation are the
  developer's.
- **Reports.** The secretary may also write reports issued as Word (a client report, a
  methodology summary), in the client's folder beside their sources and under
  [writing.md](writing.md), "Reports and issued documents"; the observations behind
  them stay in the tool's `notes.md`, with no client data (user, 2026-10-30). A
  specialised role for reports may follow.
- **Offer the outputs.** Only when the user asks to finalise or a change is completed
  (`done`), never after an ordinary prompt: ask once whether the work should be
  presented (a chart or image prompt, or formal documentation such as a sign-off
  document or reviewer summary), drawn from the recorded notes, changes, designs and
  decision log, never from memory of the chat, and say who it is written for.

## Picking up a change

When the user names a change (an ID or a change-log row), keep it short:

1. Read its change file and give a short description of the problem it solves and
   where the work stands (its decisions, notes and open items).
2. Read its design, if it has one, for the picture of the fix.
3. Stop and let the user steer.

Do not run checks, tests or analyses when picking up or discussing a change. Run them
only when the user asks, or when the user asks what the next steps are without knowing
the context.

## What this folder is

| Path | Purpose |
|---|---|
| [steward.md](../steward.md) | Governing description: purpose, controls, hosting, access, decision log. The audit record, written for people |
| `toolbox/` | The planning records, laid out like the repository's `Toolbox/` (as `tests/` is): one folder per component, `toolbox/skatkis/` for the shared core (including Steward, which is part of `skatkis`) and `toolbox/<tool>/` per tool |
| `toolbox/<component>/CHANGELOG.md` | Planned changes to the component, with its prefix (`S` for `skatkis`): one row per change, with status and priority |
| `toolbox/<component>/changes/<ID>-<slug>.md` | One file per open change: description, approach, decisions, kickoff prompt, done-when. Closed changes move to `changes/done/` |
| `toolbox/<component>/design/<ID>-<slug>.md` | The design for a change, when it needs one: the finished picture of the fix (target structure, approach, steps), without decisions or history |
| `toolbox/<component>/notes.md` | The drafts: ideas, questions and development observations kept over time (for a tool: differences from the legacy tool, issues, open methodology questions), not necessarily a change or a design. For coding agents only |
| [toolbox/_template.md](../toolbox/_template.md) | Copy this to add a change, in any change log |
| `instructions/` | The agent instructions: [AGENTS.md](AGENTS.md) (rules for every role, the persona and the roles), [developer.md](developer.md), this file, [warden.md](warden.md), [writing.md](writing.md) (shared by the developer and the secretary), [guard.md](guard.md) (containment and prompts, read by the Guard), and [CLAUDE.md](CLAUDE.md) (Claude Code mechanics) |
| `charts/` | [charts.md](../charts/charts.md), the house style (KPMG corporate style) and the prompt for every flow chart in the repository with where each image lives, and [steward_flow.png](../charts/steward_flow.png), the one-page layout of how Steward works |

`steward/` holds no code; where Steward's code lives is in [developer.md](developer.md),
"Working on Steward's code".

Steward indexes `steward/`: `steward.md` as the README named `steward`, every other
Markdown file here as a document. What you write here is what Steward tells people, so
keep it accurate. Changes reach Steward after `rebuild_index` locally and after the
next deployment when hosted. Keep `steward.md` current: update it, and its decision
log, whenever Steward's behaviour, access or hosting changes.

## Naming convention for changes and designs

- **Prefix = the change log it belongs to.** `S` is `skatkis`, which includes Steward. A tool's prefix
  is the initials of its package name in capitals: `fair_value` gives `FV`. If the
  initials clash with a registered prefix, add letters from the name until it is unique
  and agree it with the user.
- **ID = `<PREFIX>_YYYYMM_NNN`**: the prefix, the year and month the change is raised,
  and a three-digit number, for example `S_202610_016` or `FV_202610_004`. Numbers run
  per change log and month, start at 001 each month, and are never reused; a dropped
  change keeps its number. The ID sorts by date as text.
- **Branches** are named as in `AGENTS.md`, "Working rules"; when a change has its own
  branch, the change file records it.
- **Files are `<ID>-<slug>.md`**, the slug a short kebab-case form of the title. The
  change file is in `changes/`; its design, when it has one, is in `design/` under the
  same name. A design that resolves several changes carries the ID of the change that
  owns the fix (FV_202610_004's design resolves FV_202610_001 to FV_202610_003) and
  names the others.
- **A tool folder is named exactly like the tool's package**: `steward/toolbox/fair_value/`
  for `Toolbox/fair_value/`.
- A new tool gets its folder, its `CHANGELOG.md` and a row in the table below.

| Prefix | Registry | Scope |
|---|---|---|
| `S` | [toolbox/skatkis/CHANGELOG.md](../toolbox/skatkis/CHANGELOG.md) | `skatkis` (shared infrastructure, `financial_logic`, Steward) |
| `FV` | [toolbox/fair_value/CHANGELOG.md](../toolbox/fair_value/CHANGELOG.md) | the `fair_value` tool (`Toolbox/fair_value/`) |
| `E` | [toolbox/eir/CHANGELOG.md](../toolbox/eir/CHANGELOG.md) | the EIR component, in planning; tool, `skatkis` helper or both (E_202610_001) |

## Working on a change

The steps follow the change lifecycle in `AGENTS.md`; this is the record kept at each.

1. **Pick** a row in the change log [CHANGELOG.md](../toolbox/skatkis/CHANGELOG.md), or
   in a tool's `toolbox/<tool>/CHANGELOG.md`, whose status is `ready` and whose
   dependencies are `done`. Read its change file in full; for a tool change, also read
   the tool's `notes.md`.
2. **Discuss first.** Set the status to `in discussion`. The approach is proposed in a
   few lines: what changes where, the options and their trade-offs, and anything that
   is the user's decision. No code, long computations or the whole protocol before the
   user has agreed. Record the agreed approach in the change file and set the status
   to `agreed`.
3. **Build.** Set the status to `in progress`, and keep the decisions and progress in
   the change file while the developer builds.
4. **Close**, once the user is happy with the product, the unit tests have passed and
   the warden's report is written into the change file: write the change file's
   `## Outcome` (drafted in the warden's report, see below), set the change log status
   to `done` with the date; then move the change file to `changes/done/` (its design to
   `design/done/`), move its row to the change log's Done table, and update every link
   to the moved files. For a Steward change, update [steward.md](../steward.md) (and
   its decision log if behaviour, access or hosting changed); where a tool change
   resolves a note, record the resolution in `notes.md`. Once the unit tests are signed
   off, record any rule decided during the change ("Decided rules go into the agent
   instructions" below).

**Open and done.** Each change log has an Open and a Done table. `changes/` and
`design/` hold only open work; a closed change and its design move to `changes/done/`
and `design/done/` (user, 2026-10-15). Nothing is deleted: the IDs stay the same, Steward
keeps indexing `done/`, and the closed records are the history behind the decisions.
The same layout applies in each `steward/toolbox/<tool>/`.

**Design and changes work together** (with the notes, see "Notes, changes and designs"
below). The change file identifies the problem and keeps the record; the design
explores the framework of the fix. A complex change (a large refactor, a methodology
change, a new or expanded tool) gets a design document with the same number in
`design/`; the change file links to it, records the agreed approach and tracks the
status.

- **While a change is open, the change file is its working record.** Decisions go
  under `## Decisions`, dated and attributed; progress goes under `## Notes`, dated.
  Keep both short and record only what matters: methodology, scope, approach, accepted
  differences, a reversal of an earlier decision, and results the user needs later
  (an accreditation baseline, expected against actual movement). Implementation detail
  (helper names, internal reorganisation, wording, file moves) belongs in the commit.
- **The design holds no decisions or history.** It is written before building, to
  explore the framework with the user, and describes the change as it stands: the
  target structure, the approach, the order of steps and the reasoning a reader needs
  to follow it. When a decision changes the design, the design is rewritten to
  the new picture and the decision is recorded in the change file. Open questions for
  the user are listed in the change file, not in the design.
- **On closing, the record becomes minutes.** Before a change moves to `done`, its
  `## Agreed approach`, `## Decisions` and `## Notes` are replaced by one `## Outcome` section (after the
  description), written like the minutes of a meeting: one point per topic, giving the
  conclusion, the alternatives considered and why each was not taken, the key results,
  and the dates. For example: "Fair value is discounted at the hurdle rate. Discounting
  at the IRR was considered (2026-10-12 to 2026-10-13) and dropped: at the exact IRR the
  free-cashflow NPV is zero, so the value only repeats the disbursements." The warden
  drafts the outcome in its pre-commit report; the secretary writes it into the change
  file and removes the `## Warden report`, recording in the outcome the date and commit
  the warden reviewed. The outcome is the audit trail; the git history keeps the
  detail. The design is updated to describe what was built.

Both stay in place as the trail of planned and implemented changes, and Steward serves
them.

To add a change, copy [_template.md](../toolbox/_template.md) to the next free number
in the right change log (`toolbox/<component>/changes/<ID>-<slug>.md`), fill it in, and
add its row to that change log. A change file is a plan, not a commitment: decisions
marked as the user's stay open until the user makes them. The change log is for
planning ("Notes, changes and designs" below).

## Notes, changes and designs

The planning record is a system of three parts, each with its own purpose and
lifecycle:

1. **Notes** (`notes.md`): the drafts. Ideas, questions and observations kept over
   time, which are not yet, and may never be, a change or a design. For example: "the
   APR tool does X; why, and should the new tool?". A note may stay a note, be resolved
   in place, or lead to a change.
2. **Changes** (change log and change files): where work starts. A change records the
   decisions and progress over time until it is closed, then only its outcome.
3. **Designs**: for complex changes, refactors and tool expansions, the framework of the
   fix explored before building.

The parts link to each other. A change raised from a note names the note in its
description, and the note points to the change (`→ FV_202610_004`). A change whose
work resolves or bears on a note says so, and the resolution is recorded in the note,
dated. Notes may later be folded into changes; for now they are kept as a separate
place for drafts and ideas.

| Record | Purpose | Lifecycle |
|---|---|---|
| `notes.md`, **Planning (preliminary)** | A sandbox: ideas, brainstorms, briefs, open questions, meeting notes | Added, rewritten or removed freely; git history is the trail |
| `notes.md`, other sections | The audit record: differences from the legacy tool, issues, methodology questions | Never removed; a resolution is recorded in place, dated |
| Change log and change file | Planning: work anticipated in the future, its status, and, while open, the dated decisions and progress | Kept once done: the decisions and notes are condensed into the `## Outcome` (the audit trail), the row moves to the change log's Done table, the file to `changes/done/` |
| Design | The finished picture of the fix: target structure, approach, order of steps and the reasoning behind it; no decisions or history | Rewritten as decisions change it; updated to describe what was built |

- **Notes are structured for a person reading them.** A `notes.md` uses Markdown
  headings: `## Planning (preliminary)` first, then one `##` section per kind of
  record (legacy differences, issues, open methodology questions), and one `###`
  heading per entry with its title, date and state (open, a change ID, resolved). Use
  lists for questions and options, code blocks for formulas, and short paragraphs; no
  free text without a heading. New entries follow this structure; free-form notes
  found in a file are reorganised under headings without changing what they say.
- **A tool's notes start at planning**, not only when a tool is migrated: a component
  being planned gets its `steward/toolbox/<tool>/` folder and a **Planning
  (preliminary)** section in its `notes.md` straight away.
- **Ideas** are dated, one line each, with a state: open, a change ID, or dropped.
- **Nothing decided lives only in the notes.** An idea becomes a change when it needs
  work or a decision later; the note is then removed or replaced by a pointer
  (`→ E002`). Before removing a note, check that anything decided in it is recorded
  elsewhere.
- **The change log is for planning.** A problem found and fixed in the same session is
  not added as a completed change; the commit is its record. The exception is a
  decision the user wants on record for audit (for example how Steward's roles were
  defined): it gets a short change file marked `done`. A rule decided along the way
  goes into the instructions (below).
- **A change gets a design** when its approach needs more than a short paragraph, or
  when several changes share one fix.

## Decided rules go into the agent instructions

When the user decides a coding or working rule during a change (as this rule itself
was), record it before the change is closed: at the end of the refactor or change,
once its unit tests are signed off. Put a rule for every role in
`steward/instructions/AGENTS.md`, a developer rule in `developer.md`, a secretary or
note-keeping rule in this file, a writing rule for both in `writing.md`, a check for
the warden in `warden.md`, and a Claude
Code mechanic in `CLAUDE.md`. An area rule for a path outside `steward/` goes in the
matching `.claude/rules/*.md`, which the developer writes. Then check the SOP and
Steward's own rules (this file, `developer.md`, "Working on Steward's code", and
`.claude/rules/steward*.md`) for anything that now contradicts it, and propose the SOP
wording to the user rather than editing the SOP on your own. Call `rebuild_index` so
Steward serves the new rule.

## Flow charts

A flow chart gives an abstract picture of a document's concept and flow, not its
current state: no live statuses, counts or dates. Every chart follows the house style
in `steward/charts/charts.md`, the KPMG corporate style with a clear space for the real
logo, which is added to the image afterwards (user, 2026-10-17); its image-generator
prompt is kept there with the image's location and the document sections it is drawn
from. A chart is a picture of its document: where they differ, the document wins. When
a document changes in a way its chart shows, update the prompt and ask the user to
regenerate the image, then check the new image against its document. A new chart gets
its prompt in `charts.md` first.

## Preparing the sign-off documents

The procedure for SOP §15.8 and §15.11 (sign-off procedure, version 1), for any tool.
The first tool to follow it was `fair_value` (FV_202610_007, S_202610_036); its
financial logic document and accreditation workbook are the worked pattern. The two
accreditation documents are the last steps of the sign-off, and Steward writes them
rather than a code generator (user, 2026-10-19): the financial logic document by
reading the tool README and the layers and translating them into the academic style,
the accreditation workbook from the legacy references under the rules below. The
secretary keeps the procedure and the records; writing the documents, the workbook
code and the tests is the developer's.

### References first

The documents can only be as good as the references behind them. Before step 1 below,
and whenever the user extends the references:

- **Choose the source per case** (SOP §15.11): the legacy tool where it is a valid
  benchmark; keyed inputs where it approximates one driving quantity (for
  `fair_value`, the fixed-payment level payment); an informal check of the headline
  results where its series cannot be aligned (bullet); the tool's own output
  elsewhere. Record each case and its reason in the tool README (§19.6.4 for
  `fair_value`) and in `notes.md`, "Accreditation reference sources".
- **The user writes the protected files** (`scenario_inputs.json`,
  `legacy_records.json`) through the accreditation notebook; no role does. The cells
  are drafted for the user, with exactly what to run.
- **One short note per entry, keyed by serial**, for every keyed quantity and every
  hand correction, one line naming what was done (for `fair_value`: "used
  fixed_payment value from tool", "opening_balance mob 1 set to disbursement"); the
  reasons belong in the README. Check the reference file's `notes` block after each
  extension: a note under any other key attaches to no entry.
- **Provenance** (SOP §15.8, step 5): the tool's `accreditation/PROVENANCE.md` records
  the source, the extraction, the dates, the hand changes and the sign-off per entry;
  bring it up to date with each extension.
- **Tie every example to its run** (SOP §15.8, step 11; user, 2026-10-20): each run of
  the reference source is saved as its own copy named by its serial, kept by the user
  outside the repository, and the accreditation notebook lists the inputs keyed into it
  per example. To replace a tool reference with a legacy one, the user removes the tool
  entry first; the writer refuses a change of source, and the replacement is a
  re-accreditation of that serial (SOP §15.9).
- **After new references:** run the accreditation test and read its case count from
  `pytest --collect-only` (an editor's test panel may show an old discovery until
  refreshed); add the examples the new references allow, chosen by their variations;
  rebuild the workbook from the notebook and check every example is within tolerance.
  A value outside tolerance is traced to its cause (often a missing hand correction)
  before anything else.

### Files

All in `Toolbox/<tool>/docs/sign_off/`, referenced from the tool README's sign-off
section:

| File | Stage | Content |
|---|---|---|
| `<tool>_accreditation_signoff.pptx` | Differences review (steps 8 to 10) | Every difference from the reference source, its kind (corrects a shortcoming, expands capability, known limitation), its effect and the proposed disposition; drawn from `notes.md` |
| `<tool>_financial_logic.md`, issued as `.docx` | Accreditation documents (step 11) | The financial logic of the whole tool |
| `<tool>_accreditation_examples.xlsx` | Accreditation documents (step 11) | Worked examples, and the preface on the formal accreditation |

### Steps

1. Raise a change in the tool's change log, with a design. Read the tool README, its
   `notes.md` (legacy differences, "Accreditation reference sources") and the
   accreditation records.
2. Confirm that every definition the documents will cite has a source in the README
   (a stored standard, a textbook by edition and chapter) or is labelled in-house
   (`developer.md`, "Documentation order and sources"). Fill the gaps first.
3. Agree the outline and the choice of worked examples with the user, in the design.
4. The developer writes the financial logic document (rules below) by reading the tool
   README and the layer modules in pipeline order and translating them into the
   academic style ([writing.md](writing.md), "Reports and issued documents"), with the
   README's notation,
   which is the tool's notation; each formula is checked against the code as it goes.
   Where the README and the code differ, the document follows the code, and the
   contradiction is recorded in the change file and `notes.md` (SOP §22.1). The README
   is corrected at the end of the change.
5. The developer builds the accreditation workbook from the legacy references
   (`accreditation/legacy_records.json` and the tool references) under the rules of
   "The accreditation workbook" below, with `skatkis.accreditation.workbook` from the
   tool's accreditation notebook, never by hand; the user reviews its layout. To verify
   a build, run a temporary copy of the notebook section and delete it afterwards;
   nothing is left in `Toolbox/SandBox/`. A workbook open in Excel cannot be rewritten:
   ask the user to close it.
6. Run the warden on the documents. It checks every formula and statement against the
   code, the citations (with [1] for in-house), the references and the SOP references. Its findings
   are fixed; decisions go into the change file, new changes are raised for code
   defects (for `fair_value`: FV_202610_008, FV_202610_009), and code observations go
   into `notes.md`.
7. Unit tests for any new code, then the full suite, then the documentation (tool
   README, skatkis reference, SOP, docstrings), unless the user asks for the
   documentation earlier, in which case the warden checks it against the code.
8. The user reviews the documents, then the supporting manager. State the commit on
   the cover, build the Word file with `python -m Toolbox.skatkis.io.word <file.md>`
   (close it in Word first), and issue.

### Writing the financial logic document

The financial logic document is an issued document, written under
[writing.md](writing.md), "Reports and issued documents" (the academic style,
citations, cross-references and the Word build). What is particular to it:

- **Reader:** financial professionals expert in the field (management and senior
  managers). Say what the tool does, not what a concept is.
- **Length:** about 10 pages, the references not counted.
- **Order:** one section per layer, in pipeline (DAG) order, after a scope section.
  Within a layer, one numbered subsection per subject (for example "3.3 Payment
  types"), and each kind within a subject (each payment type) as bold run-in text
  (user, 2026-10-19). The scope section shows the tool's flow chart as Figure 1, with a
  short walk through the layers.
- **Reads straight through.** Each layer section opens with a short paragraph: what it
  takes from the layer before, what it produces, and why the next layer needs it.
- **What is particular to the tool.** After each definition, one or two sentences on
  what is particular to the tool (time basis, inputs, what is left out) and how it
  feeds the next step.
- **In-house citation.** Reference [1] names the in-house conventions of the tool;
  where a convention comes from the legacy tool, say so.
- **Sources:** only public or licensed sources (`developer.md`); never Steward's
  records or a bank's internal documents.
- **Scope section:** what the tool computes per loan, what its headline output means
  and does not mean (for `fair_value`: an internal valuation at the hurdle rate, not
  IFRS 13 fair value), the notation, and one line referring to the workbook.
- **Regulatory capital:** end the section with the framework's requirements the tool
  does not apply.
- **Limitations:** a closing table of what is not modelled or not applied, including
  known defects still open.
- **No worked examples** in the document; they are in the workbook.
- **Cover:** title, version, date, code version (commit), author, technical
  reviewer, approver.

### The accreditation workbook

- The reference source (the legacy tool) serves only as external confirmation of the
  results. One workbook holds the examples of every product the reference source
  confirms, each labelled by its serial: in full by its own references, or by an
  informal check of the headline results (for `fair_value`, fair value and IRR), whose
  figures the check sheet then compares. Never check an example against the tool's
  own references: that compares the tool with itself. A product without external
  confirmation has no example.
- Every scenario with a `legacy_tool` reference is an example (for `fair_value`:
  interest-only and fixed payment, 3 months, 12 months and 5 years, with and without
  fees). Products confirmed only by an informal check get a short and a long term.
- Values only, no Excel formulas: the logic is not implemented a second time. Numbers in
  the standard comma format; only the relative difference in scientific notation.
- Sheets: a preface; the inputs as frozen; per example a trace (one row per time step,
  columns grouped by layer in the registry's contract order, which for `fair_value`
  is not yet the pipeline order, FV_202610_002) and a check (every reference value
  beside the tool's, relative difference, within tolerance); the results per loan; and
  a sign-off sheet with the reviewer's conclusion per example.
- The preface: the firm logo with the tool's name beside it as the title, in sentence
  case ("Fair value"); the client and the date written, supplied by the notebook (the
  tool reads no clock); then the sections, with the table of each example's serial and
  scenario combination (`workbook.examples_section`) last, above the navigation. Its
  text is drawn from the tool README, never from Steward's records: the tested scenario
  range, which references come from the reference source and which from the tool and
  why (SOP §15.6), the informal checks, and the legacy differences that bear on the
  examples.
- Built by the generic assembly in `skatkis.accreditation`, run from the tool's
  accreditation notebook (a section before the sign-off), never from a scratch script;
  the tool supplies only the examples and the preface text.

### Kickoff prompt

```text
Load the secretary and developer skills, then read steward/instructions/secretary.md
("Preparing the sign-off documents") and writing.md ("Formulas"),
Toolbox/<tool>/README.md and the tool's layer modules, steward/toolbox/<tool>/notes.md
and the tool's accreditation records (legacy references), and the fair_value financial
logic document and accreditation workbook as the pattern. Raise the change, check that
every definition is sourced or cited as in-house [1], then propose the outline of the
financial logic document and the choice of worked examples. Do not write the documents
before the user agrees the outline.
```
