---
paths:
  - "Toolbox/skatkis/**/*.py"
  - "Toolbox/fair_value/**/*.py"
---

# Docstrings (SOP §12.2, §12.3)

Docstrings are read by people and served to agents by the `skatkis.steward` server, so they
follow one structure. Code stays authoritative: a docstring describes what the code does,
never what it should do (§22.1). Keep production identifiers exactly (§12.4).

## Module docstring

numpydoc-style underlined sections, in this order. Omit a section that does not apply.

```
"""
<path from Toolbox/, e.g. skatkis/pipelines/registry.py>
<dashes, same length>
<One-line summary.>

<One to three paragraphs: purpose, where it sits in the pipeline, key ideas.>

Owns
----
<what this module is the single owner of>

Must not
--------
<what it must not compute or do, with the owner in brackets where known>

Public API
----------
name(signature-sketch)
    One line on what it does.

Computes
--------
<concept>, <concept> : <function>
    Formula or convention in one or two lines: units, rate basis, bounds.

<Optional topic sections: Formulas, Conventions, Contract and gates, Hydration, ...>

Dependency rule
---------------
<what it may and may not import>
"""
```

Accepted aliases when parsing: `Must NOT compute` = `Must not`; `Contents` = `Public API`.

## `Computes` section

Every module that calculates a financial quantity lists it, so people and agents can find
an existing calculation before writing a new one (SOP §3.2). Required for modules in
`skatkis/financial_logic`, `skatkis/numerics` and tool layers; omit it in modules that
only move, map or validate data.

- One entry per function: the concepts it calculates, comma-separated, in the words a
  quant would search for (`discount factor`, `effective annual rate`), then ` : ` and
  the function name. Private helpers may be listed; that is how calculations still to be
  promoted into `skatkis` are found.
- The function must be defined in the module itself. A layer that calls a
  `skatkis.financial_logic` function does not list it; the shared module does.
  `health` reports `unresolved_computes` otherwise.
- The indented description states the formula and conventions as the code implements
  them, never what it should do.
- Do not write whether a function is shared or private; the index reads that from code.

## Function and class docstrings

- Every public function and class has one. Private helpers get at least a one-line
  summary unless the name and body are self-evident.
- Self-explanatory functions: one line is enough (`"""Strip whitespace from keys and
  values."""`).
- Non-trivial public functions, and all `skatkis` public functions: summary, then
  `Parameters`, `Returns`, `Raises` where relevant; add `Notes` for behaviour that is
  easy to get wrong (mutation, copy-on-write, ordering, NaN handling, bounds).
- Calculation helpers document the formula, units, bounds and boundary behaviour (§12.3).
- Newly added functions follow the full form, not the brief one, unless trivial.
