# Financial Risk Management Repository

![How the repository fits together: skatkis, tools, clients, tests and Steward](docs/repository_flow.png)

## 1. Purpose

This repository contains production-oriented financial risk analytical systems and the shared infrastructure used to construct, validate, test, and operate them.

The repository is designed for analytical work that must be:

- modular;
- deterministic;
- contract-gated;
- source-agnostic;
- independently testable;
- reproducible;
- auditable;
- extensible across products and clients;
- suitable for controlled model development and review.

The repository does not treat spreadsheets or notebooks as production architectures. Spreadsheet models may provide methodology references, sample calculations, or reconciliation benchmarks. Production implementation must express the methodology through explicit schemas, source models, registries, contracts, validation gates, analytical layers, and tests.

Development is assisted by **Steward**, an MCP agent (server `skatkis-steward`, registered in `.mcp.json`). Coding agents ask it about the code, rules and documentation before writing code, and it keeps the change logs and tool notes in `steward/`. Its role is set out in SOP §22.5; the details are in `steward/steward.md` and section 19.

---

## 2. Documentation hierarchy

The repository documentation is organised from general governance to specific implementation.

```text
Repository README
    ↓
Toolbox modular analytical tools SOP
    ↓
skatkis reference (shared core)
    ↓
Tool-specific README
    ↓
Production schemas, contracts, validation, sources, registries, and layers
    ↓
Unit, contract, validation, pipeline, and integration tests
```

Use the documents as follows:

1. **This README** explains the repository structure, development workflow, and relationship between shared infrastructure, analytical tools, client implementations, and tests.
2. **`Toolbox/SOP_Modular_Analytical_Tools.md`** defines the mandatory engineering and governance standard for reusable analytical tools.
3. **`Toolbox/skatkis/docs/skatkis_reference.md`** describes `skatkis`, the core every tool imports from: its structure, the pipeline framework, schemas and validation (Pandera), accreditation mechanics, IO, numerics, branding and Steward, and the mathematical definitions and sources of everything in `skatkis.financial_logic`.
4. **Each tool README**, such as `Toolbox/fair_value/README.md`, documents the current architecture, source models, product registries, formulas, assumptions, validation design, outputs, and extension procedures for that tool.
5. **`steward/`** is the workspace for agents and for Steward, the read-only component index and MCP server. `steward/instructions/AGENTS.md` holds the rules for every agent in the repository, with one file per role beside it (the root `AGENTS.md` and `CLAUDE.md` only point to it); `steward/steward.md` describes Steward (what it may and may not do, how it is built, deployed and accessed, and the decisions behind it) and is kept current for audit; `steward/toolbox/skatkis/CHANGELOG.md` lists planned changes to `skatkis` and Steward, and `steward/toolbox/<tool>/` holds each tool's notes and planned changes. Changes are identified by their change log's prefix, the year and month raised and a three-digit number (`S_YYYYMM_NNN`, `FV_YYYYMM_NNN`); the naming convention is in `steward/instructions/secretary.md`. Steward indexes all of it.
6. **Production Python modules are authoritative** when a discrepancy is found. Documentation and tests must then be reviewed and brought back into alignment.

The SOP defines how tools must be built. A tool README explains how a particular tool is implemented. This repository README should remain broad enough to cover all tools without duplicating their detailed methodology.

---

## 3. Repository structure

```text
FinancialRiskManagement/
├── Toolbox/
│   ├── SOP_Modular_Analytical_Tools.md
│   │
│   ├── skatkis/
│   │   ├── accreditation/        # accreditation comparison, scenarios, reference files
│   │   ├── fault_injection/      # user test: subsample seed, faults, corrupted exports
│   │   ├── financial_logic/
│   │   ├── numerics/
│   │   ├── pipelines/            # contracts, registry, sources, resolvers, validation, ui
│   │   ├── saspy_wrapper/        # experimental SAS bridge
│   │   └── steward/              # Steward: component index and MCP server (section 19)
│   │
│   ├── fair_value/
│   │   ├── README.md
│   │   ├── contracts.py
│   │   ├── io.py
│   │   ├── pipeline.py
│   │   ├── product_types.py
│   │   ├── report_checks.py
│   │   ├── schema.py
│   │   ├── validation.py
│   │   ├── sources/
│   │   ├── layers/
│   │   ├── accreditation/
│   │   ├── ui_test/              # user test: seed, corrupted export, answer key (SOP §15.12)
│   │   └── docs/
│   │
│   └── SandBox/                  # exploratory code, outside the standard
│
├── Clients/
│   └── Client_X/
│       └── analytical_tool/
│           ├── raw_data/
│           ├── column_mapping/
│           ├── configuration/
│           ├── run_model.py
│           └── outputs/
│
├── tests/
│   ├── skatkis/
│   └── analytical_tool/
│       ├── sources/
│       ├── layer/
│       ├── test_schema.py
│       ├── test_contracts.py
│       ├── test_validation_<tool>.py
│       ├── test_io.py
│       └── test_pipeline.py
│
├── steward/                      # Steward's workspace (no code)
│   ├── steward.md                # governing description: controls, hosting, decision log
│   ├── toolbox/                  # planning records, laid out like Toolbox/
│   │   ├── skatkis/              # change log, changes, designs for skatkis (incl. Steward)
│   │   └── <tool>/               # each tool's notes, change log, changes and designs
│   ├── instructions/             # agent rules: AGENTS.md, developer.md, secretary.md, warden.md, writing.md, CLAUDE.md
│   └── charts/                   # chart prompts (charts.md) and the house-style template
│
├── docs/
│   └── repository-level supporting documentation
│
├── docker/
│   ├── Dockerfile                # container images (targets: base, steward)
│   └── constraints.py            # package_versions.txt -> pip constraints
├── .azure-pipelines/
│   ├── ci.yml                    # lint and tests on master and pull requests
│   └── steward.yml               # test, build and deploy Steward
├── .dockerignore                 # keeps client data and binaries out of images
├── .claude/                      # agent rules, settings and hooks (Claude Code)
├── .vscode/
│   ├── settings.json
│   └── extensions.json
├── .githooks/
│   └── pre-commit
├── AGENTS.md                     # pointer to steward/instructions/AGENTS.md (for agents that read the root)
├── CLAUDE.md                     # one line: imports steward/instructions/CLAUDE.md
├── .mcp.json                     # registers the Steward MCP server (skatkis-steward)
├── .importlinter                 # proposed import-boundary contracts
├── pyproject.toml
├── package_versions.txt
├── setup_env.ps1
└── README.md
```

Not every analytical tool must contain every optional file. The required structure depends on whether the tool has external source models, multiple layers, product-specific behaviour, terminal summaries, or additional methodology documents.

---

## 4. Repository areas

### 4.1 `Toolbox/`

`Toolbox/` contains reusable production analytical systems and shared infrastructure.

Belongs in `Toolbox/`:

- analytical engines;
- canonical schemas;
- concrete layer contracts;
- source-model abstractions;
- source-specific transformations;
- registries;
- validation gates;
- pipeline orchestration;
- reusable financial utilities;
- tool-specific documentation.

Does not belong in `Toolbox/`:

- client file paths;
- client raw data;
- confidential client extracts;
- client-only assumptions embedded in code;
- ad hoc notebook logic;
- copied functions from another toolbox module.

Every tool in `Toolbox/` must be usable by more than one client without modifying production code for client-specific column names or locations.

### 4.2 `Toolbox/skatkis/`

`skatkis` provides shared systems infrastructure used across analytical tools. It prevents every tool from implementing its own registry, contract, hydration, source, and validation framework. It is the core of the repository: tools import from it and it imports from no tool. Its reference document, [`Toolbox/skatkis/docs/skatkis_reference.md`](Toolbox/skatkis/docs/skatkis_reference.md), describes it in full.

Shared responsibilities may include:

- `LayerContract` and related interface abstractions;
- `PipelineRegistry`;
- `ColumnMap` and lookup-source base classes;
- source loading and canonical mapping behaviour;
- contract input hydration;
- keyed lookup resolution;
- broadcast resolution;
- schema metadata utilities;
- generic validation assertions;
- reusable financial constants and calculation utilities;
- reusable schema factories;
- accreditation mechanics (`skatkis.accreditation`);
- the pipeline user interface for overrides, solvers and summaries (`skatkis.pipelines.ui`);
- the read-only component index and MCP server (`skatkis.steward`, section 19).

`skatkis` holds no tool-specific domain knowledge, but general finance is shared: rate and compounding conventions, discounting, calendar arithmetic, rating scales and similar financial mathematics live in `skatkis.financial_logic` and are reused by every tool instead of being re-implemented. Tool-specific financial methodology does not belong in `skatkis`. A function belongs in `skatkis.financial_logic` when it is reusable across tools and has clear mathematical ownership (SOP §3.2).

Shared infrastructure must be tested in `tests/skatkis/`. Tool tests must not repeatedly retest inherited generic behaviour.

### 4.3 Tool packages

Each analytical tool is a self-contained domain implementation under `Toolbox/`.

A tool normally contains:

- a comprehensive `README.md`;
- `schema.py` as the canonical data dictionary;
- `contracts.py` with concrete layer contracts;
- `validation.py` with domain gates;
- `io.py` with source-model construction (one loader per source model);
- `pipeline.py` with the DAG and registry updates;
- `sources/` for external source normalisation;
- `layers/` for analytical stages;
- an optional registry module such as `product_types.py`;
- optional supporting methodology under `docs/`.

The tool README must explain the implemented system in sufficient detail for developers, reviewers, and AI-assisted development tools.

### 4.4 `Clients/`

`Clients/` contains client-specific execution and configuration.

Belongs in a client directory:

- controlled references to client source locations;
- client-specific column mappings;
- approved parameter files;
- environment configuration;
- pipeline construction;
- execution scripts;
- output reporting and export.

Does not belong in a client directory:

- reusable calculations;
- alternative versions of toolbox formulas;
- copied production modules;
- generic validators;
- generic source abstractions;
- methodology that should apply across clients.

If logic is potentially reusable, move the logic into the appropriate toolbox tool or shared infrastructure and inject client configuration through data.

### 4.5 `tests/`

Tests mirror production ownership.

```text
tests/skatkis/
    Generic infrastructure tests

tests/analytical_tool/sources/
    Source-specific mapping and transformation tests

tests/analytical_tool/layer/
    Layer-owned calculation and orchestration tests

tests/analytical_tool/test_schema.py
    Canonical metadata and schema composition

tests/analytical_tool/test_contracts.py
    Concrete contract integrity

tests/analytical_tool/test_validation.py
    Tool-specific gates and business rules

tests/analytical_tool/test_pipeline.py
    DAG, registry update, and end-to-end orchestration
```

Tests must not be organised only around convenience. Test location should indicate which production module owns the behaviour.

### 4.6 `docs/`

Repository-level `docs/` is reserved for material that applies across tools or the repository as a whole.

Examples:

- contribution guidance;
- environment setup;
- release procedures;
- governance or review templates;
- repository-wide architecture references. Design notes for planned changes live in `steward/toolbox/skatkis/design/`.

Tool-specific calculation and architecture documentation belongs with the tool, normally in the tool README and optional `Toolbox/<tool>/docs/` material.

---

## 5. Separation of shared infrastructure and financial logic

The repository separates generic system mechanics from domain methodology.

### Shared system mechanics

Examples:

- loading a column mapping;
- representing a layer contract;
- registering source and layer outputs;
- hydrating a missing derivable column;
- broadcasting a scalar configuration;
- asserting required columns or probability bounds;
- enforcing lookup coverage.

These belong in shared infrastructure when they are independent of a specific financial tool.

### General financial mathematics (`skatkis.financial_logic`)

Examples:

- rate and compounding conventions, and conversion between them;
- discount factors and accrual rates;
- calendar and month arithmetic;
- rating-scale normalisation.

Finance in general is the domain of `skatkis.financial_logic`: these are repeated across financial tools, so they are written and tested once there and consumed by each tool. The tool still decides which formula applies, to which columns and under which product rules.

### Tool-specific financial methodology

Examples:

- amortisation;
- PD and LGD transformations;
- expected credit loss;
- correlation and capital formulas;
- pricing and profitability;
- valuation;
- product-specific payment behaviour.

These belong in the owning tool.

A root-level registry module may contain financial logic when the registry is the deliberate extension point for pluggable behaviour. For example, a tool may use `product_types.py` to register product-specific schedule and payment functions while keeping generic schedule and cash-flow engines agnostic.

This is not a violation of separation of concerns. The registry isolates variability behind a stable interface and prevents generic engines from accumulating product-specific branches.

---

## 6. Contract-gated analytical architecture

Every material analytical stage must have an explicit interface.

### 6.1 Schema

`schema.py` defines:

- canonical columns;
- dtypes;
- required fields;
- defaults;
- probability and sign constraints;
- unique and join keys;
- ownership;
- derivation metadata;
- source schemas;
- layer input and output schemas.

No other module independently defines a conflicting canonical column contract.

### 6.2 Layer contracts

`contracts.py` binds schemas to executable layer interfaces. A contract normally declares:

- layer name;
- seed columns;
- input schema;
- output schema;
- output grain;
- immutable upstream inputs;
- required source-model joins.

The exact contract fields follow the current shared `skatkis` implementation.

### 6.3 Registry and hydration

The pipeline registry contains source models, contracts, and completed layer results. A downstream layer may start from a minimal key seed. Shared resolver infrastructure hydrates missing derivable inputs from registered sources and upstream outputs before validation.

### 6.4 Validation gates

Every layer has a pre-computation and post-computation gate.

The gates may enforce:

- required columns;
- no nulls in required data;
- probability bounds;
- positivity or non-negativity;
- unique grain;
- lookup coverage;
- valid registered products or strategies;
- domain-specific timing or consistency rules;
- formal output completeness;
- protection of upstream-owned values.

Exact gate numbering may evolve. The existence and purpose of both boundaries are mandatory.

Dtypes are not checked by the gates: source values are parsed and cast before validation by `cast_and_fill` (`skatkis.pipelines.utils`), which raises on a value it cannot convert.

**Engine.** Schema-driven gates run on [Pandera](https://pandera.readthedocs.io). The schema dict in each tool's `schema.py` remains the single source of truth: `skatkis.pipelines.validation.to_pandera_schema` translates its validating flags (`required`, `required_if`, `unique_key`, `probability`, `positive`, `non_negative`, `allowed_values`) into a Pandera schema, and `_validate_from_schema` runs it in lazy mode. One failing run therefore lists every violated rule, with the number of rows and up to five sample rows named by their unique-key values, as a single `SchemaValidationError` (a `ValueError`, with Pandera's `failure_cases` table attached). The translation keeps the earlier accept/reject behaviour exactly: nulls pass value checks unless the column is required, nothing is coerced, and unknown columns are allowed. To add a check, add schema metadata; never write a separate Pandera schema for a tool.

### 6.5 Calculation ownership

After hydration and input validation, a layer computes only the outputs it owns. A downstream layer consumes upstream measures read-only.

This prevents:

- duplicated formulas;
- inconsistent methodology;
- hidden lineage;
- difficult reconciliations;
- unstable refactors.

---

## 7. Product and strategy registries

Use a registry when a generic engine must support materially different behaviours.

A registry pattern contains:

- supported lowercase identifiers;
- immutable context objects or protocols;
- one callable per behaviour;
- mappings from identifier to callable;
- tests proving generic dispatch and product-specific outcomes.

A product may require multiple registries. For example:

- one registry for schedule construction;
- one registry for payment mechanics;
- one registry for a risk or correlation strategy.

The generic engine accepts a stable context and invokes the registered function. New products are added through registration rather than by modifying the engine.

This supports stable scalability because:

- the engine remains agnostic;
- product complexity stays isolated;
- exact and approximate implementations can coexist explicitly;
- new products do not destabilise existing orchestration;
- tests can target each registered behaviour independently.

Use a registry for behavioural differences. Use ordinary data or configuration for parameter differences.

---

## 8. Source models and client column mapping

External files rarely use canonical internal names. Source modules therefore own the translation from client data to the internal schema.

A source module should define:

- an identity default mapping;
- required lookup keys;
- value columns;
- optional segment dimensions;
- a mapping loader;
- source-specific transformation;
- a model class using the shared lookup-source abstraction.

The client mapping file translates source names to internal names. Computation layers must never know client column aliases.

A source may be:

- keyed, such as a PD model by rating band and period;
- segmented through additional mapped dimensions;
- broadcast, such as portfolio-wide economics assumptions;
- transformed from long to wide format;
- capable of deriving missing representations from supplied measures.

Source-specific transformations belong in the source module and must be covered by source tests.

---

## 9. Testing model

### 9.1 Production authority

Production modules are authoritative when updating unit tests. Existing tests provide structure and historical intent, but must not override current production behaviour without an agreed production defect.

If a contradiction exists:

1. identify the contradiction;
2. determine whether production or expectation is wrong;
3. change production only after explicit agreement;
4. otherwise update the test;
5. update documentation when methodology or interface changed.

### 9.2 Test ownership

- Shared `skatkis` tests own generic infrastructure.
- Source tests own source-specific mapping and transformation.
- Layer tests own formulas and layer-specific orchestration.
- Validation tests own domain gates.
- Contract tests own concrete interface integrity.
- Pipeline tests own execution order and registry feedback.
- Integration tests own cross-module behaviour.

### 9.3 Required coverage

Depending on the function, tests should cover:

- exact formulas;
- happy paths;
- zero and boundary cases;
- monotonic relationships where valid;
- event conditions;
- grouping isolation;
- recursion continuity;
- index alignment;
- registered and unregistered strategies;
- input non-mutation;
- output columns and grain;
- expected failure modes.

Use simple lowercase identifiers such as `a` and `b` in synthetic unit-test data unless a test specifically concerns identifier formatting.

### 9.4 Validation and integration

A unit test suite is not sufficient by itself. Before merge, run the configured:

- source tests;
- layer tests;
- schema tests;
- contract tests;
- validation tests;
- pipeline or integration tests;
- Ruff checks;
- formatter;
- type checks.

---

## 10. System governance

Stable scalability depends on controls around the calculation code.

The repository governance model combines:

1. **SOP control:** defines mandatory architecture and development practices.
2. **Schema control:** defines canonical data contracts and ownership.
3. **Contract control:** defines executable layer interfaces and grains.
4. **Validation control:** rejects invalid sources, inputs, joins, and outputs.
5. **Testing control:** proves owned behaviour and guards regressions.
6. **Documentation control:** explains implemented methodology, assumptions, limitations, and extension mechanisms.
7. **Methodology control:** distinguishes code refactoring from changes that require model-risk, accounting, regulatory, or other approval.

A feature is incomplete if code is changed without reviewing affected schemas, contracts, validation, tests, and documentation.

Methodology changes include changes to:

- financial formulas;
- timing conventions;
- PD or LGD treatment;
- floors;
- capital methodology;
- tax treatment;
- valuation discount rates or exponents;
- exact versus approximate calculations;
- stochastic assumptions.

Such changes require explicit review and must not be introduced as code cleanup.

---

## 11. Development workflow

### 11.1 Before coding

1. Read `Toolbox/SOP_Modular_Analytical_Tools.md`.
2. Read the target tool README.
3. Identify the owning production module.
4. Review the canonical schema and relevant contract.
5. Review the validation gate.
6. Review existing tests.
7. Determine whether the change is structural, behavioural, or methodological.
8. Identify required governance approval.

### 11.2 Implementing a change

1. Update canonical schema metadata if the interface changes.
2. Update the concrete contract if inputs, outputs, grain, immutability, or model joins change.
3. Update source mapping or registries where relevant.
4. Implement the calculation only in the owning module.
5. Update domain validation.
6. Add focused unit tests.
7. Run structural and integration tests.
8. Update the tool README.
9. Update the SOP or repository README only when the general architecture or governance standard changed.

### 11.3 Review checklist

Reviewers should verify:

- ownership is clear;
- generic infrastructure was not duplicated;
- the DAG remains explicit;
- source aliases do not leak into calculation layers;
- hydration and join coverage remain valid;
- registered behaviour remains complete;
- time-dependent operations are correctly sorted and grouped;
- approximation assumptions are documented;
- inputs are not mutated;
- tests match production;
- documentation matches active implementation;
- methodology approvals are complete.

---

## 12. First-time setup

### Step 1: Create a virtual environment

Create the environment outside the repository:

```powershell
python -m venv C:\Users\<your-username>\venvs\frm_env
```

### Step 2: Configure the VS Code interpreter

Update the local `.vscode/settings.json` interpreter path as required by the repository configuration:

```json
{
  "python.defaultInterpreterPath": "C:\\Users\\<your-username>\\venvs\\frm_env\\Scripts\\python.exe"
}
```

Do not commit a personal interpreter path if `.vscode/settings.json` is shared.

### Step 3: Select the interpreter

In VS Code:

```text
Ctrl+Shift+P
Python: Select Interpreter
```

Select the `frm_env` environment.

### Step 4: Run repository setup

```powershell
.\setup_env.ps1
```

The setup process should install pinned dependencies and configure repository hooks according to the current setup script.

### Step 5: Reload VS Code

```text
Ctrl+Shift+P
Developer: Reload Window
```

---

## 13. Client notebooks and scripts

Client analytical notebooks are stored as `.py` files using the repository’s configured Jupytext format where applicable.

Rules:

- commit `.py`, not `.ipynb`, unless repository policy explicitly changes;
- use clear cell delimiters such as `# %%`;
- include a top markdown cell describing purpose, client context, inputs, and outputs;
- keep reusable calculations out of the notebook;
- use the notebook or script to configure and invoke toolbox pipelines;
- do not bypass production validation for convenience.

---

## 14. Code style and static checks

Toolbox code is production code and must satisfy the repository’s configured formatter, linter, and type checks.

The authoritative settings are in `pyproject.toml` and repository tooling. Do not duplicate configuration values in code.

Typical manual commands are:

```powershell
python -m ruff check Toolbox tests --fix
python -m black Toolbox tests
```

Run the configured static type checker where applicable.

General requirements:

- use `snake_case` for variables, functions, and modules;
- use explicit names;
- use double quotes where configured;
- keep imports ordered;
- avoid unnecessary comments that repeat code;
- preserve production identifiers exactly;
- use NumPy-style docstrings for public toolbox APIs;
- document mathematical formulas and assumptions.

---

## 15. Pre-commit controls

The repository pre-commit hook runs configured quality checks before a commit is accepted.

Typical controls include:

- Ruff linting and safe fixes;
- formatting;
- rejection of unresolved failures.

If the hook modifies files:

1. inspect the changes;
2. rerun relevant tests;
3. stage the corrected files;
4. commit again.

Do not bypass the pre-commit hook to merge code that does not satisfy repository standards.

---

## 16. Dependency management

Dependencies are pinned according to repository policy in `package_versions.txt` or the active environment specification.

When adding or changing a package:

1. install the approved version in the development environment;
2. update the pinned dependency file;
3. run all affected tests;
4. review compatibility with production environments;
5. commit the environment change with the code that requires it.

Do not use unreviewed version ranges for production dependencies.

---

## 17. Reproducibility and auditability

Production analytical execution should be capable of recording:

- code version;
- dependency versions;
- source identifiers or hashes;
- configuration snapshot;
- execution timestamp;
- contract and schema version lineage where supported;
- layer row counts;
- gate outcomes;
- output identifiers or hashes.

Analytical functions must not depend on hidden global state. Dates, scenarios, seeds, thresholds, and assumptions must be explicit.

---

## 18. AI-assisted development

AI may assist with architecture, coding, testing, and documentation. AI output requires engineering review.

When using AI on an existing tool, provide or inspect:

- the production module;
- the companion schema;
- the concrete layer contract;
- relevant validation;
- existing tests;
- the tool README;
- the SOP where structural guidance is needed.

Use the following authority order:

```text
production modules
    > schemas and contracts
    > validation
    > current tests
    > tool README
    > SOP and repository README
    > historical examples
```

AI must report contradictions before generating a large replacement artefact. AI must not invent missing production behaviour, alter financial methodology to satisfy stale tests, or duplicate generic framework coverage inside tool tests.

Agent rules are kept in the repository so every session starts from the same standard:

| File | Purpose |
|---|---|
| `steward/instructions/AGENTS.md` | Rules for every agent in every role, always loaded: authority order, core principles, methodology versus refactor, prohibited behaviour and protected files, working rules and branches, Steward's personality, its five roles (index, secretary, developer, warden, guard) and the change lifecycle |
| `steward/instructions/developer.md` | The developer: documentation order and sources, planning a change to financial logic, design, commands, using Steward, coding conventions, building and finalising, and work on Steward's code |
| `steward/instructions/secretary.md` | The secretary, the only role that writes in `steward/`: layout, naming of changes, working on a change, how notes, changes and designs are kept, its duties, flow charts, and preparing the sign-off documents |
| `steward/instructions/warden.md` | The warden: what it is given, its checklist and its report |
| `steward/instructions/writing.md` | Rules for writing any file, shared by the developer and the secretary: writing for the reader, human-readable layout, renames and the trail |
| `steward/instructions/guard.md` | The Guard: how Claude Code is contained in the repository, the rules for tool calls that avoid needless prompts, and the Guard's checks; read only when the Guard runs (`/guard`) |
| `tests/guard/test_pre_bash_guard.py` | Penetration test of the shell guard: command strings checked as text, never executed; known gaps as strict `xfail` |
| `steward/instructions/CLAUDE.md` | Claude Code only notes (role loading, hooks, automatic rule loading, MCP restart); imports `AGENTS.md`. The root `CLAUDE.md` imports it; the root `AGENTS.md` points other agents to the instructions |
| `.claude/skills/developer/`, `.claude/skills/secretary/` | Claude Code skills that load a role's file, with `writing.md`, when a task needs that role |
| `.claude/agents/warden.md` | The warden as a Claude Code subagent with read-only tools (no Bash, Edit or Write) |
| `.claude/rules/*.md` | One summary per area (layers, schema, sources, accreditation, ...), loaded automatically for matching paths, each pointing to its SOP sections |
| `.claude/settings.json` | The security permissions below; blocks agent edits to accreditation inputs, reference files and client raw data; runs Ruff, Black and (if installed) pyright after every Python edit |
| `.claude/hooks/pre_bash_guard.py` | Asks the user before any shell command that names a path outside the repository or a protected file |

Agents should look up the repository through the component index (section 19) rather than reading many files.

### Security permissions for Claude Code

**Rule: Claude Code must not have access beyond this repository.** It works on the
repository's files only; the rest of the computer (the user profile, other folders,
credentials, SSH keys, browser profiles) is off limits. Guarding this boundary is not
optional: any change to the settings or hooks below needs the repository owner's
approval and must not weaken them.

The boundary is enforced in layers, each in `.claude/settings.json` unless stated:

| Layer | What it does |
|---|---|
| Working directory only | `blockReadsOutsideWorkingDirectories` refuses file reads outside the repository; no additional directories are granted, and reading or editing the home directory (`~`) is denied outright |
| Edits inside the repository | Accepted without a prompt in the "Edit automatically" mode; edits elsewhere ask the user. The command-line Claude Code takes the mode from `defaultMode: acceptEdits`; the VS Code extension ignores a project's settings for its starting mode, so each user sets `"claudeCode.initialPermissionMode": "acceptEdits"` in their VS Code user settings |
| Protected files | Edits to accreditation inputs (`scenario_inputs.json`), legacy records (`legacy_records.json`), legacy parity files, macro-enabled workbooks (`*.xlsm`), client `raw_data`, and a tool's user-test seed and corrupted export (`ui_test/seed.json`, `ui_test/corrupted/`, written only by the user's refresh) are denied; edits to accreditation fixtures, a tool's accreditation `examples.py` (it holds the informal-check reference values) and `compare.py` ask the user |
| Shell | Bash runs without a prompt; the shell guard `.claude/hooks/pre_bash_guard.py` reads the command as Bash would (words split outside quotes, quotes removed, braces expanded) and asks the user first when it names an edit-denied protected file (also through quotes, brace expansion or a wildcard, which it expands against the repository only) or the user-test refresh that writes the seed and export (`ui_test.refresh`, which the user runs outside Claude Code), a parent directory (`..`), the home directory or a user folder (`~`, `~-`, `$HOME`, `$USERPROFILE`, `%APPDATA%`, `$TEMP`, `$PROGRAMDATA`, `$ONEDRIVE`, `%WINDIR%`, `$env:` variables, `expanduser`, `Path.home(`, a bare `cd`, `cd -` or `pushd`), an absolute path outside the repository (a drive path or drive-relative path such as `D:notes.txt`, a POSIX drive or system root such as `/c`, `/home`, `/etc`, `/tmp`, `/opt`, Git Bash's own folders, a wildcard at the root such as `/*`, the bare root `/`, a network path `\\server\share`, or a `file://` URL to any of these), Git's user or system configuration (`git config --global`, `--system`), or starts PowerShell. It asks when it cannot read or check a command or the command expands too far, and the command is blocked if the guard itself fails. It needs Python 3.10 or later. Its known gaps are the strict `xfail` cases in `tests/guard/test_pre_bash_guard.py`. Claude Code's own built-in checks still ask for some commands (for example a chained `cd`, some `python -c` one-liners, any write in `.claude/`), whatever the guard decides. The PowerShell tool is denied |
| Modes | Auto mode and bypass-permissions mode are disabled |
| Internet | Web search and web fetch are allowed, for looking up official sources. They are allowed in the shared `.claude/settings.json`; if a user is still asked for them, the same rules go in their own `.claude/settings.local.json` (git-ignored): `{"permissions": {"allow": ["WebFetch", "WebSearch"]}}`. `skipWebFetchPreflight` is on: Claude Code does not first check a fetched domain against Anthropic's blocklist, so the user's review of what is fetched is the control |
| MCP | Only the repository's own server, Steward (`skatkis-steward`, read-only), is enabled; claude.ai connectors are disabled |
| Data sent to Anthropic | Telemetry, error reporting, feedback and surveys, Artifacts publishing, Remote Control and other non-essential traffic are switched off |

**What these controls do not do.**

- They are permission rules inside Claude Code, not an isolation boundary. Claude
  Code's sandbox does not run on native Windows, so it is switched off.
- The shell guard checks the command text (listing the repository only to expand a
  wildcard) and returns "allow" for any command it does not match. By design it cannot catch a path a command builds at run time, a
  repository script that itself reads outside the repository (`pytest` runs test code),
  or network egress through Bash (`curl` uploads, `git push`, `pip install`). Any
  pattern gap found is listed as a strict `xfail` case in
  `tests/guard/test_pre_bash_guard.py` until the guard is fixed. These rely on the agent
  rules (`AGENTS.md`, "No access beyond the repository"), the deny rules above and the
  user's review.
- Whatever Claude Code reads is sent to Anthropic to produce its answers. Whether that
  content may be used for training is set by the Anthropic account or contract, not by
  this repository: use an account under commercial terms, or one with model training
  switched off in its privacy settings.
- With internet access on, anything Claude Code can read could in principle be sent
  elsewhere. The repository contains client data under `Clients/`, so the boundary
  above and the user's review of every prompt matter.
- A user can change project settings. On managed machines the same rules should be
  deployed as managed settings, which users cannot override.

**Planned ring-fence.** Claude Code will move from the developer's laptop to a
dedicated virtual machine, once NITSO has approved its use. The virtual machine
becomes the isolation boundary, with outbound traffic limited to the services Claude
Code and the repository need, and these settings deployed as managed settings.

---

## 19. Component index and MCP server (`skatkis.steward`)

### 19.1 What it is

`skatkis.steward` (the MCP server is called Steward, id `skatkis-steward`; skatkis means treasure chest, and Steward knows what is in it) is a read-only index of the repository's analytical components and its governing documents, served to AI assistants through the Model Context Protocol (MCP). MCP is an open standard that lets an assistant such as Claude Code call tools provided by a local program and get structured answers back, instead of reading and interpreting files itself.

The server is called Steward. Its role in development, including the change logs and tool notes it keeps, is set out in SOP §22.5. `steward/steward.md` is its governing description (purpose, controls, hosting, access and decision log); this section is the technical reference.

The index answers the questions asked before any change: *what exists, who owns it, how is it called, which rules apply, and how should new code be structured?* For example:

- Which layer owns `economic_capital_requirement`, and who consumes it?
- What does the `exposure` layer need as input, and what does it produce?
- Which rules and SOP sections apply before editing `risk_metrics.py`, and is the file protected?
- I want to add a new source: which files do I touch, which existing source do I copy, where do the tests go?
- What does the tool README say about adding an economics instrument?
- Where do the docstrings disagree with the code?

There is no database. The index is built in memory each time the server starts, from the repository itself.

### 19.2 How it works

```text
repository files                    skatkis.steward                         assistant
─────────────────                   ───────────                         ─────────
module docstrings ──┐
function signatures ┤  ast (not run)
                    ├────────────▶ index.py ──▶ server.py ──(MCP, stdio)──▶ Claude Code
pipeline class ─────┤  import         │  ▲        │
  DAG, sources,     │                 │  │        └─ uses the `mcp` package for the protocol
  contracts,        │                 │  └─ planning.py assembles plan_change from the index
  column owners,    │                 │
  registries        │                 └─ docstrings.py parses docstrings into sections
.claude/rules ──────┤
SOP, READMEs ───────┤  numbered sections
steward/instructions/AGENTS.md ──┤
settings.json ──────┤  protected-file patterns
tests/ file names ──┘
```

| Module | Role |
|---|---|
| `Toolbox/skatkis/steward/docstrings.py` | Splits each docstring into header, summary and sections (`Owns`, `Must not`, `Public API`, ...) |
| `Toolbox/skatkis/steward/index.py` | Builds the index and provides the query functions; the actual library |
| `Toolbox/skatkis/steward/planning.py` | Assembles a change plan (`plan_change`) from the index and the SOP |
| `Toolbox/skatkis/steward/server.py` | Thin MCP adapter: registers each query as a read-only tool |

Two kinds of facts are combined and kept apart in every answer by a `provenance` field:

- **From code (authoritative):** the DAG, source models, layer contracts, column ownership metadata (`owned_by` in each `schema.py`), product registries and report checks. Contracts that are built per run (economics, portfolio metrics) are read from a registry built from the tool's frozen accreditation inputs. No layer is run.
- **From documentation (explanatory):** module and function docstrings, the agent rules, and the numbered sections of the SOP, this README and each tool's README. Headings are parsed down to `####` (e.g. `19.6.1`); headings inside code blocks are ignored.

The index also reads the `Edit(...)` patterns in `.claude/settings.json`, so every answer about a file says whether agents may edit it (`deny`, `ask` or not protected), and the names of the test files, so plans can say where tests go.

Where the two disagree, the code is trusted (SOP §22.1) and `health` reports the contradiction. This is why docstrings follow one structure (`.claude/rules/docstrings.md`): they are the explanatory content of the index.

### 19.3 What it can and cannot do

| It does | It does not |
|---|---|
| Read `Toolbox/`, `steward/instructions/AGENTS.md`, `.claude/rules/`, the SOP, the READMEs, the Markdown files in `steward/`, `.claude/settings.json` and test file names | Read `Clients/` or any client data; paths under `Clients` are rejected |
| Return schema metadata (dtype, flags, defaults, ownership) | Return data values |
| Label components `available` or `active` | Describe anything as accredited; sign-off is a governance record (SOP §19.2) |
| Report the git commit every answer was built from | Run pipelines, override inputs or write files |
| Plan a change: steps, files, an example, tests, rules | Write or generate code; the agent writes it and normal review applies |
| Report docstring gaps and contradictions | Edit anything; protected files stay protected |

### 19.4 Tools and resources

| Tool | Answers |
|---|---|
| `find_calculation(concept)` | Which function already calculates a financial concept (from `Computes` docstring sections), and whether it is `shared` (reuse it), `tool_only` (promote it to `skatkis.financial_logic` first) or `missing` |
| `list_components(tool, kind)` | What modules, layers, sources, report checks and registries exist, with summary and status |
| `describe_module(name)` | Docstring sections, public symbols, status, applicable rules, SOP sections and contradictions of one module |
| `describe_symbol(name)` | Signature and full docstring of a function, class, method or constant |
| `describe_layer(name)` | Contract, DAG and registry positions, upstream and downstream layers, `Owns` and `Must not` |
| `find_owner(column)` | Owning source or layer, producing and consuming layers, immutability |
| `describe_column(column)` | Schema metadata of a column and its owner (never values) |
| `list_products(tool)` | Supported product and strategy identifiers and their registered functions |
| `rules_for(path)` | Full text of the rules that govern a file, their SOP sections, and whether the file is protected |
| `plan_change(kind, name, tool, like)` | A plan for new code that fits the architecture (section 19.6) |
| `sop_section(ref)` | Text of one SOP section, e.g. `15.9`, or a chapter, e.g. `15` |
| `readme_section(name, ref)` | One numbered README section (`name` is `repository`, a tool name, or `steward` for `steward/steward.md`); without `ref`, the table of contents |
| `document(path, section)` | A configured Markdown document that is not a numbered README (Steward's registry and change files, design notes); without `section`, its table of contents and full text |
| `list_documents()` | Every rule (and the paths it governs), SOP chapter and README section with its resource URI, plus the protected-file patterns |
| `search(query)` | Text search over code (names, docstrings) and documents (rules, SOP and README sections) |
| `health()` | Docstring gaps and docstring/code contradictions |
| `rebuild_index()` | Re-read the repository after files change |

The server has two profiles. `full`, the default over stdio, serves every tool above. `lookup`, the default over HTTP, serves only the questions people ask before writing code: `find_calculation`, `search`, `list_components`, `describe_module`, `describe_symbol`, `describe_layer`, `find_owner`, `describe_column`, `list_products`, `sop_section`, `readme_section`, `document` and `list_documents`.

Documents an assistant can attach directly: `skatkis://agents` (`steward/instructions/AGENTS.md`) and `skatkis://rule/<name>` (e.g. `layers`), which are listed resources, plus `skatkis://sop/<ref>` (e.g. `4.7`), `skatkis://readme/<name>/<ref>` (e.g. `fair_value/19.6` or `steward/9`), `skatkis://module/<dotted.name>` (a module docstring) and, listed, `skatkis://doc/<path>` for each configured document (e.g. `steward/toolbox/skatkis/CHANGELOG.md`).

### 19.5 Using it

**Setup.** The server is registered in `.mcp.json` and started by Claude Code as `python -m Toolbox.skatkis.steward.server` from the repository root. It needs the project venv active (Python 3.14, with the pinned `mcp` package from `package_versions.txt`). The first time Claude Code opens the project it asks for approval to start the `skatkis-steward` server.

**In a session.** Ask in plain language; the assistant chooses the tool. Typical uses:

- before writing new code: `plan_change(kind, name)`;
- before writing a financial calculation: `find_calculation(concept)`, and reuse a shared function rather than writing a new one;
- before editing a file: `rules_for(path)` and `describe_module(path)`, then the listed SOP sections;
- when tracing a number: `find_owner(column)` and `describe_layer(name)`;
- when looking for guidance: `search(query)`, `readme_section`, `sop_section`;
- after editing files: `rebuild_index()`. Changes to the server's own code need a restart of the server (restart Claude Code).

**Reading an answer.** Every answer contains `commit` and `dirty` (whether there were uncommitted changes). Check `provenance` to see whether a fact came from code or from a docstring. A `registry_position` that differs from `dag_position` means code that walks the registry sees layers in a different order than the DAG runs them.

**Without an assistant.** The same queries can be called from Python:

```python
from Toolbox.skatkis.steward import index as ix
from Toolbox.skatkis.steward import planning

idx = ix.build_index()
ix.find_owner(idx, "ecl")
ix.health(idx)["counts"]
planning.plan_change(idx, "source", "collateral_model")
```

**Over HTTP (Microsoft 365 Copilot in Teams).** `python -m Toolbox.skatkis.steward.server --transport http --host 0.0.0.0 --port 8000` serves the `lookup` profile at `/mcp` (pass `--profile full` to serve every tool). Every HTTP request must carry the API key from the `STEWARD_API_KEY` environment variable in the `X-API-Key` header, and the server will not start over HTTP without a key (`--no-auth` for local testing only). Anyone who can sign in to Teams with a company account may use Steward; the key keeps the hosted endpoint from being queried outside Copilot (`steward/steward.md` §9). A Copilot Studio agent adds the server as an MCP tool and is published to Teams; the container image and deployment pipeline are described in `steward/steward.md` §7–8. The hosted copy answers for the commit it was deployed from; redeploy to pick up changes, since `rebuild_index` is not served.

**In CI.** `python -m Toolbox.skatkis.steward.server --dump index.json` writes the health report and component list, and exits with 1 if a configured tool could not be read.

### 19.6 Planning new code (`plan_change`)

`plan_change(kind, name)` turns the architecture into a concrete plan before any code is written. `kind` is one of:

| Kind | For | Procedure quoted |
|---|---|---|
| `layer` | a new analytical stage | SOP §9 |
| `source` | a new input table or lookup model | SOP §6 |
| `product` | a new product, payment type or strategy in a registry | SOP §10.5 |
| `report_check` | a new post-run report check | SOP §13.6 |
| `tool` | a new analytical tool | SOP §23 |
| `other` | anything else; describe it in `name` (e.g. `"economics instrument"`) | SOP §19.3 |

The answer contains:

- `steps`: the ordered steps for that kind, each with its SOP reference;
- `procedure`: the governing SOP section, quoted;
- `files`: every file to create, edit or review, with why, the rules that govern it and whether it is protected (`ask` means edits need approval; for example, a new product's accreditation scenarios);
- `example`: an existing component of the same kind to copy, chosen as the one with the most complete docstring (or the one named in `like`), with its `Owns`, `Must not`, `Public API` and signatures;
- `tests`: where the new tests go (next to the example's tests) and which existing tests to extend;
- `readme_guides`: the tool README's own extension guides that match (for example *Add a source*), quoted;
- `context`: the current state of the relevant part of the tool (DAG and registry order, sources, registries, report checks);
- `methodology`: whether the change is a methodology change needing approval and possibly re-accreditation (SOP §12.5, §15.9);
- `warnings`: for example, a name that already exists or does not follow naming conventions.

Everything comes from the index: the procedure from the SOP, files from the standard module names (SOP §3.3), contract modules from the code that constructs `LayerContract(...)`, registries and report checks from configuration, and guides from the tool README. No tool's domain is written into `skatkis`. Tool READMEs stay useful to the planner when their extension guides keep titles that start with "Add ...".

A plan is guidance only. The agent still writes the code, under the same rules, hooks and approvals.

### 19.7 Health checks

`health()` reports:

| Issue | Meaning |
|---|---|
| `missing_header`, `missing_section` | A module docstring lacks the path header or a required section |
| `unresolved_public_api` | A name listed under `Public API` is not defined anywhere in the indexed code |
| `unresolved_computes` | A `Computes` entry names a function that its own module does not define (the module that calculates a concept owns the function) |
| `must_not_vs_outputs` | A layer's `Must not` section names one of its own outputs |
| `registry_order` | Registry contract order differs from DAG order (SOP §8.5) |
| `tool_error`, `index_error` | A configured tool or a file could not be read |

The checks are deliberately conservative: they do not yet compare `Owns` sections with contract outputs, so a docstring can still claim a column the layer does not formally produce.

### 19.8 Adding a tool or changing the configuration

The index is configured in `pyproject.toml`, so `skatkis` code never names a tool:

```toml
[tool.skatkis.steward]
index_paths = ["Toolbox/skatkis", "Toolbox/fair_value"]
exclude = ["Toolbox/SandBox"]

[[tool.skatkis.steward.tools]]
name = "fair_value"
pipeline = "Toolbox.fair_value.pipeline:FairValuePipeline"
fixture = "Toolbox.fair_value.accreditation.fixtures.scenarios:load_runs"
registries = ["Toolbox.fair_value.product_types"]
```

To index a new tool, add its folder to `index_paths` and a `[[tool.skatkis.steward.tools]]` entry. `fixture` should point at the tool's frozen accreditation inputs; without it, contracts and columns for that tool are not available. The tool's README is found as `README.md` in its package folder (override with `readme = "..."` on the tool entry). No new module is needed in the tool.

Optional top-level keys, with their defaults: `readme = "README.md"`, `settings = ".claude/settings.json"`, `tests_dir = "tests"`, `sop`, `rules_dir` and `agents`.

Documentation that is not a tool README is added with two more keys. `readmes` names further numbered READMEs (`readmes = { steward = "steward/steward.md" }`), served by `readme_section`. `documents` lists Markdown files or folders (`documents = ["steward"]`); each file is split at its headings and served by `document`. Paths under `Clients` are rejected.

`plan_change(kind="tool", name=...)` lists these steps for a new tool.

### 19.9 Tests, design and future work

- Tests: `tests/skatkis/steward/` (parser, index, documents, planner and server on a synthetic repository, through a real MCP client) and `tests/fair_value/test_steward_index.py` (the configured tool loads).
- Governing description and decision log: `steward/steward.md`.
- Planned changes: `steward/toolbox/skatkis/CHANGELOG.md`, one row per change, each with its own file in `steward/toolbox/skatkis/changes/` (description, approach, kickoff prompt). Changes are discussed and agreed before any code is written; tests and documentation follow once the result is accepted (`steward/instructions/AGENTS.md`). Steward indexes the registry, so `document("CHANGELOG.md")` or `search` answers what is planned.

---

## 20. Contributing a new analytical tool

Before writing calculation code:

1. define the analytical question;
2. identify sources and assumptions;
3. define entity and time grain;
4. identify recursive state;
5. identify lookup models;
6. identify product or strategy variability;
7. decide whether variability belongs in configuration, a schema factory, or a behaviour registry;
8. define canonical source schemas;
9. define layer input and output schemas;
10. define ownership and derivation metadata;
11. define concrete contracts;
12. define validation gates;
13. define the DAG;
14. define the test plan;
15. create the tool README.

Read `Toolbox/SOP_Modular_Analytical_Tools.md` for the complete standard.

---

## 21. Definition of done

A repository change is complete only when applicable controls are satisfied:

- production ownership is clear;
- schemas are current;
- contracts are current;
- source mappings are current;
- registries are complete;
- hydration paths resolve;
- validation gates pass;
- unit tests cover owned behaviour;
- integration tests pass;
- lint, formatting, and type checks pass;
- documentation is updated at the correct level;
- methodology approval or accreditation is documented where required;
- no client-specific reusable logic was introduced into `Clients/`;
- no shared infrastructure was unnecessarily duplicated in a tool.

---

## 22. Final principle

The repository exists to turn analytical methodology into controlled systems.

A production-ready analytical system requires more than a correct formula. It requires:

- explicit ownership;
- canonical schemas;
- executable contracts;
- controlled source normalisation;
- registry-driven hydration;
- product-agnostic engines;
- registered pluggable behaviour;
- validation gates;
- focused tests;
- reproducible execution;
- current documentation;
- disciplined model governance.

Read the SOP before contributing to `Toolbox/`, and read the relevant tool README before changing a tool.
