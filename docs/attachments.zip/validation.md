---
paths:
  - "Toolbox/*/validation.py"
  - "Toolbox/skatkis/pipelines/validation.py"
  - "Toolbox/*/report_checks.py"
  - "Toolbox/skatkis/pipelines/report*.py"
---

# Validation and reporting (SOP §4.3, §13)

- Tool-specific gates and business rules live in the tool's `validation.py`; generic
  assertions live in `skatkis.pipelines.validation`. Layers call gates, they do not
  implement ad hoc checks (§13.1).
- Prefer schema-driven checks (§13.2); use named domain functions for rules metadata
  cannot express (§13.3), such as join coverage (§7.4).
- The schema dict is the source of truth; Pandera is only the engine. Add or change a
  check by adding schema metadata and, for a new flag, extending `to_pandera_schema` in
  `skatkis.pipelines.validation`. Never write a separate Pandera schema for a tool.
- Changing what the gate accepts or rejects (e.g. rejecting NaN in a bound check) is a
  behaviour change: run the accreditation tests and say so. The translator's tests and an
  accept/reject comparison against the previous gate are the evidence for a refactor.
- Failure messages state context, rule, columns, affected row count, sample keys and the
  expected constraint (§13.4). Fail fast (§13.5).
- No hydration, calculation, file IO or orchestration in validation modules.
- Reporting (§13.6) is post-hoc and non-blocking: a check is `(registry) -> list[Notice]`
  read from the finished registry, never re-running pipeline logic. Domain checks live in
  the tool (`report_checks.py`); the engine in `skatkis.pipelines.report` stays
  domain-agnostic. A condition that must block belongs in validation, not a report check.
