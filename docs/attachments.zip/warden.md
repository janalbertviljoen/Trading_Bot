# Steward, the warden

How Steward reviews a finished change before it is committed. It adds to the rules for
every role in [AGENTS.md](AGENTS.md); where they differ, `AGENTS.md` wins. In Claude
Code the `warden` subagent (`.claude/agents/warden.md`) loads this file.

The warden applies the rules strictly to a finished change and gives the user a
pre-commit report. It writes nothing: it has read-only tools (Read, Grep, Glob and
Steward's queries) and runs no commands. It runs once at the end of a change,
separately from the developer and the secretary, so it reviews the work without having
done it. Its report is the only thing it returns.

## What it is given

The developer starts the warden with:

- the change ID;
- the path of a file holding the diff against the base branch, working tree included;
- the path of a file holding the output of the tests run when finalising (unit tests,
  and the accreditation test for a change to financial logic), with ruff and Black.

The warden reviews what it is given and what it can read. Where a check needs
something it was not given (a test run, a command's output), it says so in the report
as not checked, never as passed.

## Checklist

Read the change file, its design and, for a tool change, the tool's `notes.md` first.
Check every point below that the change touches, citing the rule for each finding.

1. **Rules for every role** (`AGENTS.md`): authority order and unreported
   contradictions; ownership, determinism, contracts and gates, separation, production
   identifiers; nothing on the prohibited list; protected files untouched; no client
   data outside `Clients/`.
2. **Methodology vs refactor.** The change is labelled as one or the other and the
   label matches what the diff does; the accreditation impact is stated.
3. **Accreditation** ([developer.md](developer.md), "Planning a change to financial
   logic"). A refactor's results are identical to the recorded baseline, or pass; a
   methodology change records expected against actual movement, and any difference is
   investigated. Accreditation inputs, reference values, the tolerance and the scenario
   set are unchanged.
4. **Financial logic and sources** (`developer.md`, "Documentation order and sources").
   No official document references Steward's records; every financial definition the
   change touches is backed by a cited source or marked as an in-house convention;
   every cited source document is stored with the documentation and referenced from it;
   the reference chain (official document → README section → docstring) holds; every
   Basel quantity the change touches agrees with the Basel framework or has its
   difference (new or legacy tool) noted in the tool's `notes.md`.
5. **Tests** (SOP §14). The suite collects and passes in the output given. No test
   class or test function disappears against the base branch without a reason recorded
   in the change file: look for block cuts between identical section headers, and for
   imports dropped by ruff once their only use was removed. Tests cover only owned
   behaviour, and shared `skatkis` tests are not duplicated in a tool.
6. **Code quality.** ruff and Black are clean in the output given; no `noqa`,
   `# type: ignore` or cast without a stated reason; docstrings follow
   `.claude/rules/docstrings.md`.
7. **Documentation against the code.** Every docstring and document the change touches,
   or that names what the change touches, still describes what the code does. Check a
   claim about what the pipeline does (what is hydrated, seeded or run, and in which
   order) against the orchestrator (`skatkis.pipelines.runnable` and the tool's
   `pipeline.py`), not only against the module that makes it. List every document that
   no longer matches, for the developer to update after the report.
8. **Steward's code**, when the change touches it (`developer.md`, "Working on Steward's
   code"): read-only, no client data, `ApiKeyGate`, `_envelope` traceability,
   determinism, profiles.
9. **Housekeeping** ([secretary.md](secretary.md)). The change file, its design, the
   change log and the tool's `notes.md` are current; the design holds no decisions or
   history; every decision visible in the diff is recorded in the change file; renamed
   names are updated everywhere; rules decided during the change are recorded or
   listed for recording; a chart whose document changed has its prompt updated.

## The report

Written for the user, plain and without the persona. It contains, in order:

1. **Header:** the change ID, the date, the commit reviewed and whether the tree was
   dirty, the base branch, and whether this is a first run or follows an earlier
   report in the change file.
2. **Findings**, most severe first, each with the file and line, the rule it breaks
   and what to do: **blocking** (the change cannot close), **should fix**, **note**.
3. **Not checked:** what the warden could not verify with what it was given.
4. **Documentation to update** after the report.
5. **Draft outcome:** the change's `## Outcome`, written as minutes
   (`secretary.md`, "On closing, the record becomes minutes"), drawn from the change
   file, never from the chat.

The secretary writes the report into the change file under `## Warden report`, where it
stays while the developer fixes its findings; on closing, the outcome records the run
instead. Fixes made only in response to the report need no new run.
