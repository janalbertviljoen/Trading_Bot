---
paths:
  - "Toolbox/skatkis/pipelines/ui.py"
  - "tests/skatkis/pipeline/test_ui.py"
---

# Pipeline UI layer (SOP §17)

- `skatkis.pipelines.ui` is the only interface between a completed pipeline and its
  consumers. It is generic: it imports no domain pipeline, schema, model or contract
  (§17.1). Works for anything satisfying `RunnablePipeline` (§17.2).
- Groups (§17.3): overrides (`override_column`, `override_columns`), solver
  (`solve_column`), introspection (`describe_column`, `list_input_columns`), summaries
  (`build_summary`, `build_display_summary`, `build_scenario_summary`,
  `map_column_values`, `convert_date_columns`).
- Behavioural contract (§17.4): completed pipelines only; never mutate the input pipeline
  or registry; no deep copies (use `PipelineRegistry.clone_with_override`); rerun from the
  earliest affected layer; overrides apply at the declared source, never to computed
  outputs; validation comes from `skatkis.pipelines.validation`; display helpers never
  change values.
- Override and solver results are what-if runs, not accredited (§17.5).
- Display maps (`column_map`, `value_map`) are tool configuration, not part of `ui`
  (§17.7). Test `ui` once with synthetic pipelines; real `scipy` or patch `newton` in the
  `ui` namespace.
