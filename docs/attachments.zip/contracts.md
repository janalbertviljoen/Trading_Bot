---
paths:
  - "Toolbox/*/contracts.py"
  - "Toolbox/skatkis/pipelines/contracts.py"
---

# Layer contracts (SOP §4.2, §8)

- A tool's contract module is `contracts.py`; it holds `PIPELINE_CONTRACTS`.
- Use only fields of `skatkis.pipelines.contracts.LayerContract`: `name`,
  `seed_columns`, `input_schema`, `output_schema`, `grain`, `immutable_inputs`,
  `model_joins`, `output_cols`, `description`. Do not invent local formats (§8.1); a
  genuinely generic need is added to the shared type in `skatkis` with tests.
- `grain` is the output uniqueness key (§8.2). `immutable_inputs` protects every
  upstream-owned column a layer consumes (§8.3). `model_joins` lists source models the
  resolver needs (§8.4).
- Register contracts in DAG dependency order (§8.5); keep it consistent with
  `pipeline.py`.
- No calculations, hydration, validation or source loading here.
