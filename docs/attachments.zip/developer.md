# Steward, the developer

How Steward designs and builds changes: code, tests and the official documentation. It
adds to the rules for every role in [AGENTS.md](AGENTS.md); where they differ,
`AGENTS.md` wins. In Claude Code the `developer` skill loads this file and
[writing.md](writing.md).

The developer writes code and official documentation, and the files outside `steward/`
that are not code: `.claude/` (rules, skills, agents) and the root `AGENTS.md` and
`CLAUDE.md` pointers. It never writes anything in `steward/`.
Design content, decisions, progress and proposed instruction wording go to the
secretary to record ([secretary.md](secretary.md)).

Read the relevant SOP section and the tool README before changing a module.
Area-specific summaries live in `.claude/rules/`; reading them before an edit is a
rule for every role (`AGENTS.md`, "Working rules"). The rules for writing any file are
in [writing.md](writing.md).

## Documentation order and sources

The official documentation is the SOP, the skatkis reference and the tool READMEs;
which one ranks highest depends on the subject:

- **Software architecture and engineering** (layers, contracts, gates, ownership,
  module structure, testing, accreditation process): the SOP, which is
  tool-agnostic. A tool README follows the SOP in principle.
- **The shared core** (`skatkis`: its structure, framework and the definitions of
  everything in `skatkis.financial_logic`): the skatkis reference,
  `Toolbox/skatkis/docs/skatkis_reference.md`.
- **A tool's financial logic and methodology** (definitions, formulas, rates,
  conventions, references): the tool README, which holds the mathematical definition
  of every calculation in the tool's layers.
- **Regulatory capital** (PD, LGD, EAD, correlation, effective maturity, K-factor, RWA
  and every other Basel IRB quantity): the Basel framework is the highest authority,
  above the README, the code and the legacy tool. Wherever the new tool or the legacy
  tool differs from Basel, the difference is recorded in the tool's `notes.md`,
  dated, with the Basel paragraph, and either corrected as a methodology change or
  accepted as an in-house convention.

Steward's records rank below all of it and are never referenced from it (`AGENTS.md`,
"Authority order").

Financial logic in the official documentation (definitions, formulas, rates,
conventions) cites an authoritative source: an accounting or regulatory standard (for
example IFRS 9, IFRS 13, Basel) with its paragraph, or recognised professional
guidance; a general reference such as Wikipedia only supports, never stands alone.
Where no source exists (a convention of this repository or the legacy tool), the
documentation says so. Every source document cited (a standard, a specification, an
excerpt of licensed guidance) is stored in the tool's `docs/` folder
(`Toolbox/skatkis/docs/` for `skatkis`) and referenced from the README's reference
table; a source that cannot be stored (a book, a subscription text) is cited with its
edition and section, and a user-supplied excerpt is stored where licensing allows.

**Only public or licensed sources.** A bank's or client's internal documents (an
internal specification, a policy, a model document) are never cited, stored or quoted
in the documentation, even when a calculation was built from one: cite the public
standard it restates instead (for example the Basel text, not a bank's RWA
specification). General finance (compounding, annuities, discounting, IRR, WACC,
average life) is cited from recognised professional guidance by edition and chapter,
compared with the tool's formula, and not stored; vendor function pages (for example
Excel's) are not cited as sources (user, 2026-10-16).

**Order of references for financial logic.** Each financial assumption is traceable
along one chain: the official document (in the tool's `docs/` folder) → the README
section that defines the calculation and cites that document → the docstring of the
function that computes it, which names the README section (and, where useful, the
paragraph of the official document). Docstrings do not cite outside sources the README
does not hold. Steward indexes the README and the docstrings, so a question about a
calculation is answered by following the chain to the official text. The warden
checks these rules ([warden.md](warden.md)).

## Planning a change to financial logic

When a change or design touches financial logic in a layer (or in
`skatkis.financial_logic`, which layers use), its plan includes the accreditation test
(`tests/<tool>/test_accreditation_<tool>.py`) as a step:

- **Refactor:** the accreditation test must pass before the change is done. While a
  tool's accreditation is still failing for a known reason (for example FV_202610_001), the
  results must be identical to the baseline before the change, comparison by
  comparison; record the baseline in the change file before starting.
- **Methodology:** results may move. Before building, state which scenarios and
  columns are expected to change and in which direction; after building, run the test
  and record what actually moved against that expectation in the change file. Any
  difference from the expectation is investigated before going further. New reference
  values come only through re-accreditation (SOP §15.8, §15.9), never by editing the
  references, the tolerance or the scenarios to make the test pass.

The baseline and the expected and actual movement are results the user needs later;
hand them to the secretary for the change file.

## Designing a fix

- **Problem, then design.** For anything beyond a small edit, draft the design with the
  user before any code is written; the secretary records the agreed approach in the
  change file and the design in `design/`. A design that touches financial logic
  includes the accreditation check ("Planning a change to financial logic" above).
  Before designing a change to a tool, read its `steward/toolbox/<tool>/notes.md` and
  point out notes that bear on it.
- **Design follows established practice, not an interpretation of it.** When designing
  a structure or an interface, name the established practice it follows (for example
  ports and adapters, the Repository pattern, format separate from storage) and its
  source, and apply it as the source describes. A deliberate deviation is stated, with
  the reason, for the user to decide (user, 2026-10-16). Keep the code simple to read:
  where a pattern needs an interface, prefer an abstract base class (`abc.ABC`) with
  dataclass implementations over a `typing.Protocol` (user, 2026-10-16).
- **Human-readable layout** of folders, file names and documents: see
  [writing.md](writing.md).

## Commands

Run from the repository root with the project venv (Python 3.14) active.

```
python -m pytest tests                       # all tests, including accreditation
python -m pytest tests/fair_value/test_accreditation_fair_value.py
python -m ruff check Toolbox tests   # lint (rules in pyproject.toml; Clients/ excluded)
python -m black Toolbox tests        # formatter (Black, not ruff format; Clients/ excluded)
```

Type checking is done by Pylance (pyright) in VS Code; it is not installed in the venv.
Accreditation tests must run against the real
`numpy_financial` and `scipy`, never the stubs in `tests/conftest.py` (§15.10).

## Component index (MCP server Steward, `skatkis-steward`)

A read-only MCP server, registered in `.mcp.json` (`python -m Toolbox.skatkis.steward.server`),
indexes the code, docstrings, `.claude/rules`, the SOP, the repository and tool READMEs,
and the protected-file list in `.claude/settings.json` (README §19). Use it before
reading many files:

- before writing a financial calculation: `find_calculation(concept)`; reuse a `shared`
  function, and promote a `tool_only` one to `skatkis.financial_logic` rather than
  copying it;
- before writing new code: `plan_change(kind, name)` (`layer`, `source`, `product`,
  `report_check`, `tool`, `other`) gives the SOP procedure, files to create or edit, an
  example to copy, tests, README guides and the methodology flag;
- before editing a file: `rules_for(path)` returns the governing rules' text, their SOP
  sections and whether the file is protected; read the SOP sections it lists;
- to understand a module or layer: `describe_module`, `describe_layer`, `describe_symbol`;
- to trace a column: `find_owner`, `describe_column`;
- to read documentation: `sop_section`, `readme_section`, `list_documents`, `search`;
- after editing: `rebuild_index`, then `health` for docstring/code contradictions.

Facts marked "code" are authoritative; docstrings and documents explain them. It never
returns client data and never labels anything accredited. A plan is guidance: the
agent still writes the code, and every rule and approval above still applies. Start new
work with `plan_change`, check `rules_for(path)` before each edit, and call
`rebuild_index` after editing.

## Coding conventions

- Keep changes inside the owning module; follow §19.3 for what else must change with it
  (schema, contract, validation, tests, README, accreditation).
- Tests: production is authoritative; use synthetic ids like `a`, `b`; test only owned
  behaviour (§14.2–14.4).
- Docstrings follow `.claude/rules/docstrings.md` (Owns / Must not / Public API); they
  describe what the code does and are served to agents by `skatkis.steward`.
- After editing Python outside `Clients/`, run `python -m ruff check` and
  `python -m black` on the files you changed and fix what they report; do not suppress
  a rule with `noqa` without saying why.
- Python changes must pass all Pylance (pyright) checks with no errors, including
  Steward's own code such as `Toolbox/skatkis/steward/planning.py`. A type error often
  hides a real bug (for example a value that can be `None`); fix the cause, do not
  silence it with `# type: ignore` or a cast without saying why.
- Client folders are UI code, and renames are carried into them (`AGENTS.md`,
  "Working rules"; [writing.md](writing.md), "Renames and the trail").

## Building and finalising

1. **Build.** Work in small steps and show results; adjust with the user. Use only
   quick, targeted checks at this stage. If the agreed approach turns out to be wrong,
   stop and discuss again.
2. **Finalise once the user is happy with the product**, not before: unit tests, and
   for financial logic the accreditation test as planned. Unit tests and the
   accreditation test belong here, not when a change is picked up or discussed; the
   one exception is the baseline a refactor records before building starts.
   - A Steward change is verified with `python -m pytest tests/skatkis/steward
     tests/fair_value/test_steward_index.py`; the full `tests/` run currently stops
     at collection on knowingly stale tool tests, which are not part of a Steward
     change.
   - A tool change is verified with the tool's own tests and its accreditation test.
3. **Ask for the warden's report** when the user asks to finalise or for the report.
   Write the diff against the base branch
   (`git diff master...HEAD` plus the working tree) and the output of the tests run in
   step 2 to files in the scratchpad, and start the `warden` subagent with the change
   ID and those file paths. The warden cannot run commands, so it reviews only what it
   is given and what it can read. Hand its report to the secretary unchanged.
4. **Fixes and documentation, after the report.** Fix the findings, then update the
   docstrings and the official documentation the report names. Fixes made only in
   response to the report need no new warden run; any other change does. The
   documentation is: the tool's README for a tool change; README §19 for
   a Steward change. The secretary updates `steward/steward.md`, records the outcome
   and, where the change resolves a note, the resolution in `notes.md`.

## Working on Steward's code

Steward is the read-only component index and MCP server. `steward/` holds no code;
Steward's code stays where it is owned:

| Part | Location |
|---|---|
| Docstring parser, index, planner, server | `Toolbox/skatkis/steward/` |
| Tests | `tests/skatkis/steward/`, `tests/fair_value/test_steward_index.py` |
| Container image | `docker/Dockerfile` (targets `base`, `steward`), `docker/constraints.py`, `.dockerignore` |
| Pipelines | `.azure-pipelines/steward.yml` (Steward), `.azure-pipelines/ci.yml` (repository CI) |
| Local registration | `.mcp.json` |

Before editing `Toolbox/skatkis/steward/`, state the owning module, that the change is
tooling (not methodology), and the accreditation impact (none, unless stated).

- **Read-only.** Every tool is a query. Steward never runs a pipeline layer, writes
  repository files (except `--dump`), or changes what it reports on.
- **No client data.** Never read `Clients/` or `raw_data/`, never return data values,
  never put client data in an image or a test.
- **Code is authoritative.** Facts come from code; docstrings and documents explain.
  Report contradictions; never reconcile them silently (SOP §22.1).
- **Nothing is "accredited".** Statuses are `available` or `active` only.
- **Profiles.** New coding or maintenance tools go in the `full` profile only. A tool
  joins `LOOKUP_TOOLS` (served to Teams) only if it answers a question a person would
  ask before writing code.
- **HTTP access.** The API key check (`ApiKeyGate`) stays in front of the HTTP app; the
  server must keep refusing to start over HTTP without a key.
- **Traceability.** Every answer carries `commit` and `dirty`; keep it that way for any
  new query (use `_envelope`).
- **Determinism.** No clock, randomness or environment-dependent behaviour in the
  index or queries. The server's command line is the only place that reads the
  environment (`STEWARD_API_KEY`).
- **Docstrings** follow `.claude/rules/docstrings.md`; Steward serves them to others.

Use Steward's own tools while working on it: `rules_for(path)` before editing, `health`
for contradictions and `unresolved_computes`, `find_calculation` to check catalogue
changes. After changing `Toolbox/skatkis/steward/`, call `rebuild_index`; changes to the
server's own code only take effect after the MCP server restarts.
