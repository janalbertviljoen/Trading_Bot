# Steward, the Guard

The Guard keeps Claude Code working **only inside the repository** (the repository
root, wherever it is cloned) and **without prompts the user did not
need**. It is one of Steward's roles ([AGENTS.md](AGENTS.md), "Roles"): it checks
and reports, and writes nothing. It runs rarely: when the user asks (`/guard`), after a
change to `.claude/settings.json` or `.claude/hooks/`, or when a prompt appeared that
should not have. This file is read only when the Guard runs; the always-loaded
instructions keep the short rules (`AGENTS.md`, "No access beyond the repository";
`CLAUDE.md`, "No prompts the user did not need").

The official description of the permissions is README §18, "Security permissions for
Claude Code". Where this file and the README differ, the README and the settings win,
and the Guard reports the difference.

## Intent

The user wants two things together:

1. **Containment.** Agents read, write and run commands only inside the repository.
   The rest of the machine is off limits: the user profile, other folders, credentials
   and keys.
2. **No needless prompts.** Anything that stays inside the repository runs without
   asking. The user approves only what reaches outside, or touches protected
   accreditation or client data.

Never weaken, bypass or remove the permissions or the shell guard without the user's
approval (user, 2026-10-16). The Guard proposes; the user decides and approves every
edit in `.claude/`.

## How containment is built

The Claude Code sandbox does not run on native Windows, and the team works on Windows,
so it is off (`"sandbox": {"enabled": false}`). The guardrail is a hook instead:

- **`.claude/hooks/pre_bash_guard.py`** (PreToolUse, Bash) reads the command as Bash
  would (words split outside quotes, quotes removed, braces expanded) and returns
  `ask` when it names an absolute path outside the repository (including a bare drive
  `/c`, a drive-relative path `D:notes.txt`, a wildcard at the root `/*`, the bare
  root `/`, Git Bash's own folders and a `file://` URL), the home directory or a user
  folder (including the Windows folder variables, and a bare `cd`, `cd -` or `pushd`,
  which leave the working directory), `..`, Git's user or system configuration
  (`git config --global`), PowerShell started from Bash, or an edit-denied protected
  file (`scenario_inputs.json`, `legacy_records.json`, `legacy_parity`, `*.xlsm`,
  `raw_data`, `ui_test/seed.json` and `ui_test/corrupted` however the path is spelled),
  also when the name is split by quotes, built by braces or matched by a wildcard, or
  the user-test refresh that writes the last two (`ui_test.refresh`, run by the user
  outside Claude Code); otherwise `allow`. A wildcard in a relative word is expanded against the
  repository to find a protected file; nothing outside the repository is listed, and
  beyond 256 expanded words or 10,000 wildcard hits it asks. It fails closed: an
  unreadable payload or any error while checking asks, and `onFailure: block` in the
  settings blocks the command if the hook itself fails. It needs Python 3.10 or later.
  A guardrail, not isolation. Two consequences by choice: the files that only ask in
  the settings (`fixtures/**`, `examples.py`, `compare.py`) are not in its pattern, so
  a shell edit to them runs without a prompt and is left to the user's review; and a
  wildcard listing in an `accreditation/` folder (`ls .../accreditation/*`) asks,
  because it matches a protected file.
- **`.claude/settings.json`:**
  - `allow`: Bash, WebFetch, WebSearch and the Steward MCP tools, with no per-tool
    prompt. The web rules are in the shared file; a user still asked for them adds
    the same rules to their git-ignored `settings.local.json`;
  - `deny`: `Read(~/**)`, `Edit(~/**)`, PowerShell, and edits to protected
    accreditation, raw-data and user-test files; `ask` for accreditation fixtures, a tool's
    accreditation `examples.py` (it holds the informal-check reference values) and
    `compare.py`;
  - `blockReadsOutsideWorkingDirectories`; `disableAutoMode` and
    `disableBypassPermissionsMode`; `defaultMode: acceptEdits`;
  - `skipWebFetchPreflight`: no domain check against Anthropic's blocklist before a
    fetch, so the user's review of what is fetched is the control;
  - telemetry, error reporting, feedback, connectors, Artifacts and Remote Control off.
- Both hooks are started with
  `python -c "...runpy.run_path(os.path.join(os.environ['CLAUDE_PROJECT_DIR'], ...))"`,
  so they work from any working directory without shell-variable expansion.

## What was learned (2026-10-16)

- Claude Code's built-in checks override the hook's `allow` (confirmed from a debug
  log: the guard returned `allow` and the user was still prompted). No setting or hook
  switches them off. They fire on a `cd` chained to another command, some `python -c`
  one-liners (exact trigger unknown), any edit to `.claude/settings.json`, and any write
  in `.claude/`.
- The VS Code extension's mode selector overrides `defaultMode`; keep it on "Edit
  automatically" (`claudeCode.initialPermissionMode: acceptEdits` in the user's VS Code
  settings).
- Hook configuration is read at session start; a change to `settings.json` needs a
  session restart.

## Rules for tool calls

The always-loaded short form is in [CLAUDE.md](CLAUDE.md); the reasons are above.

1. Never `cd`; stay at the repository root and use relative paths.
2. Read and search with the Read and Grep tools, not the shell or `python -c`; read a
   PDF with Read and its `pages` parameter (at most 20 pages per call).
3. Bash only for plain commands: `git`; `python -m pytest`, `ruff`, `black`;
   `curl -sSL -o "<path in repo>" <url>` to download a source document into a tool's
   `docs/` folder.
4. No scratch or helper files in `.claude/`. A temporary file, if truly needed, goes
   inside the repository outside `.claude/` and is deleted afterwards.
5. No paths outside the repository in commands (no `/tmp`, AppData, `~` or venv
   paths); the guard will ask.
6. Do not edit `.claude/settings.json` or the guard unless the user asks.
7. If a prompt appears anyway, tell the user the exact command and use a different
   route rather than asking for repeated approval.

## Running the Guard

Work through the checks in order, read-only, and give the user one report. Do not edit
`.claude/`, the instructions or the README during the run; list proposed edits for the
user to approve.

1. **Settings.** Read `.claude/settings.json` (and note whether a
   `settings.local.json` exists, without reading anything outside the repository).
   Check every item in "How containment is built" is present and unweakened: no new
   `allow` that reaches outside, no removed `deny`, sandbox state as recorded, modes
   still disabled, no added directories (`additionalDirectories`), MCP limited to
   `skatkis-steward`.
2. **Hook.** Read `.claude/hooks/pre_bash_guard.py`: its patterns, its fail-open or
   fail-closed behaviour, its docstring and the `statusMessage` in the settings.
3. **Penetration test.** Run `python -m pytest tests/guard -q -rxX`. Every case must
   pass or be a strict `xfail` (a known gap). Report each gap, and any new bypass you
   can think of as a proposed case for `tests/guard/test_pre_bash_guard.py` (in
   `MUST_ASK`, as a `_gap` until the hook is fixed), which the developer adds. Never
   try a bypass in Bash: the guard would ask for the command itself, and an attack
   command is never executed for real.
4. **Limits by design.** Restate what the guard cannot catch (below) and whether
   anything changed, for example a sandbox becoming available on Windows.
5. **Agreement.** Check README §18, `AGENTS.md` ("No access beyond the repository"),
   `CLAUDE.md` ("No prompts the user did not need") and this file agree with the
   settings and the hook. Report any duplicated or stale permission text in the
   always-loaded instructions; the background belongs here, once.
6. **Prompts.** If the user reported a prompt, find the command and its cause (hook
   `ask`, built-in check, mode selector) and give the route around it.
7. **Report.** Findings ranked by risk (containment first, then needless prompts,
   then documentation), each with the evidence, the proposed fix and whether it needs
   the user's approval (any edit in `.claude/` does). Record findings that need work as
   a change in `steward/toolbox/skatkis/CHANGELOG.md`, with the user's agreement.

## Limits by design

The guard reads command text, so these pass it and are covered only by the user's
review, the `deny` rules and, later, an isolated environment (S_202610_034):

- paths built at run time (encoded strings, a home path computed in code rather than
  written as `Path.home(` or `expanduser`, variables set earlier in the command or in
  a script the command runs);
- a script inside the repository that itself reads outside it (`python -m pytest` runs
  arbitrary test code);
- network egress through Bash (`curl` uploads, `git push`, `pip install`), since Bash
  and the web are allowed.
