# SOP: Modular Analytical Tool Development

**Version:** 5.2 (user testing version 1, §15.12; integrated Steward; sign-off procedure version 1, §15.8 and §15.11)  
**Purpose:** Repository-wide engineering standard for modular analytical systems  
**Audience:** Developers, quantitative analysts, model owners, reviewers, and AI-assisted development tools  
**Status:** Mandatory engineering standard  
**Applies to:** All reusable analytical tools under `Toolbox/`  
**Supersedes:** Version 5.1

---

## 1. Purpose

![Building a modular analytical tool under this SOP](skatkis/docs/SOP_flow.png)

This SOP defines the engineering and governance standard for analytical systems in the repository. It establishes how tools are structured, how analytical logic is separated, how data moves through a pipeline, how interfaces are enforced, and how changes are tested and documented.

Every analytical tool must be:

- **modular:** each module owns a clear concern;
- **deterministic:** identical inputs and configuration produce identical outputs;
- **contract-gated:** each layer declares and validates its interface;
- **source-agnostic:** external column names and formats are normalised before computation;
- **testable:** each owned behaviour is independently verifiable;
- **reproducible:** execution does not depend on hidden state, implicit dates, or unpinned environments;
- **auditable:** data lineage, assumptions, calculations, and failures are traceable;
- **extensible:** new products, sources, layers, and metrics can be added without destabilising existing modules;
- **production-oriented:** validation, logging, documentation, and governance are part of the implementation.

This SOP applies to systems including:

- fair value;
- IFRS 9 impairment;
- regulatory capital;
- pricing and profitability;
- stress testing;
- behavioural modelling;
- treasury analytics;
- forecasting;
- model validation tools;
- recurring analytical reporting.

A tool-specific `README.md` remains the authoritative explanation of that tool’s current implementation. This SOP defines the repository-wide construction standard. Production Python modules remain authoritative when a documentation conflict is discovered.

---

## 2. Engineering philosophy

### 2.1 Build systems, not spreadsheets

The repository does not reproduce spreadsheet layouts. It converts implicit spreadsheet behaviour into explicit system design.

| Spreadsheet pattern | Required system pattern |
|---|---|
| Logic hidden in cells | Logic owned by named functions and modules |
| Calculation order implied by sheets | Explicit directed acyclic graph |
| Interfaces implied by references | Declared layer contracts |
| Errors identified in final outputs | Errors rejected at boundaries |
| Manual column alignment | Source mapping and registry hydration |
| Shared mutable state | Copy-on-entry and protected upstream outputs |
| Repeated formulas | One owning implementation |
| Client-specific workbook conventions | Canonical internal schemas |

Excel may be used as a methodology reference or reconciliation source. Excel structure must not dictate production architecture.

### 2.2 Separation of concerns

The repository separates reusable logic from client execution.

| Area | Responsibility |
|---|---|
| `Toolbox/` | Reusable analytical systems, shared infrastructure, models, contracts, validation, and calculation logic |
| `Clients/` | Client paths, client input configuration, run scripts, orchestration, and reporting |
| `tests/` | Unit, contract, validation, integration, and pipeline tests |
| Repository governance documents | Cross-tool standards, setup, contribution rules, and architecture guidance |

Rules:

- Reusable analytical logic must not be implemented in `Clients/`.
- Raw client data must not be committed to `Toolbox/`.
- Client scripts may configure and run tools but must not duplicate toolbox calculations.
- A tool must be reusable across clients without modifying production modules for client-specific column names or paths.

### 2.3 Determinism

Given identical inputs, configuration, code, and dependency versions, execution must produce identical outputs.

Prohibited inside reusable toolbox logic:

- implicit current dates such as `datetime.today()` or `pd.Timestamp.now()`;
- unseeded randomness;
- hardcoded client paths;
- environment-dependent analytical branching;
- mutable module-level data state;
- hidden file reads inside calculation functions;
- assumptions embedded as unexplained literals inside functions.

Dates, thresholds, rates, scenarios, and configurations must be explicit inputs, schema constants, source-model values, or keyword-only parameters.

### 2.4 The ownership principle

Every calculated concept has one owner.

A downstream layer may consume an upstream output, but must not silently recompute it. Recalculation creates multiple sources of truth and removes the ability to reconcile layer boundaries.

A module’s documentation must state:

- what the module owns;
- what the module must not compute;
- its public interface;
- the schemas or contracts it uses;
- its grain and relevant dependencies.

### 2.5 The contract principle

A layer contract is an executable interface. It declares:

- the columns required after hydration;
- the columns the layer formally produces;
- the uniqueness grain of the output;
- source models required for hydration or joins;
- upstream fields that must remain unchanged;
- the minimum seed needed to initiate the layer.

Contracts are not optional documentation. Contracts drive registry construction, hydration, layer registration, validation, and downstream lineage.

---

## 3. Standard repository architecture

### 3.1 Repository layout

```text
FinancialRiskManagement/
├── Toolbox/
│   ├── skatkis/                       # Shared systems infrastructure
│   ├── analytical_tool_a/             # Reusable analytical tool
│   └── analytical_tool_b/
├── Clients/
│   └── Client_X/
│       └── analytical_tool_a/
├── tests/
│   ├── skatkis/
│   └── analytical_tool_a/
├── steward/                           # Steward: agent rules, change logs, tool notes (§22.5)
├── docs/ or Toolbox governance files
├── pyproject.toml
├── package_versions.txt
└── README.md
```

### 3.2 Shared infrastructure versus tool implementation

`Toolbox/skatkis` provides reusable infrastructure that should not be reimplemented in each analytical tool. Shared capabilities may include:

- layer contracts;
- registries;
- lookup source abstractions (`LookupModel`, §6.1);
- column mapping;
- input hydration;
- join resolution and broadcast behaviour;
- schema metadata utilities;
- generic validation assertions;
- the pipeline interface for overrides, solvers, introspection, and summaries (`skatkis.pipelines.ui`, §17);
- reusable financial utilities and schema factories.

A tool package defines only its domain-specific configuration and behaviour:

- canonical domain schemas;
- concrete layer contracts;
- source-specific transformations;
- domain validation gates;
- product or methodology registries;
- analytical layers;
- pipeline orchestration;
- tool-specific documentation.

`skatkis` holds no tool-specific domain knowledge. General finance is not tool-specific: financial mathematics and conventions that any financial tool may need (rate and compounding conventions, discounting, calendar and day arithmetic, rating scales) live in `skatkis.financial_logic` and are reused by every tool. A tool decides which general formula applies, to which columns and under which product rules; the formula itself is not re-implemented in the tool. Tool-specific methodology (for example PD and LGD treatment, expected credit loss, capital, product payment behaviour) stays in the owning tool. Moving an existing calculation from a tool into `skatkis.financial_logic` is a refactor only if every accredited output stays within tolerance; changing its conventions while moving it is a methodology change (§12.5).

This SOP describes the pipeline architecture `skatkis` implements. Beyond it, `skatkis` sets further standards used across the repository: schema validation runs on Pandera (the skatkis schema dict stays the single source of truth and is translated into a Pandera schema, §13.2); numerical utilities such as curve interpolation (`skatkis.numerics`); the general financial mathematics in `skatkis.financial_logic`, each concept with its mathematical definition and sources; and the firm branding and styling of every output workbook. These are documented in [`skatkis/docs/skatkis_reference.md`](skatkis/docs/skatkis_reference.md), not in this SOP.

Do not create a local copy of shared `skatkis` behaviour merely to make a tool appear self-contained. If generic infrastructure is missing, implement and test it in `skatkis`, then consume it from the tool.

### 3.3 Standard tool layout

The current standard is:

```text
Toolbox/
└── analytical_tool/
    ├── README.md
    ├── io.py
    ├── pipeline.py
    ├── contracts.py
    ├── schema.py
    ├── validation.py
    ├── product_types.py              # Optional controlled behaviour registry
    ├── sources/
    │   ├── primary_source.py
    │   ├── lookup_model_a.py
    │   └── configuration_source.py
    ├── layers/
    │   ├── layer_one.py
    │   ├── layer_two.py
    │   └── terminal_summary.py
    ├── accreditation/                # Scenario fixtures, reference data, provenance (§15)
    │   └── fixtures/
    ├── ui_test/                      # User test: seed, corrupted export, answer key (§15.12)
    └── docs/
        └── supporting methodology and reference material
```

A tool whose outputs are reviewed and signed off as a financial model includes an `accreditation/` folder (§15). Scenario fixtures, frozen reference data, and the provenance record live in or beside it. The tool README records the exact file names. Before release it also includes a `ui_test/` folder for its user test (§15.12).

`product_types.py` is optional. Use an equivalent clearly named registry module when a tool supports pluggable strategies, products, policies, instruments, or methodologies.

### 3.4 Client layout

```text
Clients/
└── Client_X/
    └── analytical_tool/
        ├── raw_data/
        ├── column_mapping/
        ├── configuration/
        ├── run_model.py
        └── outputs/
```

Client directories may contain:

- paths;
- source-file selection;
- client column mappings;
- approved parameter overrides;
- pipeline construction and execution;
- client-specific reporting.

Client directories must not contain reusable calculations, copied production functions, or alternative implementations of toolbox methodology.

---

## 4. File ownership standards

### 4.1 `schema.py`

Owns:

- canonical column names;
- dtype metadata;
- required, positive, non-negative, probability, key, join, and value flags;
- defaults;
- ownership and derivation metadata;
- source schemas;
- layer input and output schemas;
- model constants appropriate to the tool;
- selection of reusable schema structures or instrument factories.

Must not own:

- DataFrame calculations;
- file IO;
- validation execution;
- layer orchestration.

### 4.2 `contracts.py`

Owns:

- concrete `LayerContract` instances;
- ordered contract registration;
- each layer’s seed columns, input schema, output schema, grain, model joins, and immutable inputs.

Must not own:

- financial calculations;
- hydration code;
- validation functions;
- source loading.

The concrete contract shape must follow the shared `skatkis` contract implementation. Do not document or code fields that do not exist in the shared contract version used by the repository.

### 4.3 `validation.py`

Owns:

- tool-specific input and output gates;
- tool-specific business-rule validation;
- source mapping domain checks;
- registered-strategy or product checks;
- composition of generic `skatkis` assertions into domain gates.

Must not own:

- hydration;
- calculation;
- file IO;
- layer orchestration.

### 4.4 `io.py`

Owns:

- source-class construction;
- optional mapping-file resolution;
- one loader per source model, from a path or from in-memory records.

Must not own:

- opening or writing files itself: files are read and written through `skatkis.io`, which
  reports clear path-related failures;
- source-specific transformation logic;
- financial calculation;
- schemas;
- layer sequencing.

### 4.5 `pipeline.py`

Owns:

- source registration;
- DAG definition;
- execution order;
- seed extraction;
- registry updates after each layer;
- result access.

Must not own:

- formula implementation;
- source transformations;
- validation logic;
- product-specific branches.

### 4.6 `sources/`

Each source module owns the boundary between an external source and the canonical internal schema. Typical responsibilities are:

- default column mapping;
- optional mapping loader;
- required key and value classification;
- source-specific reshaping or derivation;
- source model name and schema;
- construction-time load and validation through a shared source base class.

Source modules must not calculate downstream analytical outputs.

### 4.7 `layers/`

Each layer module owns one analytical stage. A layer may contain:

- pure calculation helpers;
- one public layer entry point;
- hydration invocation;
- input gate invocation;
- owned calculation orchestration;
- output gate invocation.

A layer must not:

- read files;
- call another layer’s public compute function;
- contain client-specific logic;
- recompute upstream-owned measures;
- add product-specific branches when a registered strategy interface is available.

### 4.8 Registry modules such as `product_types.py`

A registry module is a controlled exception to the rule that root modules contain construction only. A registry module may contain domain logic when its purpose is to isolate pluggable behaviour behind a stable interface.

The pattern is appropriate when:

- multiple products or strategies share a generic engine;
- each product may require materially different behaviour;
- the engine should remain agnostic;
- adding a product should not require editing orchestration logic.

A registry module owns:

- supported identifiers;
- common context objects or protocols;
- product-specific or strategy-specific functions;
- registry dictionaries mapping identifiers to callables;
- extension instructions.

It must not own portfolio orchestration, source IO, validation gates, or unrelated downstream calculations.

---

## 5. Schema architecture

### 5.1 Single source of truth

No production module may independently redefine a canonical column contract. A schema entry is a metadata dictionary keyed by canonical column name.

Example:

```python
FACILITIES_SCHEMA = {
    "loan_id": type_str | required | unique_key | owned_by_fac,
    "principal": type_float | required | positive | owned_by_fac,
    "annual_rate": type_float | required | positive | owned_by_fac,
}
```

### 5.2 Constraint metadata

Common flags include:

| Metadata | Meaning |
|---|---|
| `dtype` | Expected pandas dtype or compatible type family |
| `required` | Column must be present and satisfy required-value rules |
| `default` | Value used when an optional field is absent |
| `positive` | Value must be greater than zero |
| `non_negative` | Value must be at least zero |
| `probability` | Value must be within `[0, 1]` |
| `unique_key` | Column participates in a uniqueness constraint |
| `join_col` | Column participates in lookup resolution |
| `value_col` | Column supplies lookup values rather than key dimensions |
| ownership metadata | Source or layer that owns the column |
| derivation metadata | Registry source from which the column may be hydrated |

### 5.3 Composition and lineage

Layer input schemas should reference source or upstream output metadata directly:

```python
CASH_FLOW_INPUT_SCHEMA = {
    "loan_id": TERM_OUTPUT_SCHEMA["loan_id"],
    "mob": TERM_OUTPUT_SCHEMA["mob"],
    "principal": FACILITIES_SCHEMA["principal"],
}
```

This preserves ownership lineage and prevents metadata drift.

Use dictionary composition only where intentional. If shared infrastructure provides a conflict-detecting schema merge, use it for programmatic composition where duplicate definitions may occur.

### 5.4 Formal outputs versus runtime intermediates

A layer may calculate intermediate analytical columns. Only columns declared in the output schema are guaranteed to survive pipeline registration.

Therefore:

- a downstream dependency must be a formal output;
- a reported field must be a formal output;
- an intermediate may remain local only if no downstream layer or external consumer requires it;
- implementation, schema, contract, validation, tests, and documentation must remain aligned.

### 5.5 Reusable schema factories

Use a schema factory when several concepts share the same structural roles. For example, a fee or cost instrument may consistently require:

- value;
- rate;
- frequency;
- growth;
- basis.

A shared factory may generate the canonical structure and metadata. The tool’s `schema.py` selects the instruments relevant to the tool. The calculation layer still owns financial behaviour and event conditioning.

This avoids repetitive schema declarations without hiding methodology.

---

## 6. Source models and column mapping

### 6.1 Source-agnostic computation

Computation layers must receive canonical internal names only. External source names are resolved in source modules using `ColumnMap` or the current shared mapping abstraction.

Every pipeline input enters through a `LookupModel` (`skatkis.pipelines.sources`), the central class of a tool's `sources/` package. A tool subclasses it once per source, declaring the source's name, canonical schema and transformations. The shared base supplies the load pipeline (map columns through the `ColumnMap`, transform, fill defaults, cast, validate) and the single generic loader `load_lookup_model`, for files or in-memory records alike. The registry stores the loaded models, and hydration (§7) joins their values into layers. A source module never reimplements this pipeline; it supplies only what is specific to its source.

### 6.2 Default mapping

Each source module should expose an identity mapping over its standard internal schema when a client mapping is not supplied.

### 6.3 Mapping loaders

A source-specific mapping loader supplies generic loading infrastructure with:

- required internal keys;
- value columns;
- a source-specific validation callback;
- clear diagnostic context.

The source module, not `io.py`, owns mapping-domain requirements.

### 6.4 Additional segmentation dimensions

A lookup source may support additional join dimensions without hardcoding every future segment. A mapped internal column that is neither a required key nor a value column may be treated as an additional segment key by the shared source abstraction.

Tests must prove:

- required keys remain present;
- optional segment columns survive transformation;
- schema columns remain ordered predictably;
- unmapped columns are dropped;
- input data is not mutated.

### 6.5 Broadcast sources

Portfolio-wide assumptions may be represented as a single-row lookup with a broadcast sentinel key. Shared resolver infrastructure may then assign scalar values across all applicable rows.

Broadcast behaviour belongs to shared infrastructure. A source-specific test should verify only that the source assigns the required broadcast key and transforms its data correctly.

---

## 7. Registry and hydration architecture

### 7.1 Pipeline registry

The registry is the controlled shared state across pipeline execution. It contains:

- loaded source models;
- concrete layer contracts;
- completed layer results and keys;
- source and contract metadata required by hydration.

After each layer completes, the pipeline updates the relevant contract entry before the next layer runs.

### 7.2 Minimal seeds

A layer may be initiated from only the key columns of its upstream source. Hydration expands the seed to the full input contract.

This enables:

- end-to-end pipeline execution;
- isolated layer execution in tests;
- reduced coupling between layers;
- central lineage and resolution rules.

### 7.3 Hydration rules

Before input validation, the resolver:

1. inspects the contract input schema;
2. identifies missing derivable columns;
3. resolves those columns from the appropriate registry entry;
4. uses lookup keys or broadcast behaviour as declared by source metadata;
5. preserves existing valid columns rather than overwriting them implicitly;
6. returns the hydrated DataFrame for domain validation.

### 7.4 Join coverage

A required lookup must have complete key coverage before analytical use. Missing PD, LGD, segmentation, or other model rows must not silently create null calculations.

Coverage diagnostics should include:

- lookup name;
- key columns;
- count or proportion unmatched;
- a sample of unmatched key combinations;
- calculation context.

---

## 8. Layer contracts

### 8.1 Required contract fields

A concrete layer contract should declare the fields supported by the current shared contract implementation, generally including:

```python
LayerContract(
    name="layer_name",
    seed_columns=["entity_id", "time_index"],
    input_schema=LAYER_INPUT_SCHEMA,
    output_schema=LAYER_OUTPUT_SCHEMA,
    grain=["entity_id", "time_index"],
    immutable_inputs=[...],
    model_joins=[...],
)
```

Do not invent local contract formats. Extend the shared contract type when a genuinely generic requirement is identified.

### 8.2 Contract grain

The contract grain is the uniqueness key of the layer output.

Typical patterns:

```text
Time-series analytical layer: entity_id, time_index
Terminal summary layer:       entity_id
Portfolio summary layer:      reporting dimensions
```

Not every layer appends columns to the same grain. Terminal summaries may return separate aggregated tables.

### 8.3 Immutable inputs

Every upstream-owned column consumed by a layer should be protected when appropriate. A layer may not overwrite an upstream result merely because the same name is convenient.

If methodology requires replacing a concept, define a new canonical output or explicitly revise ownership through schema and contract review.

### 8.4 Model joins

`model_joins` identifies source models the layer requires. It is metadata used by registry and resolver infrastructure. The calculation layer should consume hydrated columns rather than manually loading source tables.

### 8.5 Contract registration order

Contracts must be registered in dependency order. The order must be consistent with the pipeline DAG.

---

## 9. The layer execution gate

Every public analytical layer follows this conceptual sequence:

1. **Copy input**  
   Protect caller-owned data.
2. **Hydrate contract inputs**  
   Resolve missing derivable fields from the registry.
3. **Validate inputs**  
   Enforce the domain input gate.
4. **Calculate owned outputs**  
   Run only the layer’s analytical logic.
5. **Validate outputs**  
   Enforce output completeness, constraints, grain, and applicable immutability rules.
6. **Return result**  
   Return the new DataFrame or declared summary table.

Example:

```python
def compute_layer(
    df: pd.DataFrame,
    lookup_registry: PipelineRegistry,
    *,
    parameter: float = DEFAULT,
) -> pd.DataFrame:
    df = df.copy()
    df = hydrate_contract_inputs(df, LAYER_CONTRACT, lookup_registry, SEGMENTATION_SOURCE)
    validate_layer_input(df, lookup_registry)

    df["owned_output"] = _compute_owned_output(df, parameter)

    validate_layer_output(df)
    return df
```

Exact gate numbers may change as a pipeline evolves. The existence and purpose of the pre-computation and post-computation gates are mandatory.

---

## 10. Product and strategy registry pattern

### 10.1 Purpose

Use a product or strategy registry when one generic engine must support multiple behaviours that may differ substantially.

The registry prevents generic engines from becoming a chain of product-specific conditional statements.

### 10.2 Two-part behaviour pattern

A product may require more than one independent behaviour. Fair value demonstrates this with:

1. a schedule function that determines dates and event flags;
2. a payment function that determines contractual payment amounts.

The generic engines call each through a stable context interface.

```python
ScheduleFunction = Callable[
    [ScheduleContext],
    tuple[list[pd.Timestamp], list[bool]],
]

PaymentFunction = Callable[[PaymentContext], float]
```

Registries map lowercase product identifiers to callables:

```python
SCHEDULE_FUNCTIONS = {
    "fixedpayment": _build_fixed_payment,
    "bulletpayment": _build_bullet_payment,
}

PAYMENT_FUNCTIONS = {
    "fixedpayment": _pmt_fixed,
    "bulletpayment": _pmt_bullet,
}
```

### 10.3 Context objects

Use immutable context objects to provide a stable interface. Contexts should contain only the information needed by registered callables.

Benefits:

- adding a new argument does not require changing every function signature independently;
- generic engines remain product-agnostic;
- tests can instantiate contexts directly;
- complex product logic remains isolated;
- registry callables can evolve without changing orchestration.

### 10.4 Exact and approximate implementations

Registries may expose both exact and approximate implementations when the difference is explicit and documented.

For example:

- an exact payment function may discount using the actual remaining contractual payment periods;
- an approximate function may use a standard PMT formula that assumes equal periods.

Identifiers, documentation, and tests must make the approximation clear. An approximate implementation must not silently replace an exact calculation.

### 10.5 Adding a product or strategy

The extension sequence is:

1. define the identifier in the supported-values list;
2. implement each required registered behaviour;
3. register the behaviour under the same identifier in all relevant registries;
4. ensure schema allowed values derive from the supported-values list;
5. add tests for timing, state transitions, resets, boundaries, and terminal behaviour;
6. add integration coverage through the generic engines, and accreditation scenarios for the new product (§15.5);
7. update the tool README;
8. obtain methodology approval where behaviour changes model outcomes.

Do not modify a generic engine merely to dispatch a new registered product.

### 10.6 When not to use a registry

Do not introduce a registry for trivial parameter differences that belong in data or configuration. Use a registry when behaviour differs, not merely values.

---

## 11. Function design standards

### 11.1 Public layer signature

```python
def compute_layer_name(
    df: pd.DataFrame,
    lookup_registry: PipelineRegistry,
    *,
    keyword_parameter: float = DEFAULT,
) -> pd.DataFrame: ...
```

Rules:

- `df` is first;
- registry is second;
- configuration is keyword-only;
- input is copied before mutation;
- output matches the declared contract grain;
- hidden IO is prohibited.

### 11.2 Calculation helpers

Private analytical helpers may accept:

- the full hydrated DataFrame when several related columns are needed;
- explicit Series when the function is public API, reusable outside the pipeline, or registry-dispatched;
- an immutable context for pluggable behaviour.

Choose the interface that reflects ownership and reuse. Do not force every helper into one signature pattern.

### 11.3 Single responsibility

A function should compute, transform, validate, or orchestrate one coherent concept. “One sentence without the word and” is a useful heuristic, not an absolute rule. A layer entry point necessarily orchestrates several owned helper calculations.

### 11.4 Sorting and grouped operations

Before any time-dependent operation, explicitly establish order by entity and time index.

This applies to:

- recursion;
- `shift`;
- `diff`;
- cumulative sums or products;
- survival curves;
- rolling calculations;
- duration calculations.

Grouped calculations must not leak between entities.

### 11.5 Index preservation

Vectorised helpers should preserve the source index unless resetting or aggregating is part of the declared behaviour. Tests should assert index behaviour where downstream alignment depends on it.

### 11.6 Numerical behaviour

Document and test:

- clipping;
- denominator replacement;
- zero-balance behaviour;
- rounding;
- treatment of missing solver results;
- bounds;
- approximation assumptions.

Numerical protections must not conceal invalid business inputs that should be rejected by validation.

---

## 12. Documentation standards

### 12.1 Tool README

Every analytical tool must have one comprehensive root `README.md` covering:

- purpose;
- design principles;
- repository structure;
- root module responsibilities;
- source modules;
- layer modules;
- shared infrastructure dependencies;
- DAG and output grains;
- source mapping and hydration;
- product or strategy registries;
- detailed formulas and assumptions;
- canonical outputs;
- validation and testing governance;
- extension procedures;
- current limitations;
- future enhancements.

The README must help both developers and AI-assisted tools understand the system without reading every file first.

### 12.2 Module docstrings

A source or layer module docstring should state:

- module purpose;
- owned behaviour or outputs;
- prohibited responsibilities;
- public API;
- key mathematical or source conventions;
- contract or validation role where relevant.

### 12.3 Mathematical helpers

A mathematical helper should document:

- the concept calculated;
- the exact implemented formula;
- inputs and units;
- output and bounds;
- important assumptions;
- special zero or boundary behaviour.

### 12.4 Production identifiers

Documentation must preserve actual production identifiers, including an existing misspelling, until code and schema are deliberately migrated together. Do not silently “correct” names in documentation and create copy-paste failures.

### 12.5 Methodology versus refactor

Any change to a financial formula, rate convention, time exponent, floor, recovery treatment, capital method, or valuation model is a methodology change. It must not be introduced under the label of code cleanup.

---

## 13. Validation standards

### 13.1 Centralisation

Tool-specific validation belongs in the tool’s `validation.py`. Layer modules invoke gates but do not implement ad hoc validation branches.

### 13.2 Schema-driven validation

Generic validation should derive as much behaviour as possible from schema metadata:

- required columns;
- required-value null checks;
- dtype checks;
- probability bounds;
- positive and non-negative constraints;
- unique keys.

Adding metadata to `schema.py` should activate the relevant generic validation wherever that schema is used.

### 13.3 Domain validation

Some rules cannot be expressed only through column metadata. Examples include:

- either `term_months` or `final_payment_date` must be supplied;
- initial payment cannot precede loan start;
- a product identifier must be registered;
- a PD mapping must include sufficient PIT and TTC measures;
- a required lookup must cover all left-side keys.

Such rules belong in clearly named domain validation functions.

### 13.4 Diagnostic quality

Validation failures should identify:

- context;
- violated rule;
- columns involved;
- number of affected rows;
- sample invalid identifiers or keys;
- expected constraint.

Where useful, related row-level errors may be accumulated and raised together.

### 13.5 Fail fast

Calculation must not continue after an invalid gate. Returning partially calculated data from a failed layer is prohibited.
### 13.6 Post-run reporting (non-validating notices)

Validation (§13.1–13.5) rejects invalid state — it raises and execution
stops. Reporting is the deliberate counterpart: it records assumptions,
defaults, and other non-fatal conditions that were *valid* but worth
surfacing, without altering or blocking execution.

Reporting must be:

- **post-hoc.** Generated once, from the final registry state, after a
  pipeline run has completed — not threaded through compute functions
  or accumulated incrementally during execution. A check is a pure
  function of the finished registry: `(registry) -> list[Notice]`.
- **read the aftermath, not the recipe.** A check answers its question
  from whichever registry state actually holds the answer — declared
  `col_map.mapping` for "what did the client supply," computed `.data`
  for "what happened after a mutating step ran." A check must never
  re-run or partially reconstruct pipeline logic to infer an outcome;
  if the answer requires knowing what a mutation did, read its result
  off the registry, not the inputs that produced it.
- **positive framing where the schema is sparse.** When most columns of
  a structure are expected to be absent or defaulted (e.g. an
  optional-instrument schema with many more possible columns than any
  client will supply), report what was actively supplied or retained,
  not the larger unsupplied set. Silence for an item means it fully
  defaulted — the expected, unremarked case — not an omission.
- **domain-agnostic engine, domain-specific checks.** The reporting
  engine (`skatkis.pipelines.report`: `Notice`, `PipelineReport`,
  `build_report`) has no knowledge of any tool's domain. Check
  functions live in the tool package (e.g.
  `fair_value/report_checks.py`) and are passed into
  `build_report` as a list. Adding a check never requires changing the
  engine.
- **never a substitute for validation.** A condition that must block
  execution belongs in `validation.py` as an `assert_*`/raise. A
  condition that is valid but worth recording belongs in a report
  check. The two are not alternative implementations of the same rule.

A report is attached to the registry it was generated from
(`registry.report`) so the run's data and its audit notices travel
together — for output writing, and for whatever is retained for
audit purposes.
---

## 14. Testing standards

### 14.1 Test ownership hierarchy

Testing follows the same ownership model as production.

| Test area | Owns |
|---|---|
| `tests/skatkis/` | Generic contracts, registry, source base classes, column mapping, resolvers, broadcast behaviour, generic assertions, the generic accreditation mechanics, and the UI layer |
| Tool source tests | Source-specific mapping, classification, reshaping, loader orchestration, and non-mutation |
| Tool layer tests | Layer-owned formulas, event conditions, grouping, recursion, boundaries, and orchestration |
| Tool schema tests | Canonical metadata and input/output schema composition |
| Tool contract tests | Concrete contract completeness, grain, immutable inputs, and model joins |
| Tool validation tests | Tool-specific gates and business rules |
| Tool pipeline tests | DAG order, seed selection, registry updates, and result access |
| Integration tests | End-to-end behaviour across representative products and sources |
| Tool accreditation test | Pipeline runs over frozen scenario inputs compared with frozen, signed-off reference values (§15) |

Do not test an inherited generic method in every source or layer merely because the method is accessible there.

Test files mirror the source tree. A module `Toolbox/<package>/<module>.py` is tested by `tests/<package>/test_<module>.py`, so each module's tests are found where its code lives.

Accreditation tests (§15) run in the same test run as the tests above but answer a different question: whether the assembled financial logic still produces the signed-off results, not whether each function is correct.

### 14.2 Production is authoritative

When updating tests:

- use the production module as the authoritative implementation;
- use the existing test file as a structural reference;
- preserve valid test docstrings and style;
- modify only tests unless a production defect has been separately agreed;
- report contradictions instead of inventing production behaviour;
- do not patch tests to normalise unsupported production inputs;
- use lowercase simple identifiers such as `a` and `b` for synthetic entities.

### 14.3 Minimum calculation coverage

Each owned calculation should have relevant tests for:

- exact formula;
- normal case;
- zero case;
- lower and upper boundaries;
- monotonic relationship where mathematically valid;
- grouping isolation;
- index alignment;
- vectorised operation;
- input non-mutation;
- event conditioning;
- invalid registered identifier or unsupported configuration.

### 14.4 Orchestration tests

A layer orchestration test should verify only behaviour owned by the layer, such as:

- expected owned columns are created;
- formulas are connected in the right order;
- entity groups are handled independently;
- output sorting or aggregation matches the layer contract;
- input remains unchanged.

Hydration and validation may be patched when their behaviour is already tested elsewhere and the objective is to isolate layer computation.

### 14.5 External-library stubs

If a repository test harness stubs a numerical library with scalar-only behaviour, unit tests may patch the imported dependency at the production module’s namespace to provide deterministic vector-compatible behaviour. The patch must isolate the harness limitation and must not redefine production methodology. Accreditation tests (§15.10) never run against such stubs.

### 14.6 Test quality gates

Before merge, run the repository’s required:

- unit tests;
- contract tests;
- validation tests;
- integration or pipeline tests;
- accreditation tests;
- Ruff checks;
- formatter;
- static type checks where configured.

A passing happy-path test suite is not sufficient without edge-case and failure-mode coverage.

---

## 15. Accreditation of financial logic

### 15.1 Definition and purpose

In financial-model governance, *accreditation* means that the outputs of a model have been reviewed and signed off. In this repository accreditation is also executable. The signed-off outputs for a fixed set of scenarios are held as frozen reference values, and an automated test compares a full pipeline run against them on every test run.

This is distinct from parity testing in the software-development sense, although the mechanics are similar. The aim is not to show that two programs agree. The aim is to show that the tool's financial logic still produces what a reviewer approved, and to stop a change from silently moving those numbers.

Reference values may come from a decommissioned legacy tool, from independent calculations, or from the tool itself once its outputs have been reviewed. Their source must always be identifiable (§15.6).

This section defines the generic mechanism. Methodology review, and the status of a methodology as accredited, remain governed by §19.

### 15.2 Relationship to unit testing

Accreditation tests run in the same test run as the unit tests in §14 and are subject to the same quality gate (§14.6). They answer a different question.

| | Unit tests (§14) | Accreditation tests (§15) |
|---|---|---|
| Question | Is each function correct, and does it own its behaviour? | Does the assembled pipeline still produce the signed-off financial results? |
| Input | Small synthetic cases for one function | Fixed scenarios run through the complete pipeline |
| Expected values | Derived in the test from the formula or a boundary condition | Reference values reviewed and frozen in a reference file |
| Scope | One module, helper, or layer | The whole DAG and the outputs of every layer |
| A failure means | A function or its orchestration is wrong | An accredited output has moved: a defect or an unapproved methodology change |
| Who may change expected values | The developer, together with the code change | Only through re-accreditation (§15.9) |

The two are complementary, not substitutes. Every helper can be correct while their combination breaks a convention the reviewer signed off, such as timing, day-count, or sign. Accreditation tests must not test individual helpers, and unit tests must not reproduce accreditation scenarios.

### 15.3 Why accreditation is executable

- **Repeatable evidence.** Fixed fixtures and a fixed reference file give the same result on every run, independent of the source that produced the reference once it is decommissioned.
- **Regression gate.** Reference values are frozen. A change that moves an accredited value beyond tolerance fails the test, and a failing change must not merge (§14.6).
- **Few pipeline runs.** Scenarios run together as entities, with one run per distinct set of portfolio-wide models, so the test stays fast as scenarios are added.
- **Generic mechanics written once.** The comparison logic lives in `skatkis` and knows nothing about any tool's entities, rates, or expected values. Adding a scenario or product is a data change, not a code change.
- **Complete failure reports.** A failing run lists every value outside tolerance, not only the first, so a reviewer sees the whole drift and can use it as audit evidence.

### 15.4 Ownership: shared infrastructure and tool

This follows §3.2. Shared code contains nothing about a tool's entities, rates, or expected values. A tool contains nothing about how values are compared.

| Item | Owner | Current location |
|---|---|---|
| Comparison mechanics: run the pipeline, flatten the reference, read pipeline values at entity and time grain across all runs, compare, report, assert; the tolerance constant | `skatkis` | `Toolbox/skatkis/accreditation/compare.py` |
| Scenario expansion, serial ids, the frozen inputs file, and rebuilding pipeline fixtures from it | `skatkis` | `Toolbox/skatkis/accreditation/runs.py` |
| Reading and writing files (CSV, Excel, JSON; a path or a buffer) and reading a completed pipeline's results as records | `skatkis` | `Toolbox/skatkis/io/` |
| The reference-file rules (the one writer, metadata, sign-off, backfill, find, remove) and their repository | `skatkis` | `Toolbox/skatkis/accreditation/references.py` |
| The accreditation workbook: choosing examples by their variations, assembling and writing the sheets and preface (§15.8, step 11) | `skatkis` | `Toolbox/skatkis/accreditation/workbook.py` |
| Tests of the accreditation workbook | `skatkis` | `tests/skatkis/accreditation/test_workbook.py` |
| Tests of the comparison mechanics | `skatkis` | `tests/skatkis/accreditation/test_compare.py` |
| Tests of the scenario inputs | `skatkis` | `tests/skatkis/accreditation/test_runs.py` |
| Tests of the reference rules, and of reading and writing | `skatkis` | `tests/skatkis/accreditation/test_references.py`; `tests/skatkis/io/` |
| Scenario declaration: scenario types, base models, and the hook that derives values and drops impossible combinations | Tool | The tool's `accreditation/fixtures/scenarios.py` |
| The frozen inputs file | Tool | The tool's `accreditation/` folder (path set in the scenario module) |
| Reference data and its provenance record | Tool | The tool's `accreditation/` folder |
| Extraction steps specific to one legacy source | Tool | Recorded in the tool README |
| The accreditation test: parametrisation and one call into `skatkis` | Tool | `tests/<tool>/test_accreditation_<tool>.py` |
| The accreditation workbook's examples and preface text | Tool | The tool's `accreditation/examples.py` |

The scenario API of `skatkis.accreditation.runs` is `ScenarioType`, `generate_inputs`, `update_inputs`, and `load_runs`. The current public API of `skatkis.accreditation.compare` is `run_pipeline`, `reference_to_frame`, `compare_reference`, `variances_to_frame`, `assert_accredited`, `compare_value`, the `Variance` record, and the `RELATIVE_TOLERANCE` constant; pipeline values are read through `skatkis.io.pipeline_metrics` and `pipeline_entries`, which accept one pipeline or several, one per run. The reference rules in `skatkis.accreditation.references` take a `ReferenceRepository` (`JsonReferenceRepository` for the file, `InMemoryReferenceRepository`): `write_references` (the one writer, for entries from the legacy workbook or the pipeline), `sign_off`, `load_references`, `reference_metrics`, `find_references`, `remove_references`, and `backfill_meta`. The accreditation workbook in `skatkis.accreditation.workbook` is `Example`, `scenario_catalogue`, `select_examples`, `build_example_sheets`, `examples_section`, and `write_examples_workbook`. The entity key and time-index column names are parameters (`index_col` and `order_col`, defaulting to `loan_id` and `mob`), so other tools pass their own.

The comparison module reaches pipeline data only through the registry (§7): computed layers through `contract_keys()`, then source models through `model_keys()`. It never re-runs or reconstructs pipeline logic.

The accreditation package is a development-time utility. It defines no reader or writer: it reads and writes through `skatkis.io`, and it is never imported by pipeline code or layer logic, consistent with the prohibition on hidden file reads in §2.3.

### 15.5 Scenarios and identity

A scenario is one entity run through the pipeline with fixed, explicit inputs. Scenarios are declared, expanded, and then frozen into an *inputs file*. The accreditation test runs the frozen inputs and never regenerates them.

**Declaring scenarios.** A tool lists its *scenario types* (`ScenarioType`). Each names the base model it changes, what it varies, and its variations. A plain value sets the field the type is named after, for example `payment_frequency` set to `"quarterly"`. A dict is merged into the model, so one variation can change many fields at once (all fees and costs) or none (`{}`, the baseline). Every combination of one variation per type is a scenario, so adding a dimension means adding one type, not editing a loop. Every product or strategy registered under §10 must be covered. Values that depend on several variations, such as a first payment date, and combinations that cannot exist, such as a first payment after maturity, are handled by one small tool-side hook and never by hand.

**Serial ids.** Each scenario gets a serial id (`S0001`, `S0002`, ...) once, in order, when it is first stored. The serial is the entity id in the pipeline input and the key in the reference file. What a serial means is recorded in its `description`, not encoded in the id: for every variation, the model, the scenario type, the variation name, and the exact change it made. Ids stay short however many dimensions are added, and they never move.

**The inputs file.** One JSON file holds, for every serial, the resolved record, the resolved copy of every non-record model that the scenario changes (for example the portfolio economics row), and the description. Models that no scenario changes, such as the PD and LGD tables, are stored once as shared models. The inputs file and the reference file (§15.6) share one index, the serial id. The inputs file holds what went in, and the reference file holds what comes out.

**Appending, never rewriting.** `update_inputs` expands the declaration and compares each combination, by its resolved inputs, with the stored scenarios. A match keeps its serial, and a new combination is appended with the next serial. Stored scenarios are never edited, reordered, or removed. A stored scenario that the declaration no longer produces is reported as retired and is kept and still run. Because identity is the resolved inputs and not the variation names, adding a type whose default changes nothing leaves every id untouched, and changing a value creates a new scenario instead of altering an old one. A shared model that has drifted from its frozen copy is reported, and the frozen copy is kept.

**Runs.** Some models apply to a whole run: portfolio economics is one row for every entity, so scenarios that differ in it cannot share a pipeline run. `load_runs` groups the stored scenarios into one run per distinct set of such models. The comparison takes all the runs together (§15.7), so the split is invisible to the reference file and to the test.

**Coverage.** Only scenarios with a reference entry are compared. A scenario can be stored before its reference values exist, and reference entries without a stored scenario are ignored, so the scenario set can be narrowed or widened without editing the test or the reference file.

**Determinism.** Inputs use explicit dates and values (§2.3). They never use the current date or random draws.

**Why the inputs are a frozen registry.** Generating the inputs from code on every run would be simpler, and it was the first design. It was rejected for these reasons:

- A reference value is only meaningful for the exact inputs that produced it. If the test rebuilds its inputs each run, an edit to a default, a fee, a term date, or a base table changes what the pipeline is fed while the reference stays the same. The test then fails for the wrong reason or, worse, passes against inputs nobody reviewed. Frozen inputs bind every reference value to the inputs behind it.
- An id derived from labels or list positions changes when a list is reordered or an option is inserted, which silently points frozen reference values at the wrong scenario. A serial assigned once and recorded never moves.
- The meaning of a combination is recorded, not encoded. Encoding the dimensions in the id makes it grow with every new dimension. A description in the registry keeps ids short and still answers what exactly a serial is.
- Appending gives an audit trail. Extending the sweep never alters history, and retired scenarios stay visible instead of vanishing.
- The inputs file is also the single list of what to key into the legacy tool, so the manual entry and the pipeline start from one definition.

The cost is more machinery: a file, an update step, and a guard test (§15.10) that fails when the declaration has moved on without the file. That cost is accepted because accreditation exists to be auditable and stable over years, not convenient to regenerate.

### 15.6 Reference data contract

A reference file is JSON with entity-level entries, optional portfolio-level totals, per-entity notes, and per-entity metadata. Entries are keyed by the serial id of the inputs file (§15.5):

```json
{
  "facility":  { "<entity_id>": { "<metric>": "<scalar, or list in time-index order>" } },
  "portfolio": { "<metric>": "<scalar>" },
  "notes":     { "<entity_id>": "<known limitation of the reference source>" },
  "meta":      { "<entity_id>": { "source": "<source>", "created": "<UTC date>", "version": "<label>", "revision": 1 } }
}
```

`facility` is the current name of the entity-level block, because fair value's entity is a facility.

Conventions:

- **Metric names are pipeline column names.** Names used by the reference source are translated at extraction. For example, the legacy label `taxation` is stored as `tax`. The comparison therefore needs no mapping table, and each translation is a reviewed decision recorded in the tool README.
- **Scalars and series.** Both sit in the entity block. A series is a list in time-index order whose first element is the first time index. Blank source cells are stored as `null` so positions stay aligned.
- **Portfolio totals.** The `portfolio` block holds only genuine totals. Each value is compared with the sum of the pipeline column over the entities listed in the entity block. Single-entity values and portfolio-wide single values do not belong there.
- **One file, many entries.** Legacy and tool-generated entries share the one file. Adding or re-extracting an entity replaces only that entity's entry and note.
- **Stored as produced.** Values are kept exactly as the source produced them, unrounded.
- **Frozen.** Once reviewed and signed off, an entry changes only through §15.9. Sign-off is stamped in the entry's `meta`, and the writers refuse a signed-off entry unless the change is a deliberate re-accreditation.
- **Independence.** An entry derived from the tool under test is a regression baseline, not an independent reference value. Its `meta` record has `source` set to `"tool"`. Entries extracted from the legacy workbook carry `"legacy_tool"`, and an entry with no record is treated as `"legacy_tool"`. The writer refuses to replace an existing entry with one from a different source, so a tool-generated baseline can never overwrite an independent reference value, or the other way round.
- **Metrics to freeze.** Entries generated from the pipeline store only the canonical columns that the original reference entries already define (`reference_metrics`), never whole output tables.
- **Metadata and roll-back.** Each write records, per entity, a `meta` record kept apart from the entry, so the entry keeps the shape the comparison reads. The record holds the source, the UTC date of the write (shared by every entity in one call), a version label (default `"1"`, overridable by the caller, for example with the tool version or a git commit), and a revision counter that rises each time the entry is replaced. Entries written before metadata existed are filled in once with `backfill_meta`, which fills only missing fields and never overwrites. The reference file is under version control, which is the roll-back mechanism. The record identifies which entries a change touched, so entries written by mistake can be found (`find_references`) and removed (`remove_references`).
**Why the reference values are a registry.** The reference values are not just numbers in a file. Each entry is a record with a source, a date, a version, and a revision, kept apart from the values themselves.

- Legacy values cannot be regenerated. They came from a manual run of a decommissioned tool, so they are irreplaceable evidence. Treating them as records protects them from being overwritten, and the source marker lets the writer refuse to replace an entry with one from a different source.
- Different sources prove different things. A legacy value is an independent check, whereas a value generated from the tool under test only guards against regression. Keeping both in one file keeps the accreditation check in one place, and the source marker keeps them distinguishable. Before this, the origin of a value was informal knowledge, which cannot be audited.
- Mistakes must be recoverable. Entries written by accident can be found by source, date, or version and removed, and the date, version, and revision support back-testing and roll-back alongside version control.
- Keeping the record in `meta` leaves the values in exactly the shape the comparison reads, and keeps record fields from being mistaken for metrics.

### 15.7 Comparison semantics

**Locating pipeline values.** The comparison module maps each metric name to the first entity-keyed DataFrame that carries it, scanning computed layers first, then source models, and skipping frames without the entity key. A caller may pin a metric to a specific registry entry when a name occurs in more than one. The comparison accepts one pipeline or a list of them, one per run, and combines their rows, so a single call compares the whole reference file whichever run each entity was in. An entity id that appears in more than one run is rejected. Because source models are included, input values extracted under canonical names are compared with the scenario's own inputs by the same call, which gives an automatic input check for scalar inputs.

**Alignment.** Scalars are compared once per entity. Series are compared by position: element *i* of the reference against the entity's *i*-th pipeline row in time-index order. The time index is carried into failure messages. The reference extraction must therefore start at the first time index. Dates are compared as text on their first ten characters.

**Tolerance.** The default is a relative tolerance of 0.5%, held as one constant. When the expected value is zero, the check is absolute against the same number. The value is provisional and is a governed parameter. Changing it is a change to accreditation and follows §15.9.

| Status | Meaning |
|---|---|
| pass | Within tolerance |
| fail | Outside tolerance, a blank pipeline value against a real reference value, or a series of different length |
| skipped | The reference value is blank, so nothing is compared |
| missing | The reference value has no pipeline counterpart, for example an unknown column or a scalar against a time-indexed column |

**Reporting.** The comparison never raises. It returns one `Variance` record per compared value, which `variances_to_frame` turns into an evidence table. `assert_accredited` raises once, listing every failed or missing value with status counts, so a single run shows the whole drift.

This output is accreditation evidence. It is separate from the post-run notices in §13.6. Those notices record valid conditions and never block execution, whereas a failed or missing accreditation comparison fails the test.

### 15.8 Process and sign-off

The working procedure, step by step, with the functions for each step, is in the skatkis reference §7.1.

1. Declare or extend the scenario types in the tool and run `update_inputs`. New combinations are appended with the next serials, and the inputs file is committed with them.
2. Take the reference source's inputs from the inputs file, the stored record and models, and not from code, so both sides start from one frozen definition.
3. Run the reference source with those inputs and save the result. For a manual source such as a spreadsheet, this is done by hand, one scenario at a time.
4. Extract the outputs into the reference file under the serial id, translating names to canonical pipeline column names. Extraction is specific to each tool and source.
5. Record provenance next to the reference data: the source file name and hash, sheet and cell or column references, calculation date, who extracted it, and reviewer sign-off. A docstring is sufficient. Because entries are added over time, record the source hash per entry.
6. Run the pipeline over the frozen runs and compare everything in one call. Resolve input and naming mismatches first.
7. Give every genuine divergence a disposition. Either explain it and record it in the entity's note as a known limitation of the reference source, or treat it as a defect in the tool. No divergence may remain unexplained at sign-off.

Which source references each case, and how informal checks, keyed inputs and hand corrections are handled in steps 2 to 7, is set out in §15.11.

![Accreditation sign-off](skatkis/docs/accreditation_signoff_flow.png)

**Sign-off procedure, version 1 (2026-10-17).** Sign-off has two stages: a differences review (steps 8 to 10), then the accreditation documents (steps 11 and 12). The documents of both stages are kept together in the tool's `docs/sign_off/` folder and referenced from the tool README.

8. Prepare the differences presentation, which lists every difference from the reference source. For each it states whether it corrects a shortcoming of the reference source, expands the tool's capability, or remains a known limitation, with its effect on the outputs and the proposed disposition.
9. Hold the sign-off meeting. The financial logic authority reviews the differences, understands the reference source's shortcomings and how the tool improves on them, and decides for each difference whether it is accepted and which route is taken. The tool is updated to those decisions. The meeting and its decisions are part of the accreditation record.
10. Freeze the agreed routes. Every route decided in the meeting is added to the reference tests (new scenario types or serials, and their reference values) and frozen, so the decision is enforced from then on (§15.9).
11. Prepare the accreditation documents for formal accreditation:
    - **The financial logic document.** The financial logic of the whole tool, one section per layer in pipeline order, with the tool's flow chart. It is written for financial professionals expert in the field: each layer opens with what it takes from the layer before and what it produces, and each definition is given as a formula with a short account of what is particular to the tool. Every definition or statement taken from a source carries a numbered citation by the formula or claim it supports, and a references section at the end lists the sources in order of first citation, as in a journal paper. A definition that no standard or recognised professional text prescribes is *in-house* and cited to the first reference, which names the tool's in-house conventions. About ten pages, the references excluded. It is drawn from the tool README, which remains the authority, and states the code version it describes. Before issue, every formula is checked against the code, and any difference is resolved as a contradiction (§22.1).
    - **The accreditation workbook.** Worked examples of every product the reference source confirms, chosen from the accreditation scenarios, each traced from its inputs to the valuation and checked against the reference source: against its references in full, or against the headline results of an informal check. An example is never checked against the tool's own references, which would compare the tool with itself. The workbook is built by the shared accreditation workbook in `skatkis`, not by hand. A preface sheet records the tested scenario range, which references come from the reference source and which from the tool and why (§15.6), any informal checks against the reference source, and each example's serial with its scenario combination. For every example confirmed by the reference source, the inputs keyed into it are listed by serial in the accreditation notebook, and each saved run of the reference source is named by the same serial, so every number in the workbook can be traced to the reference source's own inputs and outputs. The examples are referred to from the financial logic document, not repeated in it.
12. The reviewer signs off on the accreditation documents. The inputs file, reference data, and provenance are committed together, and the tool is recorded as accredited only after governance sign-off (§19.2).

Controls:

- **Input parity.** The reference source is keyed from the frozen inputs file, and scalar inputs extracted under canonical names are checked automatically (§15.7). Everything else, such as dates, term structure, and lookup tables, is a manual check with a named reviewer, because reference sources differ too much to automate generically. The inputs of the worked examples are listed per serial for that check (step 11).
- **Provenance.** It is kept as a record beside the data, not inside the reference file.
- **Dispositions.** They are recorded, not remembered.

### 15.9 Changing accredited behaviour

- **Methodology changes.** A change to financial methodology (§12.5, §19.1) that moves accredited outputs requires re-accreditation: a new reference obtained from a reviewed source, updated provenance, and reviewer sign-off. The accreditation data changes in the same change as the methodology approval, not before it.
- **Refactors.** A refactor must leave every accredited output within tolerance. If it does not, it was not a refactor (§12.5).
- **Never to pass a test.** Do not edit stored inputs, edit reference values, widen the tolerance, or remove or narrow scenarios so that a failing test passes. A legitimate change to any of them follows §15.8 with recorded approval.
- **Changing an input.** A changed input is a new scenario, not an edit. `update_inputs` appends it under a new serial, and the old serial stays with its reference values and is reported as retired. The new scenario needs its own reference entry.
- **New products.** Adding a product or strategy adds its scenarios (§10.5) and, where a reference source exists, its reference entries.
- **Tool-generated entries.** Entries generated by the tool under test are permitted as regression baselines. They are marked as such (§15.6) and reviewed before being treated as accredited.

### 15.10 Structure of the accreditation test

Each tool has one accreditation test module, `tests/<tool>/test_accreditation_<tool>.py`. It follows the same pattern for every tool and holds no expected values, rates, or entity definitions.

1. **Frozen inputs.** The module reads the inputs file once at import through the tool's `load_runs()` and never regenerates the scenarios. It loads the reference file at import too. A missing or unreadable file is a collection error, never a silent skip. It compares only the reference entries whose serial is in the inputs file, so the test is agnostic to the size of the scenario set (§15.5).
2. **One pipeline per run.** A module-scoped fixture runs the pipeline once for each run in the inputs file, and every test in the module shares those runs. The pipeline import happens inside this fixture, so a missing dependency fails the accreditation tests with a clear error instead of breaking test discovery for the whole repository.
3. **Guards.** One test fails if no reference entry matches a stored scenario, so a mismatch between the two files can never leave nothing compared. A second runs `update_inputs` against a throw-away copy of the inputs file and fails if the declaration would add a scenario, meaning it has moved on without the file being updated and committed, or if a shared model differs from its frozen copy. The real file is never touched.
4. **One test per entry.** A parametrised test takes the serial id as its parameter, and the test id is the serial followed by its variations, for example `S0007-bullet_payment-long-monthly-nofees`. A failure therefore names both the serial and the scenario, and one scenario can be run with `-k S0007`. The test makes one call to compare that entry across all the runs (§15.7) and one call to assert.
5. **Portfolio totals.** One test compares the portfolio block when the reference file has one. When it has none, the test reports a skip with its reason instead of disappearing as an empty parameter set.
6. **Failure output.** The assertion lists every value outside tolerance, with scenario, metric, time index, actual, expected, and relative difference (§15.7).

**Real numerics, no mocks.** Accreditation tests run the real pipeline against the real numerical libraries. They never mock, stub, or patch pipeline code or those libraries. A repository harness that substitutes a library when it is missing (§14.5) must not substitute one that is installed, and the accreditation test fails loudly, with instructions, if a substitute is active.

**Where the testing effort sits.** The comparison and extraction mechanics carry the heavy unit-test coverage. They are tested once, in `skatkis`, in `tests/skatkis/accreditation/test_compare.py`, `test_runs.py`, `test_references.py`, and `test_workbook.py`, and in `tests/skatkis/io/`, mirroring the source modules (§14.1) and using synthetic entities (§14.2). The tool's accreditation test stays a thin caller of those mechanics.

### 15.11 Choosing the reference for each case

The reference source is there to confirm the tool's results from outside. Each case is referenced by the strongest source that is valid for it, and the choice and its reason are recorded per case in the tool README.

1. **The reference source, where it is a valid benchmark.** A case is legacy-referenced only where the reference source models it correctly. A known shortcoming of the source (an approximation, a convention it cannot represent, a range where its method breaks down) limits the scope of its references, for example to a range of terms or to regular payment dates, rather than being carried into the reference values.
2. **Keyed inputs, where one quantity is approximated.** When the reference source approximates a single quantity that drives the rest (for example a level payment), the tool's exact value may be keyed over it by hand, and the source computes every other value from it. The keyed quantity confirms nothing by itself; every value computed from it is an independent check. The keyed quantity is recorded in the entry's note, and in the tool README as an accepted difference.
3. **Informal checks, where series cannot be aligned.** When the reference source cannot produce comparable series for a case (for example it holds a loan in one row), its headline results per entity (for `fair_value`, the fair value and the IRR) are compared by hand with the tool's. The results, and any accepted difference such as a day count, are recorded in the tool README. The case is then referenced by the tool's own output (`"tool"`, §15.6), and the accreditation workbook checks its examples against the informal figures (§15.8, step 11).
4. **The tool's own output, everywhere else.** A regression baseline, reviewed before sign-off, never presented as independent (§15.6), and never used to confirm a worked example.

**Hand corrections.** A reference value may be set by hand only where the reference source leaves a cell blank or wrong for a reason recorded in the tool README (for example an opening balance the source does not show). Each correction is recorded in the entry's note, keyed by the serial, and is part of the reviewed reference; a reference value is never corrected to make a comparison pass (§15.9).

**Notes.** Notes in the reference file are keyed by serial, one per entry, so each attaches to the entry it describes: a known limitation of the source, a keyed quantity, or a hand correction. A note is short, one line naming what was done, for example "used fixed_payment value from tool"; the reasons are in the tool README.

### 15.12 User testing, version 1

**Why.** Accreditation shows that the tool's results are right on clean inputs. It does not show that a person can get a client's data through the tool to those results. Client data arrives in many shapes, and preparing it (column mappings, labels, missing and malformed values) is the most time-consuming part of an engagement. User testing is the last step before a tool is released to production, after accreditation and sign-off: an experiment that puts the tool in front of its users and records where they struggle. Its findings improve the error messages, the error register and Steward's guidance, and inform the design of the user interface (§17).

**The exercise.** The user is given a corrupted client-style export of a small portfolio and a set of tasks, and works through them with the tool's own client notebooks.

- **The portfolio** is a subsample of the accreditation scenarios, chosen by a fixed rule that covers every scenario variation at least once (`skatkis.fault_injection`). It is stored as a seed in `Toolbox/<tool>/ui_test/seed.json`, with the scenarios' reference values. The seed is rewritten only when the accreditation inputs change, and then for the same serials, so the exercise keeps its loans and the accreditation framework keeps confirming its clean results.
- **The faults** are injected into the seed when the export is written to `ui_test/corrupted/`: one fault per kind of data-quality error (a misnamed mapping input, an untranslated label, text in a numeric column, a missing value, a duplicate, a gap in a curve, an unrecoverable record, an instrument supplied at two levels), and faults that end in a silent default rather than an error. The list of faults, the answer key, stays in `ui_test/`, out of the exercise folder. The seed and the export are protected and written only by the refresh.
- **The tasks**, in `Clients/client_x/<tool>/user_test/`: fix the mappings and clean the data until the input check passes; run the pipeline and compare its results with the seed's references at the accreditation tolerance (§15.7); and the sensitivity analyses of a review, for `fair_value` an upper and lower bound on fair value (every facility one risk band better and one worse) and the rate at which each loan earns the hurdle rate. Each task states what to achieve, the tools at the user's disposal and the expected result; none contains its solution.

**Steward's teaching role.** Steward sets the exercise as an examiner sets a paper: the tasks, the tools and the expected results, never the solution. It answers the user's questions by pointing to what to check first and the tool to use, plays the client for values the data cannot repair, and at the end asks the user for a report: the questions asked, what was unclear, which errors did not lead to their cause, and how long each task took. On a client's real data, by contrast, it gives the exact fix when it knows it.

**What is recorded.** Every failure is classed as a *hard fail* (the run stops with an error) or a *soft outcome* (the run completes on an assumption: a defaulted value, an ignored column, a dropped row, an implicit methodology choice). Hard fails go into the error register, one entry per kind of error and source, keyed `<tool>/<source>/<error>`, with how the error is shown, where it fires, what to check first and the fix (`steward/instructions/error_register.md`). Soft outcomes become report checks (§13.6). A message that did not lead the user to the cause is made more descriptive.

**Unit tests.** One unit test per kind of fault confirms the error it raises, and drift checks fail when the seed or the export no longer matches what the accreditation inputs and the answer key generate. They are kept light: the assertions themselves are tested where they are owned (§14.1).

**Not accreditation.** The exercise's runs are what-if runs (§17.5). Their results confirm the user's work against the references; they never change, extend or stand in for accredited references (§15.9).

**Limits of version 1.** A run stops at the first stage that fails, so the user meets the faults in rounds: mapping and casting report one problem at a time and the sources load one after another, while each source's schema gate reports every rule and row at once. Collecting every input error in one run is planned for a later version.

---

## 16. Pipeline orchestration standards

### 16.1 DAG as data

The pipeline order must be represented explicitly, for example:

```python
_DAG = [
    ("term", build_term_schedules, "facilities"),
    ("cash_flow", compute_cashflow, "term"),
    ("exposure", compute_exposure_metrics, "cash_flow"),
]
```

The orchestrator iterates the DAG. It must not duplicate the calculation contents of each layer.

### 16.2 Registry update

After a layer completes:

1. order output fields according to contract grain and output schema;
2. update the layer’s registry contract entry;
3. store the result for external access;
4. make the result available to downstream hydration.

### 16.3 Independent terminal branches

A DAG may contain multiple terminal layers consuming the same upstream result. Such layers are logically independent even if the current implementation executes the DAG sequentially.

Do not imply concurrent execution unless the pipeline actually implements concurrency.

### 16.4 Pipeline construction

Use explicit constructors or `from_paths` factories to separate file-system concerns from calculation execution.

The pipeline constructor should receive validated source models or equivalent source objects. `from_paths` may call `io.py` and return a ready-to-run pipeline.

### 16.5 Result access

The pipeline should expose completed layer results through a controlled API, such as:

- a `results` mapping;
- a `result(layer_name)` accessor.

Access before execution should raise clearly.

---

## 17. User interface and deployment interface

### 17.1 Purpose and boundary

`skatkis.pipelines.ui` (`Toolbox/skatkis/pipelines/ui.py`) is the interface between a completed pipeline and everything that uses it: notebooks, reports, a web front end, scheduled jobs, and the deployment (CI/CD and container images). It is how a user or a service asks "what if this input were different?", "which input produces this result?", and "show me the loans side by side" without touching the pipeline's internals.

The rule is that consumers reach a pipeline through this layer and the registry. They do not import a tool's layer functions, contracts, or schemas, and they do not write into a tool's DataFrames. The layer is generic. It imports no domain pipeline, schema, model, or contract definitions, so it works for any pipeline that satisfies `RunnablePipeline` (§17.2).

### 17.2 The pipeline protocol

A pipeline qualifies by shape, with no base class to inherit. `RunnablePipeline` is a runtime-checkable protocol that requires:

- `registry`: the `PipelineRegistry` holding source models, contracts, and completed contract outputs (§7);
- the result mapping maintained by the concrete pipeline;
- `run(start_layer=None)`, which runs from the named layer, or from the beginning, and returns a pipeline.

Running from a named layer is what lets an override rerun only what it affects. A pipeline that has been through `solve_column` also carries a `solvers` dict keyed by `(input_column, target_column)`. A pipeline that has never been solved simply lacks it, so read it with `getattr(pipeline, "solvers", {})`.

### 17.3 What the layer provides

| Group | Functions | What it does |
|---|---|---|
| Overrides | `override_column`, `override_columns` | Change source columns at their declared source and rerun once from the earliest layer any of them feeds. A value is a scalar broadcast to every row, an index-aligned Series, or a function of the current column |
| Solvers | `solve_column` | For every loan, vary one source column until a target output reaches a requested value, using a vectorised secant method. It returns a pipeline with the best input already applied and records a `SolverResult` under `pipeline.solvers` |
| Introspection | `describe_column`, `list_input_columns` | Read-only description of the schema-declared input columns: the first consuming layer, the source, the downstream layers, and the current value (`ColumnInfo`) |
| Summaries | `build_summary`, `build_display_summary`, `build_scenario_summary`, `map_column_values`, `convert_date_columns` | A flat per-loan table from an internal-to-display name map, a display-ready transposed version, and several pipelines side by side for scenario comparison |

The solver assumes a monotonic relationship between the input and the target for each loan. It decides convergence from the best error actually observed against `target_tolerance`, not from the optimiser's own stopping flag, and each loan reports its own result.

### 17.4 Behavioural contract

1. **Completed pipelines only.** Overrides and solvers act on a pipeline with no pending contracts and raise otherwise.
2. **Nothing is mutated.** Every function that changes inputs returns a new pipeline. The pipeline passed in, and its registry, are untouched.
3. **No deep copies.** A changed registry is built with `PipelineRegistry.clone_with_override`, which shares every unaffected entry by reference. Reruns replace entries copy-on-write (§7). A consumer must therefore never modify a returned DataFrame in place, because it may be shared.
4. **Minimal reruns.** The rerun starts at the earliest layer that consumes an overridden column. Several overrides share one rerun.
5. **Inputs, not logic.** An override is applied at the registry source that the column declares, never to a computed output. The financial logic is unchanged and only its inputs differ.
6. **Validation is shared.** The checks live in `skatkis.pipelines.validation` (§13). The UI layer calls them and defines none of its own, so failures are explicit and consistent.
7. **Display helpers present, they do not calculate.** Relabelling, day-level date strings, and transposition never change a calculated value. A value missing from `value_map` passes through unchanged. `value_map` applies to every column including the index, so check that no loan identifier collides with a key.

### 17.5 Relationship to accreditation

Accreditation (§15) proves the financial logic on frozen inputs. The UI layer can only change inputs through the same registry sources, so every number a user sees is produced by the accredited logic on different inputs and never by a parallel implementation.

The accreditation comparison reads pipeline values from the registry (§15.7). It does not depend on the summaries here, so a presentation change cannot affect accreditation. Results from overrides and solvers are what-if runs. They are not accredited unless they are recorded as scenarios (§15.5), and a front end must label them as what-if results.

### 17.6 Deployment interface

The UI layer is intended to become the interface between the pipeline and its deployment. The details of the container image, the entry point, and the web front end are to be defined when they are built. These principles apply now:

- A deployed service, job, or container drives a pipeline only through its public constructors (`from_paths` or `from_records`, §16.4), `run`, and this layer.
- The image is built from the pinned environment (§20) with the real numerical libraries. It contains no test shims.
- The accreditation test (§15) runs in the same environment as the image that will be deployed, and a failing accreditation blocks promotion to production.
- Configuration enters through constructors and parameters, never hidden globals (§2.3).
- The code base uses Python 3.14 syntax (for example, multiple exception types without parentheses), so the interpreter in every environment and image must be 3.14 or later.

### 17.7 Extending and testing the layer

A capability that is not specific to one tool belongs in `skatkis.pipelines.ui`. It is implemented and tested there, then consumed by tools (§3.2). Which columns to show, their display names, and their value maps are tool configuration (`column_map`, `value_map`), kept in the tool.

The layer is tested once, in `tests/skatkis/pipeline/test_ui.py`, mirroring the module (§14.1), with synthetic pipelines and entities (§14.2). `solve_column` uses `scipy.optimize.newton`, so its tests run with the real library or patch `newton` in the `ui` module's namespace (§14.5). A tool's tests only check that its maps refer to columns that exist.

---

## 18. Instrument and configuration factory pattern

### 18.1 Purpose

Use factories when several configuration concepts have a common structural contract. This is distinct from a behaviour registry.

Examples:

- fees and costs with value, rate, frequency, growth, and basis;
- scenario definitions with name, weight, and parameter source;
- collateral types with haircut and recovery assumptions.

### 18.2 Structure versus behaviour

The shared factory defines structural roles and schema metadata. The tool selects which instruments exist. The analytical layer defines:

- amount calculation;
- compounding;
- growth;
- basis resolution;
- event conditioning;
- inclusion in income or cost totals.

A schema factory must not become a hidden calculation engine.

### 18.3 Event conditioning

When instruments share amount logic but differ by event timing, use thin wrappers around a generic amount engine.

Examples:

- drawdown fee only when disbursement is positive;
- initiation fee only at origination;
- recurring fee without an event filter.

Tests should separately verify generic amount logic and wrapper event conditions.

---

## 19. Methodology and model governance

### 19.1 Methodology-controlled changes

The following require methodology review and, where applicable, model-risk or regulatory accreditation:

- PD derivation, scaling, annualisation, or floors;
- LGD blending, downturn adjustment, or floors;
- collateral depreciation or recovery treatment;
- correlation and maturity formulas;
- capital calculations;
- economic capital definitions;
- ECL discounting;
- tax treatment;
- valuation rates or time exponents;
- exact versus approximate product calculations;
- introduction of stochastic behaviour.

### 19.2 Accreditation state

A helper may exist before it is activated in the production pipeline. Documentation must distinguish:

- available analytical utility;
- active production pipeline behaviour;
- controlled future implementation;
- accredited methodology.

Do not document an available helper as active merely because the function exists.

In this SOP, *accreditation* has its financial-model-governance meaning: the outputs of a methodology have been reviewed and signed off. The signed-off values are held as frozen reference data, and §15 defines the executable test that keeps the tool faithful to them. A methodology is not described as accredited unless that review and sign-off is recorded.

### 19.3 Change completeness

A production change is incomplete until all affected artefacts agree:

- source or layer implementation;
- schema;
- layer contract;
- validation;
- unit tests;
- integration tests;
- tool README;
- methodology references;
- accreditation scenarios, reference data, provenance, and sign-off records where the change affects accredited outputs (§15);
- release records where required.

---

## 20. Reproducibility and dependencies

### 20.1 Dependency pinning

Production dependencies must be pinned according to repository policy. Package changes require:

- version update;
- test run;
- compatibility review;
- committed environment specification.

The interpreter version is part of the pinned environment. The code base currently uses Python 3.14 syntax, so every environment and container image must run Python 3.14 or later.

### 20.2 Explicit dates and seeds

- Reporting and valuation dates are explicit inputs.
- Random processes receive explicit seeds.
- Seeds are not silently created inside analytical functions.

### 20.3 Environment separation

Development, test, and production configurations must be separable without modifying analytical code.

### 20.4 Execution lineage

Production execution should record, where supported:

- execution timestamp;
- code version;
- dependency snapshot;
- source identifiers or hashes;
- configuration snapshot;
- contract versions or equivalent lineage;
- row counts by layer;
- gate outcomes;
- output identifiers or hashes.

### 20.5 Branches

Work is done on feature branches and merged into the main branch through a pull request, so the main branch always builds and passes its tests ([Microsoft, "Adopt a Git branching strategy"](https://learn.microsoft.com/en-us/azure/devops/repos/git/git-branching-guidance)). Branches are named `<type>/<area>/<description>`, with type `feature`, `bugfix`, `hotfix`, `release` or `users/<name>`. A methodology change or a large refactor should have its own branch, so its effect on accredited outputs can be reviewed in isolation (§12.5, §15.9).

---

## 21. Performance standards

Priority order:

```text
correctness -> clarity -> maintainability -> performance
```

Rules:

- profile before optimising;
- preserve entity-level recursion where methodology requires it;
- vectorise independent row calculations;
- use grouped operations carefully and establish order first;
- avoid repeated merges or group-bys when results can be reused safely;
- do not remove required copies, validation, or auditability for minor speed gains;
- parallelise only where entity independence and deterministic ordering are preserved.

---

## 22. AI-assisted development standards

AI may assist with design, implementation, testing, refactoring, and documentation. AI output is not self-approving.

### 22.1 Required source hierarchy

When assisting on an existing tool, use this authority order:

1. current production Python modules;
2. canonical schemas and concrete contracts;
3. validation implementation;
4. current tests;
5. tool README;
6. repository SOP and higher-level documentation;
7. examples and historical documents.

If sources contradict, report the contradiction before generating a large replacement artefact.

### 22.2 Required review areas

Review AI-generated changes for:

- formula correctness;
- units and time scales;
- product registry compatibility;
- exact versus approximate methodology;
- sorting before recursive or cumulative operations;
- entity-group isolation;
- schema and contract alignment;
- hydration and join coverage;
- validation completeness;
- test ownership;
- input non-mutation;
- absence of hidden paths or client assumptions;
- documentation accuracy;
- accreditation impact: whether the change moves accredited outputs.

### 22.3 Prohibited AI behaviour

AI must not:

- invent missing production logic;
- change production to satisfy stale tests without approval;
- duplicate shared framework tests in every tool;
- silently correct canonical identifiers only in documentation;
- collapse ownership boundaries for convenience;
- treat a methodology change as a refactor;
- introduce unreviewed approximate calculations;
- claim compliance or accreditation not established by governance;
- change reference values, tolerances, or the scenario set so that an accreditation test passes;
- generate reference values from the tool under test and present them as independent or legacy values.

### 22.4 Recommended AI context prompt

Use the following as a starting context for tool work:

> Assist with a deterministic, contract-gated analytical system. Treat current production modules as authoritative. Preserve explicit ownership across schemas, source models, registry hydration, layer contracts, validation gates, analytical layers, product or strategy registries, tests, and documentation. Do not reproduce spreadsheets or collapse layers. Generic engines must remain agnostic; pluggable product behaviour belongs behind registered context-based interfaces. Distinguish calculation refactors from methodology changes. Report contradictions before producing large replacement artefacts. Test only behaviour owned by the module under test, and rely on shared framework tests for generic infrastructure.

### 22.5 Steward

Steward is the repository's AI development assistant. It is a read-only MCP server (`skatkis-steward`, code in `skatkis.steward`) that indexes the code, docstrings, contracts, this SOP, the READMEs and the agent rules, and answers questions about them with the commit they came from. Coding agents use it before writing code: to find an existing calculation, the owner of a column, the rules for a file, or a plan for a change. It never runs a pipeline, never reads client data and never labels anything accredited.

Steward also keeps the record of development work in its workspace, `steward/`:

- the agent rules every coding agent follows (`steward/instructions/AGENTS.md`);
- planned changes, each with a change file and, where needed, a design agreed with the user before code is written: `steward/toolbox/skatkis/CHANGELOG.md` for `skatkis` and Steward, and `steward/toolbox/<tool>/CHANGELOG.md` for each tool. Each change has an ID made of its change log's prefix and a number: `S###` for `skatkis` and Steward, and the initials of the tool's package name for a tool (`FV###` for `fair_value`);
- tool notes (`steward/toolbox/<tool>/notes.md`): development observations about a tool, such as differences from the legacy tool, issues and open methodology questions.

These records are dated and kept current, so design work can be drawn from them. The commentary in an accreditation report (§15) comes mainly from the tool notes, which record each difference from the legacy tool and how it was resolved; the change log is the trail behind it, not a list to reproduce. Steward assists; it does not approve. Every rule in this section still applies to what it proposes.

Details: `steward/steward.md` (purpose, controls, hosting, decision log), `steward/instructions/AGENTS.md` (agent rules, Steward's roles and the change workflow) and repository README §19 (technical reference).

---

## 23. Pre-coding checklist

Before implementing a new tool or material feature:

1. define the business question;
2. identify source models and configuration sources;
3. define canonical entity and time grains;
4. identify state variables and recursive dependencies;
5. identify pure vector calculations;
6. identify product or strategy variability;
7. decide whether variability belongs in data, a factory, or a behaviour registry;
8. define source schemas;
9. define layer input and output schemas;
10. define ownership and derivation metadata;
11. define concrete layer contracts;
12. define validation rules and join coverage;
13. define the DAG;
14. define required unit and integration tests;
15. document methodology and approval requirements.

Do not begin with a large compute function and reverse-engineer architecture afterward. For an existing tool, first read its notes and registered changes in Steward's workspace (§22.5).

---

## 24. Definition of done

A tool or feature is complete only when:

- source mappings are explicit;
- canonical schemas are updated;
- ownership is unambiguous;
- layer contracts are registered;
- hydration paths resolve correctly;
- input and output gates exist;
- calculations are in the owning module;
- generic engines remain agnostic;
- registries contain all supported behaviours;
- formulas and assumptions are documented;
- focused unit tests cover normal, edge, and failure cases;
- contract and validation tests pass;
- pipeline or integration tests pass;
- accreditation scenarios and reference entries exist for behaviour that affects accredited outputs, and the accreditation tests pass alongside the unit tests;
- lint and static checks pass;
- the tool README is current;
- methodology approval or accreditation is recorded where required;
- repository-level documentation is updated if structure or governance changed;
- the change's change log entry in Steward's workspace is current, and any tool note it resolves is updated (§22.5).

---

## 25. Final rule

Stable analytical systems are not created by formulas alone.

Stable scalability requires:

- explicit architecture;
- one source of truth for data contracts;
- controlled source normalisation;
- registry-driven hydration;
- product-agnostic engines;
- registered pluggable behaviour;
- executable layer contracts;
- validation gates;
- immutable ownership boundaries;
- focused unit tests;
- accredited financial logic;
- reproducible environments;
- current documentation;
- disciplined methodology governance.

If a change bypasses these controls, the change is not production-ready.