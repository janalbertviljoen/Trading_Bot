---
paths:
  - "Clients/**"
---

# Client directories (SOP §2.2, §3.4)

- Client code may only set paths, select source files, supply column mappings and
  approved parameter overrides, construct and run pipelines, and produce client reports.
- No reusable calculations, copied production functions or alternative implementations
  of toolbox methodology. If a client needs new logic, it belongs in `Toolbox/` (with
  tests), consumed from here.
- Drive pipelines through public constructors, `run`, and `skatkis.pipelines.ui`
  (§17.1); do not import layer functions or write into pipeline DataFrames. Exception:
  the walk-through notebooks (`Clients/client_x/<tool>/00_start_here` onwards) may import
  and call layer functions and private `ui` helpers, because taking the pipeline apart is
  what they demonstrate.
- Notebooks always live in the client folder, never in `Toolbox/`: this is where client
  nuances are worked out before an engine is extracted into `Toolbox/`, under the
  folder's own lint and format rules. A tool's accreditation notebook is
  `Clients/client_x/<tool>/accreditation/run_accreditation.py`.
- `raw_data/` is client data: read-only for agents (edit-denied), never copied into
  `Toolbox/`, tests, documentation or prompts, never sent to external services.
- Scripts are jupytext `py:percent` notebooks and UI code (display calls, hard-coded
  values): they are not linted or formatted (`pyproject.toml`, the edit hook, the
  pre-commit hook and CI exclude `Clients/`). A rename of a canonical column, function or
  module is still carried into every client script.
