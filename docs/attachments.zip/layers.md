---
paths:
  - "Toolbox/*/layers/**/*.py"
---

# Analytical layers (SOP §4.7, §9, §11)

- One module = one analytical stage. Read the module docstring for what it owns and must
  not compute before editing.
- Public entry point follows §11.1: `df` first, registry second, configuration
  keyword-only, input copied before mutation, output at contract grain.
- Keep the gate sequence of §9: copy → `hydrate_contract_inputs` → input gate → owned
  calculation → output gate → return. Never return partial results after a failed gate
  (§13.5).
- Must not: read files, import or call another layer (layers are wired only in
  `pipeline.py`), contain client logic, recompute upstream-owned measures, or add
  product `if` branches when a registry exists (§10).
- Sort by entity and time index before `shift`, `diff`, cumulative, recursive or survival
  calculations; group operations must not leak across entities (§11.4). Preserve index
  unless aggregating (§11.5).
- Document and keep clipping, denominator replacement, rounding and bounds explicit
  (§11.6, §12.3). Numerical guards must not hide inputs validation should reject.
- Any change to a formula or convention is a methodology change (§12.5, §19.1): say so
  and flag accreditation impact.
- A new or changed output column needs schema, contract, validation, tests and README
  updated together (§5.4, §19.3).
