---
paths:
  - "Toolbox/*/product_types.py"
---

# Product and strategy registries (SOP §4.8, §10)

- A registry module may hold domain logic only to isolate pluggable behaviour behind a
  stable interface. It owns supported identifiers (`PRODUCT_TYPES`), immutable context
  objects, per-product callables and the registry dicts mapping lowercase identifiers to
  callables (§10.2–10.3).
- It must not own portfolio orchestration, source IO, validation gates or unrelated
  calculations.
- Adding a product follows §10.5 exactly: identifier → every registered behaviour →
  registration in all registries → schema allowed values derived from the list → tests →
  accreditation scenarios (§15.5) → README → methodology approval. Do not edit a generic
  engine just to dispatch a new product.
- Exact and approximate implementations must be named and documented as such; an
  approximation never silently replaces an exact calculation (§10.4).
- Use a registry when behaviour differs, not when only values differ (§10.6).
