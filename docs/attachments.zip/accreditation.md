---
paths:
  - "Toolbox/*/accreditation/**"
  - "Toolbox/skatkis/accreditation/**"
  - "tests/**/test_accreditation*.py"
  - "tests/skatkis/accreditation/**"
  - "Clients/**/accreditation/**"
---

# Accreditation (SOP §15, §19.2)

- Accreditation compares a full pipeline run on frozen inputs with signed-off reference
  values. A failure means an accredited number moved: a defect or an unapproved
  methodology change.
- Files for `fair_value`: inputs `accreditation/scenario_inputs.json`
  (`INPUTS_PATH` in `fixtures/scenarios.py`), reference `accreditation/legacy_records.json`,
  legacy source `accreditation/APR_legacy_tool.xlsm`. These are edit-denied for agents.
- **Never** edit stored inputs or reference values, widen `RELATIVE_TOLERANCE`, or
  remove or narrow scenarios to make a test pass (§15.9, §22.3). Legitimate changes go
  through §15.8 with recorded approval.
- New or changed scenarios are appended by `update_inputs` under new serials; stored
  scenarios are never edited, reordered or removed (§15.5).
- Tool-generated entries are regression baselines with `meta.source = "tool"`; never
  present them as legacy or independent (§15.6).
- Ownership (§15.4): comparison mechanics live in `skatkis.accreditation`; the tool
  declares scenarios only. The tool test stays a thin caller with no expected values.
- Accreditation tests run real numerics; never mock pipeline code or libraries (§15.10).
- `skatkis.accreditation` is development-time only; never import it from pipeline, layer
  or source code. It defines no reader or writer: the reference rules in `references.py`
  take a `ReferenceRepository` (`JsonReferenceRepository(path)` for the file) and read and
  write through `skatkis.io`.
