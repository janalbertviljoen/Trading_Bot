---
paths:
  - "tests/**/*.py"
---

# Tests (SOP §14)

- Production is authoritative (§14.2). Modify only tests unless a production defect has
  been separately agreed; report contradictions instead of inventing behaviour; do not
  patch tests to normalise unsupported inputs.
- Test only behaviour the module owns (§14.1, §14.4). Generic `skatkis` behaviour is
  tested once under `tests/skatkis/`, never re-tested in each tool.
- Test files mirror the source tree: `Toolbox/<pkg>/<module>.py` →
  `tests/<pkg>/test_<module>.py` (§14.1). Existing folders `layer/` and `pipeline/`
  predate this; do not rename them without being asked.
- Use synthetic lowercase ids (`a`, `b`). Cover §14.3: exact formula, normal, zero,
  bounds, monotonicity, group isolation, index alignment, non-mutation, event
  conditioning, invalid identifiers.
- Hydration and validation may be patched to isolate layer computation when tested
  elsewhere (§14.4). Library stubs in `tests/conftest.py` are for unit tests only
  (§14.5).
- Keep existing docstrings and style.
