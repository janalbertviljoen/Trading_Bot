---
paths:
  - "Toolbox/skatkis/steward/**"
  - "tests/skatkis/steward/**"
  - "docker/**"
  - ".azure-pipelines/**"
  - ".dockerignore"
  - ".mcp.json"
---

# Steward (component index and MCP server)

- Read `steward/instructions/developer.md` (imported below), "Working on Steward's
  code", before changing Steward's code, image, pipelines or hosting; planned changes
  and their kickoff prompts are in `steward/toolbox/skatkis/CHANGELOG.md`.
- Discuss and agree the approach with the user before writing code; build the product
  in small steps; write unit tests and update documentation only once the user is happy.
- Steward is read-only: queries only, no pipeline runs, no client data, nothing labelled
  accredited. Facts come from code; contradictions are reported, not reconciled (§22.1).
- New coding or maintenance tools go in the `full` profile; only questions a person asks
  before writing code join `LOOKUP_TOOLS` (served to Teams).
- The HTTP app stays behind `ApiKeyGate`; the server must not start over HTTP without
  `STEWARD_API_KEY`.
- A change to behaviour, access or hosting is recorded by the secretary in
  `steward/steward.md` and its decision log.

@../../steward/instructions/developer.md
@../../steward/instructions/writing.md
