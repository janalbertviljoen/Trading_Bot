@AGENTS.md

## Claude Code only

The rules for every role are in `AGENTS.md`; each role's own rules are in its file
beside it. This file holds only what is specific to Claude Code.

- **Roles load on demand.** The `developer` and `secretary` skills
  (`.claude/skills/*/SKILL.md`) load `developer.md` and `secretary.md` when a task
  needs that role, each with the shared `writing.md`; a big change usually loads both. The warden is the `warden`
  subagent (`.claude/agents/warden.md`), with read-only tools and no Bash; start it as
  `developer.md`, "Building and finalising", describes.
- Area rules in `.claude/rules/*.md` load automatically for matching paths:
  `.claude/rules/steward-records.md` brings in `secretary.md` for `steward/`, and
  `.claude/rules/steward.md` brings in `developer.md` for Steward's code, each with
  `writing.md`.
- A PostToolUse hook (`.claude/hooks/post_edit_check.py`) runs `ruff check --fix`, Black
  and, if installed, pyright on every Python file you edit outside `Clients/` and
  `Toolbox/SandBox/`. Fix anything it reports in
  the same turn. Because `ruff --fix` removes unused imports, add an import in the same
  edit as its first use.
- Protected accreditation and raw-data files are denied or prompted for in
  `.claude/settings.json`.
- **No prompts the user did not need.** Claude Code's built-in checks prompt whatever
  the hooks allow, so: never `cd`; read and search with Read and Grep, not the shell or
  `python -c`; keep Bash for plain commands (`git`, `pytest`, `ruff`, `black`,
  `curl -o` into the repository); no paths outside the repository; no files in
  `.claude/`; do not edit `.claude/settings.json` or the guard unless asked. If a
  prompt appears anyway, name the command and take another route. The reasons and
  the Guard's checks are in [guard.md](guard.md) (`/guard`).
- Steward is registered as `skatkis-steward` in `.mcp.json`. Edits to
  `Toolbox/skatkis/steward/` reach the running server only after Claude Code restarts it;
  until then, check behaviour by calling the functions in `Toolbox.skatkis.steward.index`
  from Python.
