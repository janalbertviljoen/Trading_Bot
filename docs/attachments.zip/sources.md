---
paths:
  - "Toolbox/*/sources/**/*.py"
  - "Toolbox/*/io.py"
  - "Toolbox/skatkis/pipelines/sources.py"
  - "Toolbox/skatkis/pipelines/resolvers.py"
  - "Toolbox/skatkis/io/**"
---

# Sources, mapping and IO (SOP §4.4, §4.6, §6, §7)

- A source module owns the boundary from an external source to canonical names: default
  identity mapping, mapping loader, key/value classification, reshaping, source model
  name and schema (§4.6, §6.2–6.3). It never computes downstream analytical outputs.
- External column names are resolved with `ColumnMap`; layers see canonical names only
  (§6.1). The source module, not `io.py`, owns mapping-domain requirements (§6.3).
- A tool's `io.py` owns source construction and one loader per source model; no
  transformations, calculations, schemas or sequencing (§4.4).
- All reading and writing of files goes through `skatkis.io` (`csv`, `excel`, `json`,
  `paths`; `word` and `office_math` for issued Word documents; `images` for the logo on
  flow charts; `memory` reads pipeline results). Each module handles one format, takes a
  path or a buffer, and holds no business rule. New code opens no data file outside it;
  the known exceptions (`pipelines/preface.py`, the experimental `saspy_wrapper`,
  Steward's index) are recorded as follow-ups.
- Optional segment dimensions and broadcast keys are handled by shared `skatkis`
  infrastructure (§6.4–6.5); a source test checks only its own transformation.
- Never mutate the caller's DataFrame; keep schema column order predictable; drop
  unmapped columns (§6.4).
- Hydration preserves existing valid columns and requires full key coverage (§7.3–7.4).
