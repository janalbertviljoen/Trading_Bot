# Steward, writing

The rules for writing any file, shared by the developer and the secretary: code,
documentation, records and instructions alike. They add to the rules for every role in
[AGENTS.md](AGENTS.md); where they differ, `AGENTS.md` wins. In Claude Code the
`developer` and `secretary` skills load this file with their own.

## Writing for the reader

Records and documentation are written for a person reading them, not only for agents:
the conclusion first, then the reasoning; plain words; production identifiers exactly
as in the code (§12.4). The persona stays in conversation (`AGENTS.md`, "Personality");
nothing written for others carries it.

## Formulas

Every formula in a Markdown file or a Word document is written in LaTeX: `$…$` inline,
and `$$…$$` on lines of its own for a display equation, with `\begin{aligned}` and `&`
to align a definition over several lines (user, 2026-10-19). The source must stay easy
to read:

- one definition per line, spaces around operators and relations;
- an inline formula stays on one line of the source: `skatkis.io.word` converts `$…$`
  only within a line, so a formula broken across lines is left as raw text in Word;
  wrap the line before the formula instead (user, 2026-10-30);
- a display formula is part of its sentence and carries the sentence's punctuation
  inside it: a comma when the sentence goes on ("…, where $B_t^o$ is …"), a full stop
  when it ends (user, 2026-10-19);
- a calculation or convention named in the text is written as math too, so formatting
  is consistent: $\text{actual}/365.25$, $\tau_t / 12$, $12 \cdot m$ (user, 2026-10-19);
- a symbol stands right after the term it names, and the term introducing an
  equation's quantity is written with its symbol: "the loss given default $LGD_t$
  blends the secured and unsecured LGDs ($LGD_S$ and $LGD_U$ respectively) …"
  (user, 2026-10-19);
- once an acronym is a symbol in an equation ($EAD_t$, $LGD_t$, $CCF$, $IRR$), it is
  always written as that symbol afterwards, with the same subscripts, so a variable
  looks the same throughout the document; before that point, and in names such as "PD
  model" or "PD band", it stays a word (user, 2026-10-19);
- an equation reference in the middle of a sentence is set off by a comma, "…length
  $s_t$ (2.1), by compounding …", unless it is part of the grammar ("in (3.2)", "(3.3)
  is …") (user, 2026-10-19);
- floors, caps and clipping that the code applies to keep a value in range are stated
  in the sentence ("floored at zero", "capped at one", "floored at one year and
  capped at five"), not written into the formula with $\min$ or $\max$; the formula
  shows the definition (user, 2026-10-19);
- once a concept is defined with its symbol, later text uses the symbol rather than
  repeating the description ("the PIT $\widetilde{PD}_t$", not "the PIT period PD
  $\widetilde{PD}_t$") (user, 2026-10-19);
- a difference of the same quantity between periods is written with $\Delta$ where
  it makes the formula simpler, defined where it is used ($\Delta ECR_t = ECR_t -
  ECR_{t+1}$); it is not forced in everywhere (user, 2026-10-19);
- in a document that carries mathematical definitions (a tool's financial logic
  document, a report, the tool README, the skatkis reference), the academic style of
  "Reports and issued documents" below applies: equations within sentences, numbered
  by the document's own sections with `\tag{…}` and referred to by number, symbols
  defined at first use. Equation numbers are local to their document: never refer to
  another document's equation number; refer to its section instead (user, 2026-10-19);
- a rate solved from cash flows is written $IRR$, also when it is a monthly rate
  ($EIR = 12 \cdot IRR$), never a placeholder such as $m$ or $r$ (user, 2026-10-30);
- `\frac`, `\sum_{…}`, `\left( … \right)` and the like, never ASCII stand-ins such as
  `/` for a long fraction or `Σ_(t)`;
- words inside a formula in `\text{…}`, multi-letter quantities as they are named in
  the text (`EAD_t`, `LGD_t^{\text{DT}}`);
- the meaning of each symbol in the sentence, not in comments beside the formula: the
  symbol right after the term it names when the sentence introduces the equation, or
  in a "where" clause after it;
- each symbol one meaning in a document. The repository has one canonical notation,
  inspired by the sources (Basel's $N$, $G$, $R$, $b$, $M$, $K$) but decided here: an
  external formula is restated in the repository's notation, never quoted in the
  source's (user, 2026-10-19);
- a calculation is described once, in the earliest section where everything it uses
  has been described, and later sections refer back to it; nothing is referred to
  before it is described (user, 2026-10-19). Saying where a result is used later is
  fine;
- one notation per tool: the tool README and the skatkis reference use the symbols of
  the tool's financial logic document (`docs/sign_off/<tool>_financial_logic.md`), and
  name the column of each symbol in a sentence after the formula; a change of symbol
  is made in all of them together (user, 2026-10-19);
- only the LaTeX that `skatkis.io.office_math` converts, so every document can be
  issued as Word with `python -m Toolbox.skatkis.io.word <file.md>`. A formula it
  rejects is rewritten, not left as plain text or an image.

Code blocks hold code, never formulas. Python docstrings keep plain Unicode notation,
because they are read as plain text.

## Reports and issued documents

Every document issued as Word follows these rules: a tool's financial logic document
(with the additions in `secretary.md`, "Writing the financial logic document"), a
client report, a methodology summary (user, 2026-10-30). The developer or the
secretary writes them.

- **Source and build.** The source is Markdown, so changes can be reviewed in a diff;
  the `.docx` is made from it with `python -m Toolbox.skatkis.io.word <file.md>
  [target.docx]` and never edited separately. The build puts the KPMG logo at the top
  left of every page, floating in the header, and the title and page number in the
  footer. A Word file open in Word cannot be rewritten: ask the user to close it.
  Never overwrite a document someone else supplied: build to a new name.
- **Where it lives.** A client report sits in the client's folder beside its sources;
  client data never leaves it (`AGENTS.md`, "Working rules"). The observations behind
  a report are kept in the tool's `notes.md`, worded without client data.
- **Reader first.** Say who the document is written for, and keep to it. A
  descriptive document (a methodology summary) describes; conclusions belong in the
  assessment it feeds.
- **Academic style** (user, 2026-10-19), as in a journal paper: each display equation
  is introduced and continued by its sentence, with its punctuation inside the formula;
  symbols are defined at first use, by the term they name or in a "where" clause; every
  display equation is numbered by section with `\tag{3.1}` and referred to by its
  number, "(3.1)", never by "the formula above". The document stays short and concise.
- **Definitions take precedence.** Each definition is a formula in LaTeX ("Formulas"
  above), with its symbols, defined once and not reused for another meaning.
- **Shared calculations once.** Where several models, products or units use the same
  calculation, define it once for a generic unit (an account, a cell) in an early
  common section, in the order the definitions build on each other, and let each
  later section state only its own inputs and refer back (user, 2026-10-30).
- **Citations, as in a journal paper** (user, 2026-10-19). Every definition or
  statement taken from a source carries its numbered citation, "[5]", placed by the
  formula or claim it supports; [1] is the in-house conventions (of the tool, or of
  the models a report describes), including the in-house parts of an otherwise
  standard definition; the others are numbered in order of first citation. A
  "References" section at the end lists them as "[n] Author(s), *Title*, edition,
  publisher (year), chapter". No standard paragraphs, README sections or code names in
  the running text. Official documentation cites only public or licensed sources
  (`developer.md`); a client report may also name the client's own source documents.
- **Cross-references.** Sections, equations, figures and citations are referred to
  as "section 6.5", "(3.1)", "Figure 1" and "[5]"; the Word build links each to its
  target (`skatkis.io.word`), as the references in a journal paper are links.

## Human-readable layout

When proposing folders, file names or document structure, design for a person browsing
the repository, not only for agents: a folder's top level shows what a reader needs
first, related files sit together, names say what a file is, and loose or generated
files (exports, duplicates, PDFs of Markdown) are not left lying around.

## Renames and the trail

When a name, module or path is renamed or moved, update every reference to the current
name. Whether to keep a trail (a "formerly X" note, a decision-log row, a note in a
change file) depends on how established the old name was:

- created and renamed in the same session: keep no trail; the old name never existed
  for anyone else;
- long-standing, so it appears in other branches, worktrees, commits or issued
  documents: ask the user whether to keep a trail before writing one or leaving one
  out. The tool's former name is such a trail, kept only in `steward/toolbox/<tool>/notes.md` at the user's request.

Names that are functional stay, whatever the trail decision: the `mcp` SDK, the `/mcp`
endpoint and `.mcp.json`.
